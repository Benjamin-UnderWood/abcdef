import request from '@/utils/request'

// 获取树结构
export function getTreeData() {
  return request({
    url: '/api/v1/tree',
    method: 'get'
  })
}

// 创建节点
export function createNode(data) {
  return request({
    url: '/api/v1/tree/',
    method: 'post',
    data
  })
}

// 编辑节点
export function editNode(id, data) {
  return request({
    url: `/api/v1/tree/${id}`,
    method: 'put',
    data
  })
}

// 删除节点
export function deleteNode(id) {
  return request({
    url: `/api/v1/tree/${id}`,
    method: 'delete'
  })
}
