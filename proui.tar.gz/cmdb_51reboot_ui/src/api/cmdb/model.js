import request from '@/utils/request'

// 模型列表
export function getModels(params) {
  return request({
    url: '/api/v1/cmdb/model-group',
    method: 'get',
    params
  })
}

// 新建分组
export function createModelGroup(data) {
  return request({
    url: '/api/v1/cmdb/model-group',
    method: 'post',
    data
  })
}

// 删除模型分组
export function deleteModelGroup(id) {
  return request({
    url: `/api/v1/cmdb/model-group/${id}`,
    method: 'delete'
  })
}

// 编辑模型分组
export function editModelGroup(id, data) {
  return request({
    url: `/api/v1/cmdb/model-group/${id}`,
    method: 'put',
    data
  })
}

// 新建模型
export function createModel(data) {
  return request({
    url: `/api/v1/cmdb/model`,
    method: 'post',
    data
  })
}

// 模型详情
export function modelDetails(id) {
  return request({
    url: `/api/v1/cmdb/model/${id}`,
    method: 'get'
  })
}

// 编辑模型信息
export function editModel(id, data) {
  return request({
    url: `/api/v1/cmdb/model/${id}`,
    method: 'put',
    data
  })
}

// 删除模型
export function deleteModel(id) {
  return request({
    url: `/api/v1/cmdb/model/${id}`,
    method: 'delete'
  })
}

// 新建字段分组
export function createFieldGroup(data) {
  return request({
    url: `/api/v1/cmdb/field-group`,
    method: 'post',
    data
  })
}

// 编辑字段分组
export function editFieldGroup(id, data) {
  return request({
    url: `/api/v1/cmdb/field-group/${id}`,
    method: 'put',
    data
  })
}

// 编辑字段分组
export function deleteFieldGroup(id) {
  return request({
    url: `/api/v1/cmdb/field-group/${id}`,
    method: 'delete'
  })
}

// 新建字段
export function createField(data) {
  return request({
    url: `/api/v1/cmdb/fields`,
    method: 'post',
    data
  })
}

// 编辑字段
export function editField(id, data) {
  return request({
    url: `/api/v1/cmdb/fields/${id}`,
    method: 'put',
    data
  })
}

// 删除字段
export function deleteField(id) {
  return request({
    url: `/api/v1/cmdb/fields/${id}`,
    method: 'delete'
  })
}

// 新建资源数据
export function createResource(data) {
  return request({
    url: `/api/v1/cmdb/resource`,
    method: 'post',
    data
  })
}

// 数据列表
export function resourceList(params) {
  return request({
    url: `/api/v1/cmdb/resource`,
    method: 'get',
    params
  })
}

// 编辑资源数据
export function editResource(id, data) {
  return request({
    url: `/api/v1/cmdb/resource/${id}`,
    method: 'put',
    data
  })
}

// 删除资源数据
export function deleteResource(id) {
  return request({
    url: `/api/v1/cmdb/resource/${id}`,
    method: 'delete'
  })
}
