<template>
  <div class="app-container">
    <el-row>
      <el-col v-for="item in list" :key="item.id" :span="6" style="padding-right: 8px">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>{{ item.name }}</span>
          </div>
          <div class="model-list">
            <div
              v-for="modelItem in item.models"
              :key="modelItem.id"
              @click="toResourceList(modelItem.id)"
            >
              {{ modelItem.name }}
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import {
  getModels
} from '@/api/cmdb/model'
export default {
  components: {

  },
  data() {
    return {
      list: []
    }
  },
  created() {
    this.getData()
  },
  methods: {
    // 查询模型分组及分组对应的模型
    getData() {
      getModels().then(res => {
        this.list = res.data.list
      })
    },
    toResourceList(id) {
      this.$router.push({ path: '/cmdb/resource/list', query: { id: id }})
    }
  }
}
</script>

<style scoped>
  .model-list > div {
    height: 30px;
    line-height: 30px;
    cursor: pointer;
    padding: 0 5px;
    font-size: 14px;
  }

  .model-list > div:hover {
    background-color: #F3F1F1;
  }
</style>
