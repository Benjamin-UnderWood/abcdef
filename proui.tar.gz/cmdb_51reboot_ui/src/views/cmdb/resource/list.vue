<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>资源列表</span>
      </div>
      <div>
        <div class="filter-container">
          <el-button
            v-permisaction="['system:user:create']"
            type="primary"
            size="mini"
            icon="el-icon-plus"
            style=" margin-right: 8px;"
            @click="handleCreate"
          >新 建</el-button>
          <el-input v-model="listQuery.username" placeholder="请输入搜索内容" size="mini" style="width: 350px;">
            <el-button slot="append" icon="el-icon-search" @click="handleFilter" />
          </el-input>
        </div>

        <el-table
          :key="tableKey"
          v-loading="false"
          :data="list"
          border
          fit
          highlight-current-row
          size="mini"
          style="width: 100%; margin-top: 10px;"
        >
          <template v-for="fieldItem of fieldList">
            <el-table-column
              v-if="fieldItem.is_list"
              :key="fieldItem.id"
              :label="fieldItem.cname"
              :prop="fieldItem.name"
            />
          </template>

          <el-table-column label="操作" align="center" width="230" class-name="small-padding fixed-width">
            <template slot-scope="{row,$index}">
              <!-- <el-button
                type="text"
                size="mini"
                icon="el-icon-edit"
                @click="handleSelect(row)"
              >
                查看
              </el-button> -->
              <el-button type="text" size="mini" icon="el-icon-edit" @click="handleUpdate(row)">
                编辑
              </el-button>
              <el-button size="mini" type="text" icon="el-icon-delete" @click="handleDelete(row,$index)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

      </div>
    </el-card>
    <el-drawer
      title="数据管理"
      :visible.sync="drawer"
      direction="rtl"
      size="50%"
    >
      <div style="padding: 0 20px 20px 20px;">
        <el-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="90px">
          <div v-for="fieldGroupItem in model.field_group" :key="fieldGroupItem.id">
            <div>{{ fieldGroupItem.name }}</div>
            <div style="margin-top: 20px; padding-left: 20px;">
              <template v-for="fieldItems in fieldGroupItem.fields">
                <el-form-item
                  :key="fieldItems.id"
                  :label="fieldItems.cname"
                  :prop="fieldItems.name"
                >
                  <el-input v-if="fieldItems.type === 'string'" v-model="ruleForm[fieldItems.name]" size="small" />
                  <el-input-number v-else-if="fieldItems.type === 'int'" v-model="ruleForm[fieldItems.name]" size="small" />
                </el-form-item>
              </template>
            </div>
          </div>
          <el-form-item label="tag" style="padding-left: 20px;">
            <el-select
              v-model="modelTag"
              multiple
              filterable
              allow-create
              default-first-option
              size="small"
              style="width: 100%"
            >
              <el-option
                v-for="item in ruleForm.data_tag"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="small" @click="submitForm('ruleForm')">保 存</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-drawer>
  </div>
</template>

<script>
import {
  modelDetails,
  createResource,
  resourceList,
  editResource,
  deleteResource
} from '@/api/cmdb/model'
import Pagination from '@/components/Pagination'
export default {
  components: {
    Pagination
  },
  data() {
    return {
      tableKey: 0,
      list: [],
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      },
      fieldList: [],
      drawer: false,
      ruleForm: {},
      rules: {},
      model: {},
      modelTag: [],
      resourceStatus: 'create'
    }
  },
  created() {
    this.getModel()
    this.getList()
  },
  methods: {
    getList() {
      this.list = []
      this.listQuery.model = this.$route.query.id
      resourceList(this.listQuery).then(res => {
        for (var d of res.data.list) {
          d.data['data_id'] = d.id
          d.data['data_model'] = d.model
          d.data['data_tag'] = d.tag
          this.list.push(d.data)
          this.total = res.data.total
        }
      })
    },
    getModel() {
      modelDetails(this.$route.query.id).then(res => {
        this.model = res.data
        for (var field_group of res.data.field_group) {
          for (var field of field_group.fields) {
            if (field.required) {
              this.rules[field.name] = [
                { required: true, message: '必填', trigger: 'blur' }
              ]
            }
            this.fieldList.push(field)
          }
        }
      })
    },
    handleCreate() {
      this.drawer = true
      this.ruleForm = {}
      this.modelTag = []
      this.resourceStatus = 'create'
      this.$nextTick(() => {
        this.$refs.ruleForm.clearValidate()
      })
    },
    handleUpdate(row) {
      this.drawer = true
      this.ruleForm = row
      this.modelTag = row.data_tag
      this.resourceStatus = 'edit'
      this.$nextTick(() => {
        this.$refs.ruleForm.clearValidate()
      })
    },
    handleDelete(row) {
      this.$confirm('确认是否删除此数据?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteResource(row.data_id).then(() => {
          this.getList()
          this.$notify({
            title: '成功',
            message: '删除成功',
            type: 'success',
            duration: 2000
          })
        })
      }).catch(() => {
        this.$notify({
          title: '取消',
          message: '已取消删除',
          type: 'info',
          duration: 2000
        })
      })
      console.log(row)
    },
    handleFilter() {},
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.resourceStatus === 'create') {
            createResource({
              model: this.$route.query.id,
              data: this.ruleForm,
              tag: this.modelTag
            }).then(res => {
              this.getList()
              this.drawer = false
              this.$notify({
                title: '成功',
                message: '创建成功',
                type: 'success',
                duration: 2000
              })
            })
          } else {
            var jsonParams = JSON.parse(JSON.stringify(this.ruleForm))
            delete jsonParams.data_id
            delete jsonParams.data_tag
            delete jsonParams.data_model
            editResource(this.ruleForm.data_id, {
              model: this.ruleForm.data_model,
              data: jsonParams,
              tag: this.modelTag
            }).then(res => {
              this.getList()
              this.drawer = false
              this.$notify({
                title: '成功',
                message: '编辑成功',
                type: 'success',
                duration: 2000
              })
            })
          }
        }
      })
    }
  }
}
</script>

<style scoped>

</style>
