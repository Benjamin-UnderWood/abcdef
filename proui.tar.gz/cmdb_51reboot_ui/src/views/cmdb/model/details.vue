<template>
  <div class="app-container">
    <div>
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>基础数据</span>
          <el-button
            v-if="model.field_group !== undefined && model.field_group.length === 0"
            style="float: right; padding: 3px 0; margin-left: 15px;"
            type="text"
            icon="el-icon-delete"
            @click="deleteModelHandle"
          >删除</el-button>
          <el-button
            style="float: right; padding: 3px 0"
            type="text"
            icon="el-icon-edit"
            @click="editModelHandle"
          >编辑</el-button>
        </div>
        <div style="font-size: 14px;">
          <el-row>
            <el-col :span="12" style="margin-bottom: 15px;">
              <span class="model-info-title">ID：</span>
              {{ model.id }}
            </el-col>
            <el-col :span="12" style="margin-bottom: 15px;">
              <span class="model-info-title">名称：</span>
              {{ model.name }}
            </el-col>
            <el-col :span="12">
              <span class="model-info-title">图标：</span>
              <i :class="model.icon" />
            </el-col>
            <el-col :span="12">
              <span class="model-info-title">标签：</span>
              <el-tag
                v-for="(tagItem, tagIndex) in model.tag"
                :key="tagIndex"
                size="mini"
                style="margin-right: 5px;"
              >{{ tagItem }}</el-tag>
            </el-col>
          </el-row>
        </div>
      </el-card>
    </div>
    <div style="margin-top: 8px;">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>字段管理</span>
        </div>
        <div>
          <!-- 新建 -->
          <div style="margin-bottom: 20px;">
            <el-button type="primary" size="mini" @click="createFieldHandle(undefined)">新建字段</el-button>
            <el-button type="primary" size="mini" @click="createFieldGroupHandle">新建分组</el-button>
          </div>
          <!-- 模型渲染 -->
          <template v-for="(item, index) in model.field_group">
            <div
              :key="item.id"
              class="model-list"
              :style="index === model.field_group.length - 1 ? {marginBottom: 0} : {}"
            >
              <!-- 字段分组名称 -->
              <div class="model-group-name">
                {{ item.name }}
                <i class="el-icon-edit" @click="editFieldGroupHandle(item)" />
                <i v-if="item.fields.length === 0" class="el-icon-delete" @click="deleteFieldGroupHandle(item.id)" />
              </div>
              <!-- 字段列表 -->
              <div class="model-list-content">
                <el-row>
                  <template v-for="fieldItem in item.fields">
                    <el-col
                      :key="fieldItem.id"
                      :span="4"
                      class="model-list-col"
                    >
                      <el-button
                        plain
                        style="height: 50px;"
                        @click="editFieldHandle(fieldItem)"
                      >{{ fieldItem.cname }}</el-button>
                    </el-col>
                  </template>
                  <el-col
                    :span="4"
                    class="model-list-col"
                  >
                    <el-button
                      plain
                      style="height: 50px; font-size: 12px; color: #999;"
                      @click="createFieldHandle(item.id)"
                    >添加字段</el-button>
                  </el-col>
                </el-row>
              </div>
            </div>
          </template>
        </div>
      </el-card>
    </div>

    <!-- 模型的基本信息编辑 -->
    <el-dialog
      title="模型管理"
      :visible.sync="modelDialogShow"
      width="38%"
    >
      <div>
        <el-form ref="modelRuleForm" :model="modelRuleForm" :rules="rules" label-width="80px">
          <el-form-item label="名称" prop="name">
            <el-input v-model="modelRuleForm.name" size="small" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="图标" prop="icon">
            <el-input v-model="modelRuleForm.icon" size="small" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="tag" prop="tag">
            <el-select
              v-model="modelRuleForm.tag"
              multiple
              filterable
              allow-create
              default-first-option
              size="small"
              style="width: 100%"
            >
              <el-option
                v-for="item in modelRuleForm.tag"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="modelDialogShow = false">取 消</el-button>
        <el-button type="primary" size="small" @click="submitModelForm('modelRuleForm')">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 字段分组管理 -->
    <el-dialog
      title="字段分组管理"
      :visible.sync="fieldGroupDialogShow"
      width="38%"
    >
      <div>
        <el-form ref="fieldGroupForm" :model="fieldGroupForm" :rules="rules" label-width="80px">
          <el-form-item label="名称：" prop="name">
            <el-input v-model="fieldGroupForm.name" size="small" />
          </el-form-item>
          <el-form-item label="顺序：" prop="sort">
            <el-input-number v-model="fieldGroupForm.sort" size="small" />
          </el-form-item>
          <el-form-item label="描述：" prop="remarks">
            <el-input v-model="fieldGroupForm.remarks" type="textarea" size="small" />
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="fieldGroupDialogShow = false">取 消</el-button>
        <el-button type="primary" size="small" @click="submitFieldGroup">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 字段管理 -->
    <el-dialog
      title="字段管理"
      :visible.sync="fieldDialogShow"
      width="38%"
    >
      <div>
        <el-form ref="fieldForm" :model="fieldForm" :rules="rules" label-width="90px">
          <el-form-item label="名称：" prop="name">
            <el-input v-model="fieldForm.name" size="small" placeholder="请输入英文标识" />
          </el-form-item>
          <el-form-item label="昵称：" prop="cname">
            <el-input v-model="fieldForm.cname" size="small" placeholder="请输入中文昵称" />
          </el-form-item>
          <el-form-item label="类型：" prop="type">
            <el-select v-model="fieldForm.type" size="small" style="width: 100%">
              <el-option label="字符串" value="string" />
              <el-option label="整数" value="int" />
            </el-select>
          </el-form-item>
          <el-row>
            <el-col :span="8">
              <el-form-item label="是否唯一：">
                <el-checkbox v-model="fieldForm.is_unique" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="是否必填：">
                <el-checkbox v-model="fieldForm.required" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="列表展示：">
                <el-checkbox v-model="fieldForm.is_list" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="分组：" prop="group">
            <el-select v-model="fieldForm.group" placeholder="请选择" size="small" style="width: 100%;">
              <el-option
                v-for="item in model.field_group"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="用户提示：">
            <el-input v-model="fieldForm.prompt" size="small" type="textarea" />
          </el-form-item>
          <el-form-item label="默认值：">
            <el-input v-model="fieldForm.default" size="small" />
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button
          v-if="fieldStatus === 'edit'"
          type="danger"
          size="small"
          style="float: left;"
          @click="deleteFieldHandle(fieldForm.id)"
        >删 除</el-button>
        <el-button size="small" @click="fieldDialogShow = false">取 消</el-button>
        <el-button type="primary" size="small" @click="submitFieldForm">确 定</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
import {
  modelDetails,
  editModel,
  deleteModel,
  createFieldGroup,
  editFieldGroup,
  deleteFieldGroup,
  createField,
  editField,
  deleteField
} from '@/api/cmdb/model'
export default {
  components: {

  },
  data() {
    return {
      modelDialogShow: false,
      fieldGroupDialogShow: false,
      fieldDialogShow: false,
      model: {},
      modelRuleForm: {},
      rules: {
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ],
        cname: [
          { required: true, message: '请输入昵称', trigger: 'blur' }
        ]
      },
      fieldStatus: 'create',
      fieldForm: {},
      fieldGroupForm: {
        model: this.$route.query.id
      },
      fieldGroupStatus: 'create'
    }
  },
  created() {
    this.getData()
  },
  methods: {
    getData() {
      modelDetails(this.$route.query.id).then(res => {
        this.model = res.data
      })
    },
    editModelHandle() {
      this.modelRuleForm = {
        name: this.model.name,
        icon: this.model.icon,
        tag: this.model.tag,
        group: this.model.group
      }
      this.modelDialogShow = true
      this.$nextTick(() => {
        this.$refs.modelRuleForm.clearValidate()
      })
    },
    deleteModelHandle() {
      this.$confirm('确认是否删除此模型?', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteModel(this.$route.query.id).then(() => {
          this.$router.push({ path: '/cmdb/model' })
        })
      }).catch(() => {
        this.$notify({
          title: '取消',
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    deleteFieldGroupHandle(id) {
      this.$confirm('确认是否删除此字段分组?', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteFieldGroup(id).then(() => {
          this.getData()
          this.$notify({
            type: 'success',
            title: 'Success',
            message: '删除字段分组成功'
          })
        })
      }).catch(() => {
        this.$notify({
          title: '取消',
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    createFieldGroupHandle() {
      this.fieldGroupStatus = 'create'
      this.fieldGroupForm = {
        model: this.$route.query.id
      }
      this.fieldGroupDialogShow = true
      this.$nextTick(() => {
        this.$refs.fieldGroupForm.clearValidate()
      })
    },
    editFieldGroupHandle(item) {
      this.fieldGroupStatus = 'edit'
      this.fieldGroupForm = item
      this.fieldGroupDialogShow = true
      this.$nextTick(() => {
        this.$refs.fieldGroupForm.clearValidate()
      })
    },
    submitFieldGroup() {
      this.$refs['fieldGroupForm'].validate((valid) => {
        if (valid) {
          if (this.fieldGroupStatus === 'create') {
            createFieldGroup(this.fieldGroupForm).then(res => {
              this.getData()
              this.fieldGroupDialogShow = false
              this.$notify({
                type: 'success',
                title: 'Success',
                message: '创建字段分组成功'
              })
            })
          } else {
            editFieldGroup(this.fieldGroupForm.id, {
              name: this.fieldGroupForm.name,
              model: this.fieldGroupForm.model,
              sort: this.fieldGroupForm.sort,
              remarks: this.fieldGroupForm.remarks
            }).then(res => {
              this.getData()
              this.fieldGroupDialogShow = false
              this.$notify({
                type: 'success',
                title: 'Success',
                message: '编辑字段分组成功'
              })
            })
          }
        }
      })
    },
    submitModelForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          editModel(this.$route.query.id, this.modelRuleForm).then(() => {
            this.getData()
            this.modelDialogShow = false
            this.$notify({
              type: 'success',
              title: 'Success',
              message: '编辑模型成功'
            })
          })
        }
      })
    },
    deleteFieldHandle(id) {
      this.$confirm('确认是否删除此字段?', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteField(id).then(() => {
          this.getData()
          this.fieldDialogShow = false
          this.$notify({
            type: 'success',
            title: 'Success',
            message: '删除字段成功'
          })
        })
      }).catch(() => {
        this.$notify({
          title: '取消',
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    createFieldHandle(id) {
      this.fieldForm = {}
      if (id !== undefined) {
        this.fieldForm.group = id
      }
      this.fieldStatus = 'create'
      this.fieldDialogShow = true
      this.$nextTick(() => {
        this.$refs['fieldForm'].clearValidate()
      })
    },
    editFieldHandle(field) {
      this.fieldForm = field
      this.fieldStatus = 'edit'
      this.fieldDialogShow = true
      this.$nextTick(() => {
        this.$refs['fieldForm'].clearValidate()
      })
    },
    submitFieldForm() {
      this.$refs['fieldForm'].validate((valid) => {
        if (valid) {
          this.fieldForm.model = this.$route.query.id
          if (this.fieldStatus === 'create') {
            createField(this.fieldForm).then(() => {
              this.getData()
              this.fieldDialogShow = false
              this.$notify({
                type: 'success',
                title: 'Success',
                message: '新建字段成功'
              })
            })
          } else {
            editField(this.fieldForm.id, this.fieldForm).then(() => {
              this.getData()
              this.fieldDialogShow = false
              this.$notify({
                type: 'success',
                title: 'Success',
                message: '编辑字段成功'
              })
            })
          }
        }
      })
    }
  }
}
</script>

<style scoped>
  .model-info-title {
    color: #999;
  }

  .model-list {
    margin-bottom: 20px;
  }

  .model-group-name {
    font-size: 13px;
    color: #999;
    border-left: 2px solid #ccc;
    padding-left: 5px;
  }

  .model-group-name > i {
    margin-left: 10px;
    cursor: pointer;
    display: none;
  }

  .model-group-name:hover i {
    display: inline;
  }

  .model-list-col {
    padding-left: 10px;
  }

  .model-list-col > .el-button {
    width: 100%;
    margin-top: 10px;
  }
</style>
