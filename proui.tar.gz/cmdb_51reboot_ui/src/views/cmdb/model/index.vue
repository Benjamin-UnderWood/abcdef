<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>模型管理</span>
      </div>
      <div>
        <!-- 新建 -->
        <div>
          <el-button type="primary" size="mini" @click="createModelHandle">新建模型</el-button>
          <el-button type="primary" size="mini" @click="createModelGroupHandle">新建分组</el-button>
        </div>
        <!-- 模型渲染 -->
        <template v-for="item in list">
          <div :key="item.id" class="model-list">
            <!-- 模型分组名称 -->
            <div class="model-group-name">
              {{ item.name }}
              <i class="el-icon-circle-plus-outline" />
              <i class="el-icon-edit" @click="editModelGroupHandle(item)" />
              <i v-if="item.models.length === 0" class="el-icon-delete" @click="deleteModelGroupHandle(item.id)" />
            </div>
            <!-- 模型列表 -->
            <div class="model-list-content">
              <el-row>
                <template v-for="modelItem in item.models">
                  <el-col
                    :key="modelItem.id"
                    :span="4"
                    class="model-list-col"
                  >
                    <el-button plain style="height: 50px;" @click="toModelDetails(modelItem.id)">{{ modelItem.name }}</el-button>
                  </el-col>
                </template>
              </el-row>
            </div>
          </div>
        </template>
      </div>
    </el-card>

    <el-dialog
      title="模型分组管理"
      :visible.sync="modelGroupDialogShow"
      width="38%"
    >
      <div>
        <el-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="60px">
          <el-form-item label="名称" prop="name">
            <el-input v-model="ruleForm.name" size="small" />
          </el-form-item>
          <el-form-item label="顺序" prop="sort">
            <el-input-number v-model="ruleForm.sort" size="small" />
          </el-form-item>
          <el-form-item label="描述" prop="remarks">
            <el-input v-model="ruleForm.remarks" type="textarea" size="small" />
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="modelGroupDialogShow = false">取 消</el-button>
        <el-button type="primary" size="small" @click="submitForm('ruleForm')">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="模型管理"
      :visible.sync="modelDialogShow"
      width="38%"
    >
      <div>
        <el-form ref="modelRuleForm" :model="modelRuleForm" :rules="rules" label-width="80px">
          <el-form-item label="名称" prop="name">
            <el-input v-model="modelRuleForm.name" size="small" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="图标" prop="icon">
            <el-input v-model="modelRuleForm.icon" size="small" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="tag" prop="tag">
            <el-select
              v-model="modelRuleForm.tag"
              multiple
              filterable
              allow-create
              default-first-option
              size="small"
              style="width: 100%"
            >
              <el-option
                v-for="item in modelRuleForm.tag"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="分组" prop="group">
            <el-select
              v-model="modelRuleForm.group"
              filterable
              size="small"
              style="width: 100%"
            >
              <el-option
                v-for="item in list"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="modelDialogShow = false">取 消</el-button>
        <el-button type="primary" size="small" @click="submitModelForm('modelRuleForm')">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>

import {
  getModels,
  createModelGroup,
  deleteModelGroup,
  editModelGroup,
  createModel
} from '@/api/cmdb/model'

export default {
  components: {

  },
  data() {
    return {
      modelGroupDialogShow: false,
      modelDialogShow: false,
      list: [],
      ruleForm: {},
      rules: {
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ]
      },
      modelRuleForm: {},
      modelGroupSubmitStatus: 'create'
    }
  },
  created() {
    this.getData()
  },
  methods: {
    // 查询模型分组及分组对应的模型
    getData() {
      getModels().then(res => {
        this.list = res.data.list
      })
    },
    toModelDetails(id) {
      this.$router.push({ path: '/cmdb/model/details', query: { id: id }})
    },
    deleteModelGroupHandle(id) {
      this.$confirm('确认是否删除模型分组?', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteModelGroup(id).then(res => {
          this.getData()
          this.$notify({
            title: 'Success',
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(() => {
        this.$notify({
          title: '取消',
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    createModelHandle() {
      this.modelDialogShow = true
      this.$nextTick(() => {
        this.$refs.modelRuleForm.clearValidate()
      })
    },
    createModelGroupHandle() {
      this.modelGroupSubmitStatus = 'create'
      this.modelGroupDialogShow = true
      this.ruleForm = {}
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
    },
    editModelGroupHandle(item) {
      this.modelGroupSubmitStatus = 'edit'
      this.ruleForm = item
      this.modelGroupDialogShow = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.modelGroupSubmitStatus === 'create') {
            // 新建模型分组
            createModelGroup(this.ruleForm).then(res => {
              this.getData()
              this.modelGroupDialogShow = false
              this.$notify({
                type: 'success',
                title: 'Success',
                message: '新建模型分组成功'
              })
            })
          } else {
            // 编辑模型分组
            editModelGroup(this.ruleForm.id, {
              name: this.ruleForm.name,
              sort: this.ruleForm.sort,
              remarks: this.ruleForm.remarks
            }).then(res => {
              this.getData() // 重新获取新的模型分组数据，进行渲染
              this.modelGroupDialogShow = false
              this.$notify({
                type: 'success',
                title: 'Success',
                message: '编辑模型分组成功'
              })
            })
          }
        }
      })
    },
    submitModelForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          createModel(this.modelRuleForm).then(res => {
            this.getData()
            this.modelDialogShow = false
            this.$notify({
              type: 'success',
              title: 'Success',
              message: '新建模型成功'
            })
          })
        }
      })
    }
  }
}
</script>

<style scoped>
  .model-list {
    margin-top: 20px;
  }

  .model-group-name {
    font-size: 13px;
    color: #999;
    border-left: 2px solid #ccc;
    padding-left: 5px;
  }

  .model-group-name > i {
    margin-left: 10px;
    cursor: pointer;
    display: none;
  }

  .model-group-name:hover i {
    display: inline;
  }

  .model-list-col {
    padding-left: 10px;
  }

  .model-list-col > .el-button {
    width: 100%;
    margin-top: 10px;
  }
</style>
