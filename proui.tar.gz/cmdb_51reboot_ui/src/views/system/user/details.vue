<template>
  <div>
    <h1>Hello Details</h1>
  </div>
</template>

<script>
export default {
  components: {

  },
  data() {
    return {

    }
  },
  methods: {

  }
}
</script>

<style scoped>

</style>
