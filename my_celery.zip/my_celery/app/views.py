import threading
from datetime import datetime, timedelta

from django.shortcuts import render

from celery_task.run import app
from celery_task.send_email.tasks import send_email
from django.http import JsonResponse
from celery.result import AsyncResult
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore, register_events

# DjangoJobStore 数据存储
# register_events 注册事件状态

# 生成调度器的实例
scheduler = BackgroundScheduler()
scheduler.add_jobstore(DjangoJobStore())  # 告诉调度器保存到哪里, 保存到django 对应的存储里面. django_apscheduler 帮我们封装好的

# 启动调度器, 不会阻塞进程
scheduler.start()


def add_crontab_job(request):
    """
    添加任务, 观察 django_apscheduler_djangojob 表数据创建
    :param request:
    :return:
    """

    res = {
        "code": 10000,
        "message": "OK",
        "data": []
    }
    try:
        if request.method == 'POST':
            scheduler.add_job(
                send_email.delay,  # 要传入的函数,
                "cron",  # 以什么方式执行
                args=(),  # 传递参数
                second="*/5",  # 每5秒执行一次
            )
            register_events(scheduler)  # 注册到django中
    except Exception as e:
        res["code"] = 10400
        res["message"] = str(e)

    return JsonResponse(res)


def delete_aps_job(request):
    """
    删除任务
    :param request:
    :return:
    """
    res = {
        "code": 10000,
        "message": "OK",
        "data": []
    }
    try:
        job_id = request.GET.get("job_id")
        scheduler.remove_job(job_id)
    except Exception as e:
        res["code"] = 10400
        res["message"] = str(e)

    return JsonResponse(res)

def test(request):
    """
    celery 任务练习
    :param request:
    :return:
    """
    # 直接执行任务
    # result = send_email.delay()
    # print(dir(result))
    # print(result.as_list())
    # print(result.task_id)
    # return JsonResponse({"code": 200, "data": result.id})
    # '_cache', '_get_task_meta', '_ignored', '_iter_meta', '_maybe_reraise_parent_error',
    # '_maybe_set_cache', '_on_fulfilled', '_parents', '_set_cache', '_to_remote_traceback',
    # 'app', 'args', 'as_list', 'as_tuple', 'backend', 'build_graph', 'children', 'collect',
    # 'date_done', 'failed', 'forget', 'get', 'get_leaf', 'graph', 'id', 'ignored', 'info',
    # 'iterdeps', 'kwargs', 'maybe_reraise', 'maybe_throw', 'name', 'on_ready', 'parent',
    # 'queue', 'ready', 'result', 'retries', 'revoke', 'state', 'status', 'successful',
    # 'supports_native_join', 'task_id', 'then', 'throw', 'traceback', 'wait', 'worker'

    # # 获取任务的返回结果
    # result = send_email.delay()  # 可在delay中给任务传递参数
    # async_result = AsyncResult(id=result.id, app=app)  # 通过任务id获取执行结果

    # # 获取任务的执行状态 PENDING, SUCCESS
    # def aa():
    #     while True:
    #         print(async_result.status)
    #         print(f"async_result.successful(): {async_result.successful()}")
    #         if async_result.successful():
    #             break
    #
    # t = threading.Thread(target=aa)
    # t.start()
    # t.join()
    # return JsonResponse({"code": 200, "data": async_result.get()})

    # 定时任务
    c_time = datetime.now()
    utc_time = datetime.utcfromtimestamp(c_time.timestamp())
    time_delay = timedelta(seconds=20)  # 10秒钟之后
    task_time = utc_time + time_delay
    result = send_email.apply_async(eta=task_time)  # 定时任务, 可以给任务传参数

    return JsonResponse({"code": 200, "data": {"id": result.id}})



