import datetime
import json
import os
import pathlib
import time
from uuid import uuid4

import pytz
from apscheduler.schedulers.background import BackgroundScheduler
from celery.result import AsyncResult
from django.core.paginator import Paginator, PageNotAnInteger
from django.shortcuts import render
from django_apscheduler.jobstores import DjangoJobStore, register_events
from rest_framework.views import APIView

from celery_task.run import app
from task_manager import models
from utils.api_response.api_response import api_response
from utils.task.get_file_name import get_file_name
from celery_task.command.tasks import exec_command
from celery_task.remote_command.tasks import exec_command as exec_remote_command
from utils.add_execute_task.add_execute_task import add_execute_task

"""
任务管理:
1. 任务列表
2. 创建任务
3. 更新任务
4. 删除任务
5. 任务详情
6. 执行命令
7. 立即执行任务
"""

scheduler = BackgroundScheduler()
scheduler.add_jobstore(DjangoJobStore())
scheduler.start()


# 文件类任务  scripts目录下
class TaskManager(APIView):

    def get(self, request):
        """
        获取文件列表
        :param request:
        :return:
        """
        try:
            # 获取目录的对象
            dir_obj = pathlib.Path("./scripts")

            # 获取文件的详细信息
            file_list = []
            for d in dir_obj.iterdir():  # dir_obj.iterdir() 返回一个可迭代对象
                f = pathlib.Path(d)
                # '__subclasshook__', '__truediv__', '_accessor', '_cached_cparts', '_closed', '_cparts',
                # '_drv', '_flavour', '_format_parsed_parts', '_from_parsed_parts', '_from_parts',
                # '_hash', '_init', '_make_child', '_make_child_relpath', '_opener', '_parse_args',
                # '_parts', '_pparts', '_raise_closed', '_raw_open', '_root', '_str', 'absolute',
                # 'anchor', 'as_posix', 'as_uri', 'chmod', 'cwd', 'drive', 'exists', 'expanduser',
                # 'glob', 'group', 'home', 'is_absolute', 'is_block_device', 'is_char_device', 'is_dir',
                # 'is_fifo', 'is_file', 'is_reserved', 'is_socket', 'is_symlink', 'iterdir', 'joinpath',
                # 'lchmod', 'lstat', 'match', 'mkdir', 'name', 'open', 'owner', 'parent', 'parents', 'parts',
                # 'read_bytes', 'read_text', 'relative_to', 'rename', 'replace', 'resolve', 'rglob', 'rmdir',
                # 'root', 'samefile', 'stat', 'stem', 'suffix', 'suffixes', 'symlink_to', 'touch', 'unlink',
                # 'with_name', 'with_suffix', 'write_bytes', 'write_text'
                cn_tz = pytz.timezone('Asia/Shanghai')
                file_list.append({
                    "name": f.name,
                    "owner": f.owner(),  # 属主
                    "group": f.group(),  # 属组
                    # "create_time": datetime.datetime.fromtimestamp(f.stat().st_ctime, tz=cn_tz),  # 创建时间 格式
                    "create_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(f.stat().st_ctime)),  # 创建时间
                    "update_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(f.stat().st_mtime)),  # 最后修改时间
                    "atime": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(f.stat().st_mtime)),  # 最后访问时间
                    # "lstat": {t: getattr(f.lstat(), t) for t in dir(f.lstat()) if t.startswith("st_")}
                })


            return api_response(data=file_list)
        except Exception as e:
            return api_response(10400, str(e))



    def post(self, request):
        """
        创建任务
        :param request:
        :return:
        """
        try:
            # 获取传进来的文件名
            # 筛选出参数对应的文件名, 不能出现以 . 或者  '/' 开头的文件
            # ../a.py  /a.py

            # 获取任务名称
            result, status = get_file_name(request.data)
            if not status:
                return api_response(10400, result)

            # 获取任务内容
            file_content = request.data.get("content", "")

            if file_content == "":
                return api_response(10400, "任务内容不能为空, 请确认content是否传递")
            # os.getcwd 项目根目录
            task_path = f"{os.getcwd()}/scripts/{result}"

            # pathlib 创建可以指定权限
            # 创建文件执行先查看是否存在, 如果存在不创建
            file_obj = pathlib.Path(task_path)  # 创建一个pathlib文件对象

            # 判断文件是否存在
            if file_obj.exists():
                return api_response(10400, f"任务<{result}>存在")

            # 创建任务文件
            file_obj.touch(mode=0o755)
            file_obj.write_text(file_content)  # 写入任务文件内容 文本类型
            return api_response()
        except Exception as e:
            return api_response(10400, str(e))


    def put(self, request):
        """
        编辑任务
        :param request:
        :return:
        """
        try:
            result, status = get_file_name(request.data)
            if not status:
                return api_response(10400, result)

            file_content = request.data.get('content', '')
            if file_content == '':
                return api_response(10400, "任务内容不能为空")

            # 生成实例
            update_file_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")
            # 判断文件是否存在
            if not update_file_obj.exists():
                return api_response(10400, f"任务{result}, 不存在")

            # 更新文件
            update_file_obj.write_text(file_content)
            return api_response()
        except Exception as e:
            return api_response(10400,str(e))

    def delete(self, request):
        """
        编辑任务
        :param request:
        :return:
        """
        try:
            result, status = get_file_name(request.GET)
            if not status:
                return api_response(10400, result)

            # 生成实例
            delete_file_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")
            # 判断文件是否存在
            if not delete_file_obj.exists():
                return api_response(10400, f"任务{result}, 不存在")

            # 删除文件
            delete_file_obj.unlink()
            return api_response()
        except Exception as e:
            return api_response(10400,str(e))


class TaskDetails(APIView):
    def get(self, request):
        """
        编辑任务
        :param request:
        :return:
        """
        try:
            result, status = get_file_name(request.GET)
            if not status:
                return api_response(10400, result)

            # 生成实例
            get_file_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")
            # 判断文件是否存在
            if not get_file_obj.exists():
                return api_response(10400, f"任务{result}, 不存在")
            file_content = get_file_obj.read_text()
            return api_response(data=file_content)
        except Exception as e:
            return api_response(10400,str(e))


# 立即执行命令
class ExecCommand(APIView):
    def post(self, request):
        try:
            """
                参数:
                title: 简要描述此次执行命令的标题
                command: 命令的内容
            """
            title = request.data.get("title", "")
            target_ip_list = request.data.get("ips", "").split(",")
            command = request.data.get("command", "")

            if title == "" or command == "":
                return api_response(10400, "command  和 title 必须传递")
            print(target_ip_list)

            # for ip in target_ip_list:
            #         exec_result = exec_remote_command.delay(ip, command)
            exec_result = exec_command.delay(command)

            result = AsyncResult(id=exec_result.id, app=app)
            models.TaskHistory.objects.create(**{
                "title": title,
                "task_id": exec_result.id,
                "task_type": "立即执行命令",
                "task_status": result.status
            })

            return api_response(data=result.get())
        except Exception as e:
            return api_response(10400, str(e))


# 立即执行任务
class ExecTask(APIView):
    def post(self, request):
        try:
            """
            name: 任务名称
            """
            result, status = get_file_name(request.data)
            if not status:
                return api_response(10400, result)
            task_script_path = f"{os.getcwd()}/scripts/{result}"
            exec_task_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")
            if not exec_task_obj.exists():
                return api_response(10400, "任务脚本不存在")

            exec_task_command = task_script_path
            # 如果是python文件那么通过python执行
            if task_script_path.endswith(".py"):
                exec_task_command = f"python {task_script_path}"
            elif task_script_path.endswith(".sh"):
                exec_task_command = task_script_path
            exec_result = exec_command.delay(exec_task_command)
            models.TaskHistory.objects.create(**{
                "title": result,
                "task_id": exec_result.id,
                "task_type": "立即执行任务"
            })

            return api_response()
        except Exception as e:
            return api_response(10400, str(e))


# 历史记录
class TaskHistory(APIView):
    def get(self, request):
        try:
            contact_list = models.TaskHistory.objects.all().order_by("-id")
            paginator = Paginator(contact_list, 10)  # 每页显示10条
            page = request.GET.get('page')
            try:
                contacts = paginator.page(page)
            except PageNotAnInteger:
                contacts = paginator.page(paginator.num_pages)
            return api_response(data={
                "total": paginator.count,
                "list": list(contacts.object_list.values())
            })
        except Exception as e:
            return api_response(10400, str(e))


# 通过任务ID, 将任务历史的执行结果返回
class TaskHistoryResult(APIView):
    def get(self, request):
        try:
            task_id = request.GET.get("task_id", "")
            if task_id == "":
                return api_response(10400, "task_id必须传递")

            result = AsyncResult(id=task_id, app=app)

            return api_response(data=result.get())
        except Exception as e:
            return api_response(10400, str(e))


# 定时任务
class CrontabTask(APIView):
    def get(self, request):
        """
        定时任务列表
        :param request:
        :return:
        """
        try:
            task_list = []
            job_list = scheduler.get_jobs()
            print(job_list)
            for j in job_list:
                tmp_dict = {
                    "id": j.id,
                    "next_run_time": j.next_run_time,
                    "name": "",
                    "remark": ""
                }
                job_info_list = models.CrontabTask.objects.filter(task_id=j.id)
                if len(job_info_list) > 0:
                    tmp_dict['name'] = job_info_list[0].name
                    tmp_dict['remark'] = job_info_list[0].remarks
                task_list.append(tmp_dict)
            return api_response(data=task_list)
        except Exception as e:
            return api_response(10400, str(e))

    def post(self, request):
        """
        创建定时任务
        :param request:
        :return:
        """
        try:
            task_name = request.data.get("task_name", "")
            execution_way = request.data.get("execution_way", "")
            name = request.data.get("name", "")
            remarks = request.data.get("remarks", "")
            execution_way = json.loads(execution_way)
            if task_name == "" or execution_way == "":
                return api_response(10400, "task_name 或者 execution_way 参数必须传递")

            # 定时任务job id  对应数据库
            task_id = uuid4().hex

            # 注册定时任务
            scheduler.add_job(
                add_execute_task,
                "cron",
                args=[f"./scripts/{task_name}"],
                id=task_id,
                **execution_way
            )
            # 注册事件
            register_events(scheduler)
            models.CrontabTask.objects.create(**{
                "task_id": task_id,
                "name": name,
                "remarks": remarks
            })
            return api_response()
        except Exception as e:
            return api_response(10400, str(e))

    def delete(self, request):
        """
        删除任务
        :param request:
        :return:
        """
        try:
            scheduler.remove_job(request.GET.get("job_id", ""))
            return api_response()
        except Exception as e:
            return api_response(10400, str(e))


    def put(self, request):
        """
        开启 暂停定时任务
        :param request:
        :return:
        """
        try:
            job_id = request.data.get("job_id", "")
            if job_id == "":
                return api_response(10400, "job_id必须传递")
            status = int(request.data.get("status", -1))
            if status == 1:
                scheduler.resume_job(job_id)  # 开启
            elif status == 0:
                scheduler.pause_job(job_id)  # 暂停
            return api_response()
        except Exception as e:
            return api_response(10400, str(e))