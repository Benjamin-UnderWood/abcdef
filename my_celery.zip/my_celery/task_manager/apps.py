from django.apps import AppConfig


class TaskManagerConfig(AppConfig):
    name = 'task_manager'
