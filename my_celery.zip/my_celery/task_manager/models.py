from django.db import models


# Create your models here.

class TaskHistory(models.Model):
    title = models.CharField(verbose_name="任务标题", max_length=128)
    task_id = models.CharField(verbose_name="任务ID", max_length=128)
    task_status = models.CharField(verbose_name="任务执行状态", max_length=128, null=True, blank=True)
    task_type = models.CharField(verbose_name="任务类型", max_length=128)

    def __str__(self):
        return self.title

    class Meta:
        db_table = "celery_task_history"
        verbose_name = "执行历史"
        verbose_name_plural = "执行历史"


# 扩展定时任务表
class CrontabTask(models.Model):
    task_id = models.CharField(verbose_name="任务ID", max_length=128)
    name = models.CharField(verbose_name="定时任务名称", max_length=128)
    remarks = models.CharField(verbose_name="备注", max_length=128)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "celery_crontab_task"
        verbose_name = "定时任务扩展"
        verbose_name_plural = "定时任务扩展"
