broker_url = "redis://127.0.0.1:6379/14"
result_backend = "redis://127.0.0.1:6379/15"


timezone = 'Asia/Shanghai'
enable_utc = False
