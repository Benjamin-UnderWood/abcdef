"""
检测定时任务执行的情况
"""
import threading
import time

from celery_task.run import app
from celery.result import AsyncResult


def get_result(id):
    a = time.time()
    async_result = AsyncResult(id=id, app=app)  # 通过任务id获取执行结果

    while True:
        print(async_result.status)
        print(f"async_result.successful(): {async_result.successful()}")
        if async_result.successful():
            break
    print(f"id: {id}, result: {async_result.get()}")
    print(f"花费时间: {time.time() - a}")

if __name__ == '__main__':
    t = threading.Thread(target=get_result, args=("71a5d2aa-d06a-4986-92e8-3a4c55c74e2f", ))
    t.start()
    t.join()
