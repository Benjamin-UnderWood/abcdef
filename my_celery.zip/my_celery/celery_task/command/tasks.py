"""
执行shell 命令
包括脚本
"""

import subprocess
from celery_task.run import app

@app.task
def exec_command(command):
    """
    用户传递 的命令
    :param command:
    :return:
    """
    try:
        # subprocess.Popen()
        _, output = subprocess.getstatusoutput(command)

    except Exception as e:
        output = str(e)

    return output  # 把任务执行的结果存入到d对应的celeryc存储中, 按照这个项目,就是存到入到redis中
