import time

from celery_task.run import app


@app.task
def send_email():
    print("发送邮件")
    time.sleep(1)
    print("发送成功!!!")
    return "successful!!!"
