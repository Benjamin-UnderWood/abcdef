#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

"""
执行shell命令，包括脚本
"""

import subprocess
import paramiko
# import logging
from celery_task.run import app  # Celery 实例对象
import celery


# log = logging.getLogger("django")


@app.task
def exec_command(ip, command):
    """
    :param command: 用户传递的命令
    :return:
    """
    try:
        ssh = paramiko.SSHClient()
        key = paramiko.AutoAddPolicy()
        ssh.set_missing_host_key_policy(key)
        ssh.connect(ip, 22, 'user', 'passwd', timeout=5)
        stdin, stdout, stderr = ssh.exec_command(command)

        for i in stdout.readlines():
            print(i)
        output = stdout
    except Exception as e:
        output = str(e)
    return output  # 会把任务执行的结果存入到对应的celery存储中，按照这个项目的话，就是存入到redis

    # raise KeyError
