import os

from celery import Celery

# 实例
app = Celery("test")

#  django settings

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "my_celery.settings")

# 引入celery的配置文件
app.config_from_object("celery_task.config")

# app.conf.timezone = 'Asia/Shanghai'
# app.conf.enable_utc = False

# 需要加载的任务, 自动找包下的tasks.py
app.autodiscover_tasks([
    "celery_task.send_email",
    "celery_task.command",
    "celery_task.remote_command",
])
