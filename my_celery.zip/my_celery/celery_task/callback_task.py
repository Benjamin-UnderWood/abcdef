#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

import os
from celery import Task
from celery.result import AsyncResult

from celery_task.run import app

from task_manager.models import TaskHistory

class MyTask(Task):
    # 任务失败时执行
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        async_result = AsyncResult(id=task_id, app=app)
        TaskHistory.objects.filter(task_id=task_id).update(**{"task_status": async_result.status})

    # 任务成功时执行
    def on_success(self, retval, task_id, args, kwargs):
        async_result = AsyncResult(id=task_id, app=app)
        print(f"task id: {task_id}, execute successfully.")
        TaskHistory.objects.filter(task_id=task_id).update(**{"task_status": async_result.status})

    # 任务重试时执行
    def on_retry(self, exc, task_id, args, kwargs, einfo):
        pass
