#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

# 筛选出参数对应的文件名, 不能出现以 . 或者  '/' 开头的文件
# 验证文件名称的格式
def get_file_name(request):
    file_name = request.get("name", "")  # request.data, request.GET
    if file_name == "":
        return "name参数必须传递", False

    if file_name.startswith("."):
        return "文件名称格式不正确，请勿使用'.'开头的文件名称", False

    if file_name.startswith("/"):
        return "文件名称格式不正确，请勿使用'/'开头的文件名称", False

    return file_name, True
