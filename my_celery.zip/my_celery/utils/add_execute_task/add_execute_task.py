#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

from celery_task.command.tasks import exec_command
from task_manager import models


def add_execute_task(task_name):
    exec_result = exec_command.delay(task_name)

    # 写入执行历史
    models.TaskHistory.objects.create(**{
        "title": task_name,
        "task_id": exec_result.id,
        "task_type": "定时任务"
    })
