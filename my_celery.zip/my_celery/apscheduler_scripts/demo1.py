from apscheduler.schedulers.blocking import BlockingScheduler
from datetime import datetime, timedelta

sched = BlockingScheduler()  # 阻塞调度器
"""
调度器
BackgroundScheduler  在使用框架(django) 时候用到
AsyncIOScheduler asyncio 模块
GeventScheduler gevent 协程模块
"""


def my_job():
    print(f"{datetime.now()} Hello World")


# sched.add_job(my_job, 'interval', seconds=2)  # 每2秒执行一次
a = datetime.now()
print(a)
# sched.add_job(my_job, 'interval', next_run_time=a + timedelta(seconds=5))  # 5秒之后执行, 间隔执行
# sched.add_job(my_job, next_run_time=a + timedelta(seconds=5))  # 5秒之后执行,仅执行一次,之后一直阻塞
# sched.add_job(my_job, trigger="cron", second="*/2")  # crontab 每两秒执行一次
# sched.add_job(my_job, trigger="cron", minute="*/2")  # crontab 每两分钟执行一次

# 输出
# 2021-09-19 14:31:39.579879
# 2021-09-19 14:32:00.001435 Hello World
# 2021-09-19 14:34:00.001125 Hello World
# 2021-09-19 14:36:00.001040 Hello World

# a = sched.add_job(my_job, trigger="cron", second="58", minute="39", hour="14", month="9", day="19")  # 只执行一次
# print(a)
# 2021-09-19 14:39:23.637867
# my_job (trigger: cron[month='9', day='19', hour='14', minute='39', second='58'], pending)
# 2021-09-19 14:39:58.005564 Hello World
a = sched.add_job(my_job, trigger="cron", second="*/2", minute="41", hour="14", month="9",
                  day="19")  # 在9/19 14:41分钟内,每两秒执行一次
# sched.add_job(my_job, trigger="cron", second="*/2", minute="41", hour="14", month="9",
#                   day="*")  # 9月份的每一天这个时间执行
# * * * * * * * 秒分时日月周年
sched.add_job(my_job, trigger="cron", second="*/2", minute="47", hour="14", month="9",
                  day="19", day_of_week="*", year="*")
# week="" 欧洲写法
# day_of_week="" 我们的使用方式  0-6
# year 年

sched.start()
