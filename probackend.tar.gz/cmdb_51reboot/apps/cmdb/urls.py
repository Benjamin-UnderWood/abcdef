#!/usr/bin/env python
# encoding: utf-8
# @author: lanyulei


from django.urls import path
from . import views

urlpatterns = [
    # 模型分组
    path("model-group", views.ModelGroupViewSet.as_view({"get": "list", "post": "create"})),
    path("model-group/<int:pk>", views.ModelGroupViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 模型
    path("model", views.ModelViewSet.as_view({"get": "list", "post": "create"})),
    path("model/<int:pk>", views.ModelViewSet.as_view({"get": "retrieve", "put": "update", "delete": "destroy"})),

    # 字段分组
    path("field-group", views.FieldGroupViewSet.as_view({"get": "list", "post": "create"})),
    path("field-group/<int:pk>", views.FieldGroupViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 字段
    path("fields", views.FieldsViewSet.as_view({"get": "list", "post": "create"})),
    path("fields/<int:pk>", views.FieldsViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 数据
    path("resource", views.ResourceViewSet.as_view({"get": "list", "post": "create"})),
    path("resource/<int:pk>", views.ResourceViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 数据关联
    path("resource-related", views.ResourceRelatedViewSet.as_view({"get": "list", "post": "create"})),
    path("resource-related/<int:pk>", views.ResourceRelatedViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 云账号管理
    path("cloud-account", views.CloudAccountViewSet.as_view({"get": "list", "post": "create"})),
    path("cloud-account/<int:pk>", views.CloudAccountViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 云资源同步
    path("cloud-discovery", views.CloudDiscoveryViewSet.as_view({"get": "list", "post": "create"})),
    path("cloud-discovery/<int:pk>", views.CloudDiscoveryViewSet.as_view({"put": "update", "delete": "destroy"})),
]
