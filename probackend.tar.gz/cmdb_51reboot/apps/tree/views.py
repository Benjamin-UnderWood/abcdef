from django.http import JsonResponse
from pkg.custom_model_view_set import CustomModelViewSet
from . import models, serializers
from pkg.recursion_service_tree import recursion_service_tree
from django.db import transaction
from rest_framework.views import APIView
from apps.cmdb.models import Resource
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# 服务树结构
class ServiceTreeViewSet(CustomModelViewSet):
    queryset = models.ServiceTreeModel.objects.all()
    serializer_class = serializers.ServiceTreeSerializer

    def list(self, request, *args, **kwargs):
        """
        使用递归的方式，将数据进行树结构的生成
        """
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            top_tree_list = list(models.ServiceTreeModel.objects.filter(parent=0).values())
            for node in top_tree_list:
                node["children"] = list(models.ServiceTreeModel.objects.filter(parent=node["id"]).values())
                node["children"] = recursion_service_tree.set_childrens(node["id"], node["children"])
            res["data"] = top_tree_list
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"获取树结构失败，{e}"
        return JsonResponse(res)

    def destroy(self, request, *args, **kwargs):
        """
        删除节点之前，需判断是否有关联资源
        """

        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            delete_related = request.GET.get("delete_related", "0")

            instance = self.get_object()

            with transaction.atomic():  # 事务
                if delete_related == "1":  # 删除关联
                    models.TreeRelatedModel.objects.filter(tree_id=instance.id).delete()

                # 判断是否有关联的资源数据
                tree_related_count = models.TreeRelatedModel.objects.filter(tree_id=instance.id).count()

                # 判断当前节点是否有子节点
                node_children_count = models.ServiceTreeModel.objects.filter(parent=instance.id).count()

                if tree_related_count > 0:
                    res["code"] = 40000
                    res["message"] = f"删除树节点失败，当前节点存在资源关联情况，无法直接删除。"
                elif node_children_count > 0:
                    res["code"] = 40000
                    res["message"] = f"删除树节点失败，当前节点存在子节点，无法直接删除。"
                else:
                    self.perform_destroy(instance)
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"删除树节点失败，{e}"
        return JsonResponse(res)


# 服务器关联资源
class TreeRelatedViewSet(CustomModelViewSet):
    queryset = models.TreeRelatedModel.objects.all()
    serializer_class = serializers.TreeRelatedSerializer


# 查询节点关联的数据
class GetNodeResourceAPIView(APIView):
    def get(self, request, pk, *args, **kwargs):
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            model_id = request.GET.get("model", None)
            if model_id is None:
                raise Exception("参数 model 没有传递")

            resource_id_list = [t[0] for t in
                                list(models.TreeRelatedModel.objects.filter(tree_id=pk).values_list("target_id"))]

            contact_list = Resource.objects.filter(id__in=resource_id_list, model=model_id).values()
            paginator = Paginator(contact_list, 10)  # 每页显示25条

            page = request.GET.get('page')
            try:
                contacts = paginator.page(page)
            except PageNotAnInteger:
                # 如果请求的页数不是整数，返回第一页。
                contacts = paginator.page(1)
            except EmptyPage:
                # 如果请求的页数不在合法的页数范围内，返回结果的最后一页。
                contacts = paginator.page(paginator.num_pages)

            res["data"] = {
                "total": paginator.count,
                "list": list(contacts.object_list.values()),
            }
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"查询关联资源失败，{e}"

        return JsonResponse(res)
