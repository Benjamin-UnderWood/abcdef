#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm


"""
启动命令：celery -A my_celery.run worker -l info
"""

import os
import django
from celery import Celery


# 创建Celery实例
app = Celery("bsc_celery_task")

# 引入django的settings
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "devops.settings")
django.setup()

# 读取配置文件
app.config_from_object("my_celery.config")

# 让程序自动去找注册的任务
app.autodiscover_tasks([
    "my_celery.command",
    "my_celery.remote_command"
])
