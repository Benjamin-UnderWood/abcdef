#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan

import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "bsc.production_settings")
django.setup()

