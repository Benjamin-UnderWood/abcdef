from rest_framework.views import APIView
from django.http import JsonResponse
from apps.cmdb import models
from rest_framework.authentication import SessionAuthentication, BaseAuthentication
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated
from apps.middleware.casbin import CasbinApiPermission


class Classification(APIView):
    authentication_classes = [SessionAuthentication, JSONWebTokenAuthentication]
    # permission_classes = [IsAuthenticated]
    permission_classes = [IsAuthenticated, CasbinApiPermission]

    """
    IsAuthenticated: 登陆验证
    CasbinApiPermission：权限验证
    
    casbin: 
      - p -> project （用户，角色）
      - g -> group (用户组，角色)
    """

    """
    Casbin: 缓存 -> 内存
    单点架构
    
    高可用 SLB -> 2台ECS 
    1ECS -> 修改权限
    2ECS -> 
    """

    # 获取分类列表
    def get(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        page = int(request.GET.get("page", 1))  # 页码
        limit = int(request.GET.get("limit", 10))  # 每页展示数量
        name = request.GET.get("name", "")  # 搜索
        if name == "":
            value_list = list(
                models.Classification.objects.all().order_by("-id").values()[(page - 1) * 10: limit * page])
        else:
            value_list = list(
                models.Classification.objects.filter(name__icontains=name).order_by("-id").values()[
                (page - 1) * 10: limit * page])

        res = {
            "list": value_list,
            "total": models.Classification.objects.count()
        }
        result["data"] = res
        return JsonResponse(result)

    # 新建分类
    def post(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        value = {
            "name": request.data.get("name"),
            "remarks": request.data.get("remarks")
        }

        try:
            models.Classification.objects.create(**value)
        except Exception as e:
            result["code"] = 10001
            result["message"] = "新建分类失败，{}".format(e)

        return JsonResponse(result)

    # 修改分类
    def put(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }

        value = {
            "name": request.data.get("name"),
            "remarks": request.data.get("remarks")
        }

        try:
            models.Classification.objects.filter(id=request.data.get("id", 0)).update(**value)
        except Exception as e:
            result["code"] = 10002
            result["message"] = "更新分类失败，{}".format(e)

        return JsonResponse(result)

    # 删除分类
    def delete(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }

        id = request.data.get("id", 0)
        try:
            models.Classification.objects.filter(id=id).delete()
        except Exception as e:
            result["code"] = 10003
            result["message"] = "删除分类失败，{}".format(e)

        return JsonResponse(result)


class Table(APIView):
    authentication_classes = [SessionAuthentication, JSONWebTokenAuthentication]
    permission_classes = [IsAuthenticated]

    # 表列表
    def get(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        page = int(request.GET.get("page", 1))
        limit = int(request.GET.get("limit", 10))
        name = request.GET.get("name", "")
        try:
            if name == "":
                value_list = list(models.Table.objects.all().order_by("-id").values()[(page - 1) * 10: limit * page])
            else:
                value_list = list(
                    models.Table.objects.filter(name__icontains=name).order_by("-id").values()[
                    (page - 1) * 10: limit * page])

            for table_value in value_list:
                classification_value = models.Classification.objects.filter(id=table_value.get("classification_id", 0))
                if classification_value:
                    table_value["classification_name"] = classification_value[0].name
                else:
                    table_value["classification_name"] = None

                table_value["classification"] = table_value["classification_id"]

            result_list = {
                "list": value_list,
                "total": models.Table.objects.count()
            }
            result["data"] = result_list
        except Exception as e:
            result["code"] = 10100
            result["message"] = "获取表数据失败，{}".format(e)

        return JsonResponse(result)

    # 新建表
    def post(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            table_value = request.data
            classification_obj = models.Classification.objects.get(id=table_value.get("classification", 0))
            table_value["classification"] = classification_obj
            models.Table.objects.create(**table_value)
        except Exception as e:
            result["code"] = 10101
            result["message"] = "创建表失败，{}".format(e)

        return JsonResponse(result)

    # 更新表
    def put(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            table_value = {
                "name": request.data.get("name"),
                "alias": request.data.get("alias"),
                "classification": models.Classification.objects.get(id=request.data.get("classification")),
                "fields": request.data.get("fields"),
                "remarks": request.data.get("remarks")
            }
            models.Table.objects.filter(id=request.data.get("id")).update(**table_value)
        except Exception as e:
            result["code"] = 10102
            result["message"] = "更新表失败，{}".format(e)

        return JsonResponse(result)

    # 删除表
    def delete(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        id = request.data.get("id", 0)
        try:
            models.Table.objects.filter(id=id).delete()
        except Exception as e:
            result["code"] = 10103
            result["message"] = "删除分类失败，{}".format(e)

        return JsonResponse(result)


# 获取分类对应的表
class ClassificationTable(APIView):
    authentication_classes = [SessionAuthentication, JSONWebTokenAuthentication]
    permission_classes = [IsAuthenticated]

    # 获取类型对应的表
    def get(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            id = request.GET.get("id", "")  # 分类ID
            if id == "":
                result["code"] = 10201
                result["message"] = "id参数不能为空"
            else:
                table_list = list(
                    models.Table.objects.filter(classification=id).values("id", "name", "alias"))  # 查询分类ID对应的表
                result["data"] = table_list
        except Exception as e:
            result["code"] = 10201
            result["data"] = f"获取表数据失败，{e}"

        return JsonResponse(result)


class TableValue(APIView):
    authentication_classes = [SessionAuthentication, JSONWebTokenAuthentication]
    permission_classes = [IsAuthenticated]

    # 获取类型对应的表
    def get(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            id = request.GET.get("id")
            table_value = list(models.Table.objects.filter(id=id).values())[0]
            result["data"] = table_value
        except Exception as e:
            result["code"] = 10202
            result["data"] = f"获取表数据失败，{e}"

        return JsonResponse(result)


class Data(APIView):
    # authentication_classes = [SessionAuthentication, JSONWebTokenAuthentication]
    # permission_classes = [IsAuthenticated]

    # 数据列表
    def get(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            page = int(request.GET.get("page", 1))
            limit = int(request.GET.get("limit", 10))
            table_id = int(request.GET.get("table_id", 0))
            search_key = request.GET.get("searchKey", "")
            search_value = request.GET.get("searchValue", "")
            table_object = models.Table.objects.get(id=table_id)
            if search_key == "" or search_value == "":
                value_list = list(models.Data.objects.filter(table=table_object).
                                  order_by("-id").values()[(page - 1) * 10: limit * page])
            else:
                value_list = list(models.Data.objects.filter(table=table_object).
                                  extra(
                    where=[f'''json_extract(value,  '$.{search_key}' ) like "%%{search_value}%%"''']).
                                  order_by("-id").values()[(page - 1) * 10: limit * page])

            result_list = {
                "list": value_list,
                "total": models.Data.objects.filter(table_id=table_id).count()
            }
            result["data"] = result_list
        except Exception as e:
            result["code"] = 10100
            result["message"] = f"获取数据失败，{e}"

        return JsonResponse(result)

    # 新建数据
    def post(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            data_value = {
                "table": models.Table.objects.get(id=request.data.get("table", 0)),
                "value": request.data.get("value")
            }

            models.Data.objects.create(**data_value)

            # data_value = [
            #     {
            #         "ip": "192.168.1.1",  # 唯一
            #         "hostname": "localhost",
            #         "host": "localhost",
            #         "name": "localhost"
            #     }
            # ]
            #
            # # models.Data.objects.get(id="")
            #
            # table = request.data.get("table", 0)
            # value = request.data.get("value")
            # if table == 0 or value == None:
            #     result["code"] = 10400
            #     result["message"] = f"参数不正确，请确认"
            #
            # # 1. 查询出表结构
            # table_struct = models.Table.objects.get(id=table)
            # """
            # [
            #     {
            #         "name":"ip",
            #         "type":"input",
            #         "alias":"IP",
            #         "remarks":"",
            #         "required":true
            #     },
            #     {
            #         "name":"hostname",
            #         "type":"input",
            #         "alias":"主机名",
            #         "remarks":"",
            #         "required":false
            #     }
            # ]
            # """
            #
            # # 2. 校验数据
            # status = True
            # for t in table_struct.fields:
            #     if t["required"]:
            #         if value.get(t["name"], None) == None:
            #             result["code"] = 10404
            #             result["data"] = f"<{t['alias']}> 必须传递"
            #             status = False
            #             break
            #
            # # 3. 变更历史
            # change_list = []
            # data_value1 = data_value[0]  # 相当于查询语句
            # for k in data_value1:
            #     if value.get(k, None):
            #         # 如果存在则判断数据是否有过变更
            #         if value.get(k) != data_value1[k]:
            #             change_list.append(f"数据变更，<{data_value1[k]}> => <{value.get(k)}>")
            #     else:
            #         # 如果不存在，则需要将当前数据清除，并且记录到历史记录中
            #         change_list.append(f"删除数据，<{k}>，<{data_value1[k]}>")
            #
            # change_value = ', '.join(change_list)
            # print(f"变更前的数据：{data_value[0]}")
            # data_value[0] = value
            # print(f"""变更前的数据：{value}\n\n\n变更记录：{change_value}""")
            #
            # if status:
            #     result["message"] = "创建成功"
            # else:
            #     result["message"] = "创建失败"

            # todo 创建数据

        except Exception as e:
            result["code"] = 10301
            result["data"] = f"创建数据失败，{e}"

        return JsonResponse(result)

    # 编辑数据
    def put(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            data_id = int(request.data.get("data_id", 0))
            data_value = {
                "table": models.Table.objects.get(id=request.data.get("table", 0)),
                "value": request.data.get("value")
            }

            models.Data.objects.filter(id=data_id).update(**data_value)
        except Exception as e:
            result["code"] = 10302
            result["data"] = f"更新数据失败，{e}"

        return JsonResponse(result)

    # 删除数据
    def delete(self, request, *args, **kwargs):
        result = {
            "code": 20000,
            "message": "成功",
            "data": ""
        }
        try:
            data_id = request.data.get("data_id", 0)
            models.Data.objects.filter(id=data_id).delete()
        except Exception as e:
            result["code"] = 10303
            result["data"] = f"删除数据失败，{e}"

        return JsonResponse(result)
