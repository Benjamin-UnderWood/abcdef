from django.apps import AppConfig


class CeleryTasksConfig(AppConfig):
    name = 'apps.celery_tasks'
