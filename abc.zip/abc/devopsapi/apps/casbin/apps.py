from django.apps import AppConfig


class CasbinConfig(AppConfig):
    name = 'apps.casbin'
    verbose_name = "API权限系统"
