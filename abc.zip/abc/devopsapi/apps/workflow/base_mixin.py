from rest_framework.decorators import action
from rest_framework.response import Response
class UpDownMixin(object):
    @action(methods=['get'], detail=True)
    def up(self, request, pk):
        '''
        向上移动
        '''
        instance = self.get_object()
        last_instance = self.queryset.filter(workflow=instance.workflow, order_num__lt=instance.order_num).last()
        if last_instance:
            last_instance.order_num, instance.order_num = instance.order_num, last_instance.order_num
            last_instance.save()
            instance.save()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    @action(methods=['get'], detail=True)
    def down(self, request, pk):
        '''
        向下移动
        '''
        instance = self.get_object()
        next_instance = self.queryset.filter(workflow=instance.workflow, order_num__gt=instance.order_num).first()
        if next_instance:
            next_instance.order_num, instance.order_num = instance.order_num, next_instance.order_num
            next_instance.save()
            instance.save()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)