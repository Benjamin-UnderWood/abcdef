# -*- coding: utf-8 -*-
#author Jack qq:774428957
import json,logging
from django.conf import settings
from django.db import transaction
from django.db.models import Q, Count
from django.contrib.auth import get_user_model
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import action
from utils.base_view import BaseModelViewSet
from .base_mixin import UpDownMixin
from apps.user.models import Role

from .util import *
from .serializers import *
from .models import *
from .filters import *

User = get_user_model()

logger = logging.getLogger('views')

class WorkFlowGroupViewSet(BaseModelViewSet):
    '''
        queryset=model.objects.all().order_by('id')
        serializers
        search_filed=('name','cname')
    '''
    queryset=WorkFlowGroup.objects.all().order_by('-id')   #list
    serializer_class = WorkFlowGroupSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')


class WorkFlowViewSet(BaseModelViewSet):
    '''
        queryset=model.objects.all().order_by('id')
        serializers
        search_filed=('name','cname')
    '''
    queryset=WorkFlow.objects.all().order_by('-id')   #list
    serializer_class = WorkFlowSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')

    @action(methods=['get'], detail=True)
    def steps(self, request, pk):
        '''
        审批流
        '''
        instance = self.get_object()
        step_instances = AuditStep.objects.filter(workflow=instance).order_by('order_num')
        serializer = AuditStepSerializer(step_instances, many=True)
        return Response(serializer.data)

    @action(methods=['get'],detail=True)
    def formfields(self,request,pk):
        instances = FormField.objects.filter(workflow_id=pk).order_by('order_num')
        serializer = FormFieldSerializer(instances, many=True)
        #把有dicturl的数据都调用一边:
        #数据组装完毕后在用

        return Response(serializer.data)

    @action(methods=['get'], detail=False)
    def demoformfields(self, request):
        '''
        demo表单字段
        '''
        instance = WorkFlow.objects.get(name='demo')
        formfield_instances = FormField.objects.filter(workflow=instance).order_by('order_num')
        serializer = FormFieldSerializer(formfield_instances, many=True)
        return Response(serializer.data)


class AuditStepViewSet(UpDownMixin,BaseModelViewSet):
    queryset = AuditStep.objects.order_by('order_num')
    serializer_class = AuditStepSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')

    def list(self,request):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        print(serializer.data)
        return Response(serializer.data)

    @action(methods=['get'], detail=False)
    def get_table_info(self, request):
        '''
        获取表字段名和过滤选项
        '''
        data = {}
        if hasattr(self.queryset.model(), 'get_fields'): data['fields'] = self.queryset.model().get_fields()
        data['role_types'] = AuditStep.ROLE_TYPE
        data['roles'] = [{'id': row.id, 'cname': row.cname} for row in Role.objects.all()]
        return Response(data)

class FormFieldViewSet(UpDownMixin,BaseModelViewSet):
    queryset = FormField.objects.order_by('order_num')
    serializer_class = FormFieldSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')


class OpenApiViewSet(UpDownMixin,BaseModelViewSet):
    queryset = NoneModel.objects.all()
    serializer_class = OpenApiSerializer

    @action(methods=['get'], detail=False)
    def get_ecstypes(self,request):
        '''
        #使用阿里云 api/sdk 链接进入
        # 获取列表.格式化成能使用的格式
            [
                {"value":"0","label":"大象","disabled":false},
                {"value":"1","label":"青蛙","disabled":false},
                {"value":"2","label":"狐狸","disabled":false}
            ]
        :param request:
        :return:
        '''
        ret=[
            {"value": 1, "label": "大象", "disabled": False},
            {"value": 2, "label": "青蛙", "disabled": False},
            {"value": 3, "label": "狐狸", "disabled": False}
        ]
        return Response(ret)