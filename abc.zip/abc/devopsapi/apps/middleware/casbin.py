import os
import casbin
from django.conf import settings

from rest_framework.permissions import BasePermission

from apps.casbin.adapter import DjangoAdapter
from apps.casbin.models import CasbinRule


class CasbinApiPermission(BasePermission):
    """
        Casbin Token permission controller.
    """

    def has_permission(self, request, view):
        username = request.user
        path = request.META.get('PATH_INFO')
        method = request.META.get('REQUEST_METHOD')

        print("username: {}, path: {}, method: {}.".format(
            username,
            path,
            method
        ))

        e = casbin.Enforcer(
            os.path.join(settings.ROOT_DIR, "config", "keymatch_model.conf"),
            adapter=DjangoAdapter(CasbinRule),
            enable_log=False,
        )
        return e.enforce(request.user.username, path, method)
