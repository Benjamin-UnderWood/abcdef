import request from '@/utils/request'

// 获取树状结构
export function treeData() {
  return request({
    url: '/api/v1/service-tree',
    method: 'get'
  })
}

// 新建
export function createTreeNode(data) {
  return request({
    url: '/api/v1/service-tree',
    method: 'post',
    data
  })
}

// 编辑
export function updateTreeNode(data) {
  return request({
    url: '/api/v1/service-tree',
    method: 'put',
    data
  })
}

// 删除
export function deleteTreeNode(id) {
  return request({
    url: `/api/v1/service-tree?id=${id}`,
    method: 'delete'
  })
}

// 获取模型详情
export function cmdbTableDetails(id) {
  return request({
    url: `/api/v1/cmdb-table-details?table_id=${id}`,
    method: 'get'
  })
}

// 绑定cmdb数据
export function bindCmdbData(data) {
  return request({
    url: `/api/v1/bind-cmdb-data`,
    method: 'post',
    data
  })
}

// 获取绑定的分类列表
export function getBindClassifyList(service_tree) {
  return request({
    url: `/api/v1/get-bind-classify?service_tree=${service_tree}`,
    method: 'get'
  })
}

// 获取绑定的分类对应的表列表数据
export function getBindClassifyTableList(params) {
  return request({
    url: `/api/v1/get-bind-classify-table`,
    method: 'get',
    params
  })
}

// 获取表绑定的数据
export function getBindTableDataList(params) {
  return request({
    url: `/api/v1/get-bind-table-data`,
    method: 'get',
    params
  })
}

// 删除绑定
export function deleteBind(params) {
  return request({
    url: `/api/v1/delete-bind`,
    method: 'delete',
    params
  })
}
