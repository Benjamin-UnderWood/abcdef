import request from '@/utils/request'

// 任务列表
export function taskList() {
  return request({
    url: '/api/v1/task/manage',
    method: 'get'
  })
}

// 新建任务
export function createTask(data) {
  return request({
    url: '/api/v1/task/manage',
    method: 'post',
    data
  })
}

// 任务详情
export function taskDetails(params) {
  return request({
    url: '/api/v1/task/details',
    method: 'get',
    params
  })
}

// 更新任务
export function updateTask(data) {
  return request({
    url: '/api/v1/task/manage',
    method: 'put',
    data
  })
}

// 删除任务
export function deleteTask(params) {
  return request({
    url: '/api/v1/task/manage',
    method: 'delete',
    params
  })
}

// 立即执行命令
export function execCommandRequest(data) {
  return request({
    url: '/api/v1/task/command',
    method: 'post',
    data
  })
}

// 立即执行任务
export function execTaskRequest(data) {
  return request({
    url: '/api/v1/task/execute',
    method: 'post',
    data
  })
}

// 任务历史列表
export function getTaskHistory(params) {
  return request({
    url: '/api/v1/task/history',
    method: 'get',
    params
  })
}

// 任务历史返回结果
export function getTaskHistoryResult(params) {
  return request({
    url: '/api/v1/task/history-result',
    method: 'get',
    params
  })
}

// 定时任务列表
export function crontabTaskList() {
  return request({
    url: '/api/v1/task/crontab',
    method: 'get'
  })
}

// 定时任务列表
export function createCrontabTask(data) {
  return request({
    url: '/api/v1/task/crontab',
    method: 'post',
    data
  })
}

// 定时任务列表
export function deleteCrontabTask(params) {
  return request({
    url: '/api/v1/task/crontab',
    method: 'delete',
    params
  })
}

// 定时任务列表
export function switchCrontabTask(data) {
  return request({
    url: '/api/v1/task/crontab',
    method: 'put',
    data
  })
}
