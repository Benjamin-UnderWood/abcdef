import request from '@/utils/request'

// 分类列表
export function classificationList(params) {
  return request({
    url: '/api/v1/classification',
    method: 'get',
    params
  })
}

// 新建分类
export function createClassification(data) {
  return request({
    url: '/api/v1/classification',
    method: 'post',
    data
  })
}

// 更新分类
export function updateClassification(data) {
  return request({
    url: '/api/v1/classification',
    method: 'put',
    data
  })
}

// 删除分类
export function deleteClassification(data) {
  return request({
    url: '/api/v1/classification',
    method: 'delete',
    data
  })
}

// 表列表
export function tableList(params) {
  return request({
    url: '/api/v1/table',
    method: 'get',
    params
  })
}

// 新建表
export function createTable(data) {
  return request({
    url: '/api/v1/table',
    method: 'post',
    data
  })
}

// 更新表
export function updateTable(data) {
  return request({
    url: '/api/v1/table',
    method: 'put',
    data
  })
}

// 删除表
export function deleteTable(data) {
  return request({
    url: '/api/v1/table',
    method: 'delete',
    data
  })
}

// 获取分类对应的表
export function classificationTable(params) {
  return request({
    url: '/api/v1/classification/table',
    method: 'get',
    params
  })
}

// 获取表详细信息
export function getTableValue(params) {
  return request({
    url: 'api/v1/table/value',
    method: 'get',
    params
  })
}

// 新建数据
export function createData(data) {
  return request({
    url: 'api/v1/data',
    method: 'post',
    data
  })
}

// 更新数据
export function updateData(data) {
  return request({
    url: 'api/v1/data',
    method: 'put',
    data
  })
}

// 数据列表
export function dataList(params) {
  return request({
    url: 'api/v1/data',
    method: 'get',
    params
  })
}

// 删除数据
export function deleteData(data) {
  return request({
    url: 'api/v1/data',
    method: 'delete',
    data
  })
}
