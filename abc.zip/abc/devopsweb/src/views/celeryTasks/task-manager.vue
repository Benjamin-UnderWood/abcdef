<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>任务管理</span>
      </div>
      <div class="text item">
        <div class="filter-container">
          <el-button class="filter-item" type="primary" icon="el-icon-edit" @click="handleCreate">
            新建
          </el-button>
          <el-button class="filter-item" type="primary" icon="el-icon-edit" @click="dialogCommandVisible = true">
            执行命令
          </el-button>
        </div>

        <!-- 任务列表 -->
        <el-table
          :key="tableKey"
          v-loading="listLoading"
          :data="list"
          border
          fit
          highlight-current-row
          style="width: 100%; margin-top: 12px"
        >
          <el-table-column label="名称">
            <template slot-scope="{row}">
              <span>{{ row.name }}</span>
            </template>
          </el-table-column>
          <el-table-column label="属主">
            <template slot-scope="{row}">
              <span>{{ row.owner }}</span>
            </template>
          </el-table-column>
          <el-table-column label="属组">
            <template slot-scope="{row}">
              <span>{{ row.group }}</span>
            </template>
          </el-table-column>
          <el-table-column label="创建时间">
            <template slot-scope="{row}">
              <span>{{ row.create_time | formatDate }}</span>
            </template>
          </el-table-column>
          <el-table-column label="更新时间">
            <template slot-scope="{row}">
              <span>{{ row.update_time | formatDate }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" align="center" width="280" class-name="small-padding fixed-width">
            <template slot-scope="{row,$index}">
              <el-button type="primary" size="mini" @click="handleExecTask(row)">
                立即执行
              </el-button>
              <el-button type="primary" size="mini" @click="handleUpdate(row)">
                编辑
              </el-button>
              <el-button size="mini" type="danger" @click="handleDelete(row,$index)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 新建任务/编辑任务的弹窗 -->
        <el-dialog :title="textMap[dialogStatus]==='Create'?'新建任务': '编辑任务'" :visible.sync="dialogFormVisible">
          <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="70px" style="margin-left:50px;">
            <el-form-item label="名称" prop="name">
              <el-input v-model="temp.name" size="small" />
            </el-form-item>
            <el-form-item label="内容" prop="content">
              <el-input v-model="temp.content" type="textarea" rows="8" size="small" />
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">
              关闭
            </el-button>
            <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">
              提交
            </el-button>
          </div>
        </el-dialog>

        <!-- 执行命令的弹窗 -->
        <el-dialog title="立即执行命令" :visible.sync="dialogCommandVisible">
          <el-form
            ref="dataForm"
            :rules="rules"
            :model="execCommandParams"
            label-position="left"
            label-width="70px"
            style="margin-left:50px;"
          >
            <el-form-item label="标题" prop="title">
              <el-input v-model="execCommandParams.title" size="small" />
            </el-form-item>
            <el-form-item label="IP列表" prop="ip_list">
              <el-select v-model="execCommandParams.ip_list" size="small" multiple placeholder="请选择需要去执行的IP" style="width: 100%">
                <el-option
                  v-for="item in server_list"
                  :key="item.id"
                  :label="item.value.ip"
                  :value="item.value.ip">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="命令" prop="command">
              <el-input v-model="execCommandParams.command" type="textarea" rows="8" size="small" />
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogCommandVisible = false">
              关闭
            </el-button>
            <el-button type="primary" @click="execCommand">
              提交
            </el-button>
          </div>
        </el-dialog>
      </div>
    </el-card>
  </div>
</template>

<script>
import moment from 'moment'
import waves from '@/directive/waves' // waves directive

// 任务相关的请求方法
import {
  taskList,
  createTask,
  taskDetails,
  updateTask,
  deleteTask,
  execCommandRequest,
  execTaskRequest
} from '@/api/celeryTasks'

import {
  dataList
} from '@/api/cmdb'

export default {
  name: 'Classification',
  directives: { waves },
  filters: {
    formatDate: function(date) {
      return moment.utc(date).format('YYYY-MM-DD HH:mm:ss')
    }
  },
  data() {
    return {
      server_list: [],
      tableKey: 0,
      list: null,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      },
      temp: {
        name: '',
        content: ''
      },
      execCommandParams: {
        title: '',
        command: ''
      },
      dialogFormVisible: false,
      dialogCommandVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      rules: {
        name: [{ required: true, message: '任务名称不能为空', trigger: 'blur' }],
        content: [{ required: true, message: '任务内容不能为空', trigger: 'blur' }],
        title: [{ required: true, message: '标题不能为空', trigger: 'blur' }],
        command: [{ required: true, message: '命令不能为空', trigger: 'blur' }]
      }
    }
  },
  created() {
    this.getList()
    this.getTableDataList()
  },
  methods: {
    // 任务列表
    getList() {
      this.listLoading = true
      taskList().then(response => {
        this.list = response.data
        this.listLoading = false
      })
    },
    getTableDataList() {
      dataList({
        limit: 99999,
        table_id: 1
      }).then(response => {
        this.server_list = response.data.list
      })
    },
    handleExecTask(row) {
      this.$confirm('是否立即执行任务？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        execTaskRequest({
          name: row.name
        }).then(response => {
          this.$message({
            type: 'success',
            message: '已加入任务队列'
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消'
        })
      })
    },
    execCommand() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          execCommandRequest(this.execCommandParams).then(response => {
            this.dialogCommandVisible = false
            this.$notify({
              'title': '成功',
              'type': 'success',
              'message': '命令已加入执行队列'
            })
          })
        }
      })
    },
    resetTemp() {
      this.temp = {
        name: '',
        content: ''
      }
    },
    // 新建任务
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    // 新建任务的请求方法
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          createTask(this.temp).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '创建成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    // 更新任务的初始化方法
    handleUpdate(row) {
      this.temp.name = row.name // copy obj
      // 获取任务详情
      taskDetails({
        name: this.temp.name
      }).then(response => {
        this.temp.content = response.data
        this.dialogStatus = 'update'
        this.dialogFormVisible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].clearValidate()
        })
      })
    },
    // 更新任务的请求方法
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          updateTask(tempData).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '更新成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    // 删除任务
    handleDelete(row, index) {
      this.$confirm('此操作将删除该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteTask(
          { name: row.name }
        ).then(response => {
          this.getList()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  }
}
</script>

<style scoped>
  .text {
    font-size: 14px;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  .clearfix:after {
    clear: both
  }
</style>
