<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>任务管理</span>
      </div>
      <div class="text item">
        <div class="filter-container">
          <el-button class="filter-item" type="primary" icon="el-icon-edit" @click="handleCreate">
            新建
          </el-button>
        </div>

        <!-- 任务列表 -->
        <el-table
          :key="tableKey"
          v-loading="listLoading"
          :data="list"
          border
          fit
          highlight-current-row
          style="width: 100%; margin-top: 12px"
        >
          <el-table-column label="任务ID">
            <template slot-scope="{row}">
              <span>{{ row.id }}</span>
            </template>
          </el-table-column>
          <el-table-column label="名称">
            <template slot-scope="{row}">
              <span>{{ row.name }}</span>
            </template>
          </el-table-column>
          <el-table-column label="备注">
            <template slot-scope="{row}">
              <span>{{ row.remarks }}</span>
            </template>
          </el-table-column>
          <el-table-column label="下次执行时间">
            <template slot-scope="{row}">
              <span>{{ row.next_run_time | formatDate }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" align="center" width="280" class-name="small-padding fixed-width">
            <template slot-scope="{row,$index}">
              <el-button :type="row.next_run_time === null ? 'primary' : 'info'" size="mini" @click="handleSwitch(row)">
                {{ row.next_run_time === null ? '开启' : '暂停' }}
              </el-button>
              <el-button size="mini" type="danger" @click="handleDelete(row,$index)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 新建任务/编辑任务的弹窗 -->
        <el-dialog title="创建定时任务" :visible.sync="dialogFormVisible">
          <el-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="100px" class="demo-ruleForm">
            <el-form-item label="绑定任务" prop="task_name">
              <el-select v-model="ruleForm.task_name" clearable filterable placeholder="请选择任务" style="width: 100%" size="small">
                <el-option
                  v-for="(items, index) in allTaskList"
                  :key="index"
                  :label="items.name"
                  :value="items.name"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="任务名称" prop="name">
              <el-input v-model="ruleForm.name" placeholder="请输入名称" />
            </el-form-item>
            <el-form-item label="任务备注">
              <el-input v-model="ruleForm.remarks" placeholder="请输入备注" />
            </el-form-item>
            <el-form-item label="执行时间">
              <el-row>
                <el-col :span="3"><el-input v-model="ruleForm.execution_way.second" placeholder="秒，默认 1" style="width: 100%" size="small" /></el-col>
                <el-col :span="3"><el-input v-model="ruleForm.execution_way.minute" placeholder="分，默认 1" style="width: 100%" size="small" /></el-col>
                <el-col :span="3"><el-input v-model="ruleForm.execution_way.hour" placeholder="时，默认 *" style="width: 100%" size="small" /></el-col>
                <el-col :span="3"><el-input v-model="ruleForm.execution_way.day" placeholder="日，默认 *" style="width: 100%" size="small" /></el-col>
                <el-col :span="4"><el-input v-model="ruleForm.execution_way.month" placeholder="月，默认 *" style="width: 100%" size="small" /></el-col>
                <el-col :span="4"><el-input v-model="ruleForm.execution_way.day_of_week" placeholder="周，默认 *" style="width: 100%" size="small" /></el-col>
                <el-col :span="4"><el-input v-model="ruleForm.execution_way.year" placeholder="年，默认 *" style="width: 100%" size="small" /></el-col>
              </el-row>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer" style="text-align: center">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="submitSaveTask('ruleForm')">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </el-card>
  </div>
</template>

<script>
import moment from 'moment'
import waves from '@/directive/waves' // waves directive

import {
  taskList,
  crontabTaskList,
  createCrontabTask,
  deleteCrontabTask,
  switchCrontabTask
} from '@/api/celeryTasks'

export default {
  name: 'Classification',
  directives: { waves },
  filters: {
    formatDate: function(date) {
      return moment.utc(date).format('YYYY-MM-DD HH:mm:ss')
    }
  },
  data() {
    return {
      allTaskList: [],
      tableKey: 0,
      list: null,
      listLoading: true,
      dialogFormVisible: false,
      ruleForm: {
        execution_way: {
          year: '*',
          day_of_week: '*',
          month: '*',
          day: '*',
          hour: '*',
          minute: '1',
          second: '1'
        },
        task_name: '',
        name: '',
        remarks: ''
      },
      rules: {
        execution_way: [
          { required: true, message: '请输入执行时间', trigger: 'blur' }
        ],
        task_name: [
          { required: true, message: '请选择任务', trigger: 'change' }
        ],
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    // 启停定时任务
    handleSwitch(row) {
      switchCrontabTask({
        job_id: row.id,
        status: row.next_run_time === null ? 1 : 0
      }).then(response => {
        this.getList()
      })
    },
    submitSaveTask() {
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          createCrontabTask(this.ruleForm).then(response => {
            this.getList()
            this.dialogFormVisible = false
          })
        }
      })
    },
    // 任务列表
    getList() {
      this.listLoading = true
      crontabTaskList().then(response => {
        this.list = response.data
        this.listLoading = false
      })
    },
    getTaskList() {
      taskList().then(response => {
        this.allTaskList = response.data
      })
    },
    // 新建任务
    handleCreate() {
      this.getTaskList()
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['ruleForm'].clearValidate()
      })
    },
    // 删除任务
    handleDelete(row, index) {
      this.$confirm('此操作将删除该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteCrontabTask(
          { job_id: row.id }
        ).then(response => {
          this.getList()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  }
}
</script>

<style scoped>
  .text {
    font-size: 14px;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  .clearfix:after {
    clear: both
  }
</style>
