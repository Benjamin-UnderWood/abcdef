## 版本要求
```bash
node >= v12 （稳定版本）
npm >= v6.14.8
```

## 部署
```bash
# 拉取代码
git clone https://github.com/51Reboot/devopsweb.git

# 使用cnpm安装依赖
cd devopsweb
npm install -g cnpm --registry=https://registry.npm.taobao.org
cnpm install

# 编译
npm run build:prod
```

## Nginx 配置
```bash
server {
  listen 18892;
  server_name _;

  location /api {
    proxy_pass http://localhost:18891;
  }

  location / {
    root /51Reboot/bsc/devopsweb/dist;
    index index.html index.htm;
    try_files $uri $uri/ /index.html =404;
    add_header Access-Control-Allow-Origin *;
    add_header Access-Control-Allow-Methods 'GET, POST, PUT, DELETE, OPTIONS';
    add_header Access-Control-Allow-Headers 'DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Authorizat
ion';
    if ($request_method = 'OPTIONS') {
      return 204;
    }
  }

  error_page 500 502 503 504 /50x.html;
  location = /50x.html {
    root html;
  }
}
```
