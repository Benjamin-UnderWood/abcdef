!function () {
    window._CLOUDA_HASHMAP_ = {}, window._CLOUDA_HASHMAP_.res = {
        "device/accelerometer": {src: "/s/accelerometer_84625ae.js"},
        "device/activity": {src: "/s/activity_b4ae78d.js"},
        "device/battery": {src: "/s/battery_62f9a9a.js"},
        "device/cache": {src: "/s/cache_64434ac.js"},
        "device/compass": {src: "/s/compass_15c89de.js"},
        "device/connection": {src: "/s/connection_d6a5864.js", pkg: "/pkg/connection-database-interceptor_9592762.js"},
        "device/contact": {src: "/s/contact_9719ace.js"},
        "device/database": {src: "/s/database_f8493f4.js", pkg: "/pkg/connection-database-interceptor_9592762.js"},
        "device/device": {src: "/s/device_1c3ccfe.js"},
        "device/fs": {src: "/s/fs_581e9e9.js", pkg: "/pkg/fs-media_46b55f4.js"},
        "device/geolocation": {src: "/s/geolocation_8d41e6c.js"},
        "device/globalization": {src: "/s/globalization_a9147bd.js"},
        "device/gyro": {src: "/s/gyro_1f24b9b.js"},
        "device/interceptor": {
            src: "/s/interceptor_c739c9e.js",
            pkg: "/pkg/connection-database-interceptor_9592762.js"
        },
        "device/keyboard": {src: "/s/keyboard_5a415bf.js"},
        "device/localStorage": {src: "/s/localStorage_17a6703.js"},
        "device/media": {src: "/s/media_7055dfc.js", pkg: "/pkg/fs-media_46b55f4.js"},
        "device/notification": {src: "/s/notification_eef2b0f.js"},
        "device/orientation": {src: "/s/orientation_36e568a.js"},
        "device/qr": {src: "/s/qr_ff8e6b9.js"},
        "device/screen": {src: "/s/screen_e87a873.js"},
        "lego/boostNativeBgPageDataSender": {src: "/s/boostNativeBgPageDataSender_f57c01f.js"},
        "lego/boostNativeBgPageDataSender_v2.1": {src: "/s/boostNativeBgPageDataSender_v2.1_003668e.js"},
        "lego/boostNativeSmartBar": {src: "/s/boostNativeSmartBar_73d8e46.js"},
        "lego/boostNativeSmartBar_v2.0": {src: "/s/boostNativeSmartBar_v2.0_22b3e59.js"},
        "lego/boostNativeSmartBar_v2.1": {src: "/s/boostNativeSmartBar_v2.1_b00a5a4.js"},
        "lego/boostNativeSmartBar_v2.2": {src: "/s/boostNativeSmartBar_v2.2_bdb8d5e.js"},
        "lego/boostNativeSmartBar_v2.3": {src: "/s/boostNativeSmartBar_v2.3_c335a55.js"},
        "lego/monitor": {src: "/s/monitor_17191c7.js", pkg: "/pkg/helper-utils-moplus-monitor_cccb3ce.js"},
        "lego/o2oSmartBar": {src: "/s/o2oSmartBar_f5fee65.js"},
        "lego/smartBar": {src: "/s/smartBar_a84ba96.js", pkg: "/pkg/push-smartBar_f0a0b3a.js"},
        "lib/helper": {src: "/s/helper_e16d823.js", pkg: "/pkg/helper-utils-moplus-monitor_cccb3ce.js"},
        "lib/moplus": {src: "/s/moplus_57541ba.js", pkg: "/pkg/helper-utils-moplus-monitor_cccb3ce.js"},
        "lib/o2o": {src: "/s/o2o_061d704.js"},
        "lib/utils": {src: "/s/utils_74ec880.js", pkg: "/pkg/helper-utils-moplus-monitor_cccb3ce.js"},
        "mbaas/account": {src: "/s/account_d54829c.js", pkg: "/pkg/account-pay_6c1fe41.js"},
        "mbaas/alipay": {src: "/s/alipay_63cd99c.js"},
        "mbaas/app": {src: "/s/app_2488902.js", pkg: "/pkg/app-socialshare_b5c9f0e.js"},
        "mbaas/consult": {src: "/s/consult_275e3fe.js"},
        "mbaas/face": {src: "/s/face_b1e114e.js"},
        "mbaas/feedback": {src: "/s/feedback_818dd59.js"},
        "mbaas/map": {src: "/s/map_4a0eeb0.js"},
        "mbaas/mbaas": {src: "/s/mbaas_cf1f6f9.js"},
        "mbaas/pay": {src: "/s/pay_9571121.js", pkg: "/pkg/account-pay_6c1fe41.js"},
        "mbaas/pcs": {src: "/s/pcs_c6de68a.js"},
        "mbaas/player": {src: "/s/player_ec5a980.js"},
        "mbaas/push": {src: "/s/push_976656f.js", pkg: "/pkg/push-smartBar_f0a0b3a.js"},
        "mbaas/socialshare": {src: "/s/socialshare_b9595c8.js", pkg: "/pkg/app-socialshare_b5c9f0e.js"},
        "mbaas/subscribe": {src: "/s/subscribe_0bfdf59.js"},
        "mbaas/vtt_tts": {src: "/s/vtt_tts_76814d8.js"},
        "ui/BlendUI": {src: "/s/BlendUI_46c857a.js"},
        "ui/BlendWebUI": {src: "/s/BlendWebUI_7de2650.js"}
    }
}();
;!function (e, n) {
    function t(e, t) {
        function r() {
            m[e] = !0, b.debug || o.removeChild(a);
            var n = e.slice(0, -3).replace(w, ""), r = x.pop(), i = y[r];
            i && n !== r && (y[n] = {alias: r}), a = null;
            var l = _[e] || [], u = null;
            if (l.length > 0) {
                for (; u = l.shift();) u && u();
                _[e] = null
            }
            t && t()
        }

        if (u(m, e)) t && t(); else if (u(_, e)) _[e] = _[e] || [], _[e].push(t); else {
            _[e] = [];
            var o = n.getElementsByTagName("head")[0], a = n.createElement("script");
            a.type = "text/javascript", a.charset = "utf-8", a.src = e, a.setAttribute("_md_", "_anymoore_" + e), o.appendChild(a), s(t) && (n.addEventListener ? a.addEventListener("load", r, !1) : a.onreadystatechange = function () {
                /loaded|complete/.test(a.readyState) && (a.onreadystatechange = null, r())
            })
        }
    }

    function r(n) {
        var t = null;
        if ("undefined" != typeof e._CLOUDA_HASHMAP_.res) {
            var r = e._CLOUDA_HASHMAP_.res[n] || {};
            t = r.pkg ? r.pkg : r.src || n
        }
        return t = ".js" !== t.slice(-3) ? t + ".js" : t, w = "http:" === window.location.protocol ? "http://apps.bdimg.com/cloudaapi" : "https://openapi.baidu.com/cloudaapi", -1 !== t.indexOf("http://") || -1 !== t.indexOf("https://") ? t : t = w + t
    }

    function o(e, n) {
        var o = i(e, "weak") || {};
        if (u(o, "exports")) return void n(e);
        var a = null;
        if ("undefined" != typeof r) a = r(e); else {
            var s = l(e);
            a = ".js" !== s.slice(-3) ? s + ".js" : s
        }
        a && t(a, function () {
            n(e)
        })
    }

    function a(e) {
        var n = [];
        if (e && e.length > 0) for (var t = 0, r = e.length; r > t; t++) "require" !== e[t] && "exports" !== e[t] && "module" !== e[t] && n.push(e[t]);
        return n
    }

    function i(e, n) {
        var n = n || "strong";
        if (!e || !u(y, e)) return "strong" !== n ? {} : (d('%c_moduleMap中不存在该模块: "' + e + '"', "color:red"), !1);
        var t = y[e];
        return u(t, "alias") && (t = y[t.alias]), t
    }

    function l(e) {
        var n = [];
        if (-1 !== e.indexOf("://")) return e;
        n = e.split("/"), e = [];
        for (var t = 0, r = n.length; r > t; t++) "." !== n[t] && (".." === n[t] ? e.length >= 2 && e.pop() : e.length && "" === n[t] || e.push(n[t]));
        return e = e.join("/")
    }

    function u(e, n) {
        return g.hasOwnProperty.call(e, n)
    }

    function s(e) {
        return "[object Function]" === h.call(e)
    }

    function f(e) {
        return "[object Array]" === h.call(e)
    }

    function c(e) {
        return "[object Object]" === h.call(e)
    }

    function d() {
        if (b.debug) {
            var n = Array.prototype.slice;
            e.console && e.console.log.apply(console, n.call(arguments))
        }
    }

    var p, v, g = Object.prototype, h = g.toString, y = {}, m = {}, _ = {}, x = [], j = 0, b = {debug: 1, ts: 0},
        w = "";
    ("undefined" == typeof e._define_ || "undefined" == typeof e._require_) && (v = function (e, n, t) {
        if (!u(y, e)) {
            if (s(e) || f(e) || c(e)) {
                var r = "_anonymous_mod_" + j++;
                1 === arguments.length ? (t = e, n = null) : 2 === arguments.length && (t = n, n = e), e = r
            } else s(n) && 2 === arguments.length && (t = n, n = null);
            y[e] = {id: e, deps: n, factory: t}, x.push(e)
        }
    }, p = function (e, n) {
        function t(e) {
            var n = i(e) || {}, t = [], l = 0;
            if (u(n, "deps") && n.deps && (t = a(n.deps), l = t.length), l > 0) {
                f += l - 1;
                for (var s = 0; l > s; s++) {
                    var c = t[s];
                    o(c, arguments.callee)
                }
            } else --f <= 0 && r()
        }

        function r() {
            if (x.length > 0) for (var t = null; t = x.shift();) t && p.sync(t);
            for (var r = [], o = 0; s > o; o++) r.push(p.sync(e[o]));
            n && n.apply(void 0, r), r = null
        }

        if ("string" == typeof e && (e = [e]), 1 === e.length && 1 === arguments.length) return p.sync(e.join(""));
        var l = a(e), s = l.length, f = s;
        if (s) for (var c = 0; s > c; c++) {
            var d = l[c];
            o(d, t)
        } else r()
    }, p.sync = function (e) {
        var n, t, r, o = [];
        if (!u(y, e)) throw new Error('Required unknown module, id: "' + e + '"');
        if (n = i(e) || {}, u(n, "exports")) return n.exports;
        if (n.exports = t = {}, r = n.deps) for (var a = r.length, l = 0; a > l; l++) {
            var f = r[l];
            o.push("require" === f ? p : "module" === f ? n : "exports" === f ? t : p.sync(f))
        }
        if (c(n.factory)) n.exports = n.factory; else if (s(n.factory)) {
            var d = n.factory.apply(void 0, o);
            void 0 !== d && d !== t && (n.exports = d)
        }
        return n.exports
    }, e._define_ = v, e._require_ = p, "undefined" == typeof e.clouda && (e.clouda = {}), e.clouda.define = v, e.clouda.require = p, v.amd = {}, v.version = "0.9.0")
}(window, document);
;!function (win, doc) {
    function execApiStack(modules) {
        var modulesLen = modules.length;
        if (modulesLen) for (var stackIndex = 0; modulesLen > stackIndex; stackIndex++) eval(modules[stackIndex].func).apply(null, modules[stackIndex].arg)
    }

    function initApiStack(modules) {
        for (var api_tmp, type, i = modules.length - 1; i >= 0; i--) {
            clouda.device || (clouda.device = {}), clouda.mbaas || (clouda.mbaas = {}), clouda.lego || (clouda.lego = {}), api_tmp = device_apis[modules[i]] ? device_apis[modules[i]] : !1;
            var legoApiTmp = lego_apis[modules[i]] ? lego_apis[modules[i]] : !1;
            if (api_tmp ? type = "device" : legoApiTmp ? (type = "lego", api_tmp = legoApiTmp) : (type = "mbaas", api_tmp = mbaas_apis[modules[i]] ? mbaas_apis[modules[i]] : !1), "undefined" == typeof eval("clouda." + type + "['" + modules[i] + "']") && api_tmp) {
                eval("clouda." + type + "['" + modules[i] + "']={}");
                for (var f_str, j = 0, len = api_tmp.length; len > j; j++) f_str = "function(){API_STACK.push({func:'clouda." + type + '["' + modules[i] + '"]["' + api_tmp[j] + "\"]',arg:arguments});}", eval("clouda." + type + "['" + modules[i] + "']['" + api_tmp[j] + "'] =" + f_str)
            }
        }
    }

    function getPathArr(e) {
        for (var t, a = window._CLOUDA_HASHMAP_.res, o = [], i = 0, n = e.length; n > i; i++) t = e[i], a["device/" + t] ? o.push("device/" + t) : a["mbaas/" + t] ? o.push("mbaas/" + t) : a["lego/" + t] ? o.push("lego/" + t) : a["ui/" + t] && o.push("ui/" + t);
        return o
    }

    if ("object" == typeof win) {
        "undefined" == typeof win.clouda && (win.clouda = {}), win.Blend && win.Blend.ui && (clouda.ui = Blend.ui), win.Blend = win.blend = clouda;
        var device_apis = {
            accelerometer: ["get", "startListen", "stopListen"],
            activity: ["start", "checkSupport"],
            battery: ["get", "startListen", "stopListen", "checkSupport"],
            compass: ["get", "startListen", "stopListen"],
            connection: ["get", "checkSupport"],
            contact: ["find", "insert", "update", "remove", "count", "getCursor"],
            device: ["getImei", "getSysVersion", "getDeviceModelName", "getScreenSize", "checkSupport"],
            fs: ["post", "checkSupport", "download", "remove", "removeAll", "getMd5", "unzip", "getSurplusSize", "read", "getInfo"],
            geolocation: ["get", "startListen", "stopListen", "checkSupport"],
            globalization: ["getPreferredLanguage", "dateToString", "stringToDate", "getDatePattern", "getDateNames", "isDayLightSavingsTime", "getFirstDayOfWeek", "numberToString", "getNumberPattern", "getCurrencyPattern", "getlocale", "checkSupport"],
            gyro: ["get", "startListen", "stopListen"],
            localStorage: ["set", "get", "remove", "count", "empty"],
            media: ["captureMedia", "operateMedia", "checkSupport"],
            notification: ["alert", "confirm", "beep", "vibrate", "prompt", "startLoad", "stopLoad", "startProgress", "updateProgress", "stopProgress"],
            qr: ["startCapture", "checkSupport"],
            screen: ["captureScreen", "shareImage", "shareScreen"],
            orientation: ["setOrientation", "checkSupport"],
            keyboard: ["startListenKeyboard", "stopListenKeyboard"],
            database: ["get", "set", "remove", "clear"],
            cache: ["set", "remove"],
            interceptor: ["set", "getUrlList"]
        }, mbaas_apis = {
            account: ["login", "closeLoginDialog", "checkSupport", "bdLogin"],
            app: ["followSite", "checkFollow", "checkSupport"],
            pay: ["init", "doPay", "checkSupport"],
            alipay: ["doThirdPay", "checkSupport"],
            socialshare: ["callShare", "checkSupport", "UCShare"],
            push: ["registerUnicast", "unregisterUnicast", "registerMulticast", "unregisterMulticast", "getUniqueId", "isBind", "checkSupport"],
            vtt: ["init", "showDialog"],
            tts: ["say"],
            subscribe: ["follow", "checkFollow"],
            feedback: ["addFeedback", "getFeedback"],
            player: ["play"],
            consult: ["openConsult"]
        }, lego_apis = {
            smartBar: ["show", "hide", "setViewItems", "setShowViewItem", "setTheme", "adjustPanel"],
            monitor: ["create", "click", "error", "send", "sendSpeed"],
            o2oSmartBar: ["show", "hide", "setData"],
            "boostNativeSmartBar_v2.0": ["show", "hide"],
            "boostNativeSmartBar_v2.1": ["show", "hide"],
            "boostNativeSmartBar_v2.2": ["show", "hide", "sendBackgroundPageData"],
            "boostNativeSmartBar_v2.3": ["show", "hide", "sendBackgroundPageData"]
        }, blendui_apis = {BlendUI: ["ready"], BlendWebUI: ["ready"]};
        win.cloudaapiInitCount || (win.cloudaapiInitCount = {}, cloudaapiInitCount.lightInit = 0, cloudaapiInitCount.load = 0), win.hasOpenJS || (win.hasOpenJS = !1);
        var o2oUAReg = /BaiduRuntimeO2OZone\/([\d\.]+)/i,
            o2oVersion = navigator.userAgent.match(o2oUAReg) ? navigator.userAgent.match(o2oUAReg)[1] : "0",
            API_STACK = [];
        if ("function" != typeof clouda.lightapp && (clouda.lightapp = function (e, t) {
            clouda.lightapp.ak = e;
            var a = ["activity", "battery", "connection", "device", "fs", "geolocation", "globalization", "media", "qr", "account", "app", "pay"];
            clouda.device && clouda.mbaas && clouda.mbaas.pay ? "function" == typeof t && t() : clouda.require(["/s/api-latest"], function () {
                "function" == typeof t && t();
                var e = API_STACK.length;
                if (e) {
                    execApiStack(API_STACK);
                    for (var o = {}, i = 0; i < a.length; i++) o[a[i]] = !0;
                    for (var n = [], i = 0; e > i; i++) {
                        var c = API_STACK[i].func;
                        o[c.split(".")[2]] || n.push(API_STACK[i])
                    }
                    API_STACK = n, o = null, n = null
                }
            }), initApiStack(a)
        }), "function" != typeof clouda.lightInit) {
            var defautAPI = ["monitor", "smartBar"];
            initApiStack(defautAPI), clouda.lightInit = function (e, t) {
                e.ak && (clouda.lightapp.ak = e.ak);
                var a = e.module || [], o = !1;
                if (a.length > 0) {
                    for (var i = 0, n = a.length; n > i; i++) if ("vtt_tts" == a[i]) a.push("vtt"), a.push("tts"); else if ("blendui" == a[i]) {
                        var c = /BlendUI/i;
                        a[i] = c.test(navigator.userAgent) ? "BlendUI" : "BlendWebUI"
                    } else ("subscribe" == a[i] || "pay" == a[i]) && (o = !0);
                    initApiStack(a)
                }
                cloudaapiInitCount.lightInit += 1;
                var r = ["lib/helper", "lib/utils", "lib/moplus", "lego/monitor"];
                o2oVersion >= "2.2" && r.push("lib/o2o"), clouda.require(r, function () {
                    function e() {
                        clouda.require(getPathArr(a), function () {
                            if (cloudaapiInitCount.load += 1, "function" == typeof t && t(), API_STACK.length && cloudaapiInitCount.lightInit === cloudaapiInitCount.load && (execApiStack(API_STACK), API_STACK.length = 0), i[n] && i[n] > 0 && clouda.lego.monitor && clouda.lego.monitor.send) {
                                var e = 1 * new Date - i[n];
                                clouda.lego.monitor.send("comboapi", {dur: e > 0 ? e : 1, mods: encodeURIComponent(n)})
                            }
                        })
                    }

                    var i = {}, n = a.join("|");
                    if (i[n] = 1 * new Date, !win.hasOpenJS && o) {
                        if ("http:" === window.location.protocol) var c = "http://static2.searchbox.baidu.com/static/searchbox/openjs/aio.js?v=201502"; else var c = "https://m.baidu.com/static/searchbox/openjs/aio.js?v=201502";
                        loadScript(c, function () {
                            console.log("openjs loaded"), win.hasOpenJS = !0, e()
                        })
                    } else e()
                })
            }
        }
        var script = doc.getElementsByName("baidu-tc-cerfication");
        if (script.length) for (var l = script.length; l--;) if (script[l].getAttribute("data-appid")) {
            clouda.lightapp.appid = script[l].getAttribute("data-appid");
            break
        }
        var loadScript = function (e, t) {
            var a = document.createElement("script");
            a.setAttribute("src", e), document.head.appendChild(a), a.onload = function () {
                t && t(a)
            }
        };
        !function () {
            clouda.envs || (clouda.envs = {}), (navigator.userAgent.match(/BaiduRuntimeO2OZone/i) || "undefined" != typeof BLightApp) && (clouda.envs.zhidahao = 1), navigator.userAgent.match(/baiduboxapp/i) && (clouda.envs.kuang = 1, navigator.userAgent.match(/light/i) && (clouda.envs.zhidahao = 1))
        }(), clouda.ready = function (e) {
            return "function" != typeof e ? void console.error("clouda.ready need a callback function") : void (clouda.STATUS && 1 == clouda.STATUS.SUCCESS ? e() : document.addEventListener("runtimeready", function () {
                e()
            }))
        }
    }
}(window, document);
;!function () {
    function a() {
        o || (setTimeout(function () {
            for (var a = 0, e = b.length; e > a; a++) try {
                b[a]()
            } catch (c) {
                console.error("callBack exe error", c.stack)
            }
            b = []
        }, 1), o = !0)
    }

    function e(e) {
        if ("complete" == document.readyState || "interactive" == document.readyState) try {
            e(), a()
        } catch (c) {
            console.error("callBack exe error", c.stack)
        } else b.push(e)
    }

    function c(a, e, c) {
        d(a[e], function () {
            1 >= c - e && callBackFn && callBackFn()
        })
    }

    function d(a, e, d) {
        if ("[object Array]" != Object.prototype.toString.apply(a)) {
            var f = document.createElement("script");
            f.onload = function () {
                e && e()
            }, f.onerror = function () {
                e && e(new Error("加载失败"))
            }, f.src = a, f.async = "async", d && d.defer && (f.defer = "defer"), f.type = "text/javascript", f.charset = "utf-8", document.head.appendChild(f)
        } else for (var b = (a.length, 0), o = a.length; o > b; b++) c(a[b], b, o)
    }

    function f(a, e, c) {
        if (null !== a && "undefined" != a || null !== e && "undefined" !== e) {
            clouda.lego.smartBar._cacheAppCallBackFnName = l, window[l] = function (a) {
                a && 0 === a.error_code ? (clouda.lego.smartBar._cacheAppData = a, clouda.lego.smartBar._cacheAppState = "loadEnd", clouda.lightapp.ak = a.app_info.api_key, c && c(a)) : clouda.lego.smartBar._cacheAppState = "loadError"
            }, clouda.lego.smartBar._cacheAppState = "loadStart";
            var f = localStorage.getItem("xnSmartBarCacheKey_" + a), b = {};
            f && (b.defer = !0);
            var o = t;
            a ? (o += "old" === clouda.lego.smartBar.whichAPI ? "?m_code=" + a : "&m_code=" + a, clouda.lego.smartBar.loadDataType = "m_code") : e && (o += "old" === clouda.lego.smartBar.whichAPI ? "?app_id=" + e : "&app_id=" + e, clouda.lego.smartBar.loadDataType = "app_id"), d(o + "&from=lightapp&callback=" + l, function (a) {
                clouda.lego.smartBar._cacheAppState = a ? "loadError" : "loadEnd", setTimeout(function () {
                    delete window[l]
                }, 2e3)
            }, b)
        }
    }

    var b = [], o = !1;
    window.addEventListener("DOMContentLoaded", function () {
        a()
    }), window.addEventListener("load", function () {
        a()
    }), "undefined" != typeof clouda && (clouda.lego || (clouda.lego = {}), clouda.lego.smartBar || (clouda.lego.smartBar = {})), clouda.lego.smartBar._smartBarCSSELID = "xnSmartBarCacheCSSID";
    var l = "xnBBBBBCallBackFn" + parseInt(1e5 * Math.random() + 1e3, 10);
    clouda.lego.smartBar.whichAPI = "new";
    var t = "//m.baidu.com/navbarapp_api?do=get";
    "old" === clouda.lego.smartBar.whichAPI && (t = "//m.baidu.com/lightapp/navbar/get"), clouda.lego.appIdList = [2123454, 2490867, 1953586, 5350162, 6294364, 3492389, 2411856, 5749572, 5430508, 3030261, 2389466, 5081360, 3513433, 4369669, 2387396, 5233476, 6289639, 4552454, 3372687, 6169549, 4875362, 5256896, 5577490, 6546154, 4779811, 5494744, 2130642, 6646844, 5901307, 2130645, 2615211, 4809590, 1019536, 6404184, 4372613, 5817373, 5064247, 3589836, 6357206, 4929950, 5513199, 5388039, 5043106, 5710936, 5194138, 3406137, 5365268, 2344625, 2069028, 5102684, 6613064, 6616414, 2007309, 2299346, 3070534, 6429613, 6215420, 2143484, 5707747, 2383704, 5382981, 4956518, 4303093, 6124617, 4997255, 1638467, 5427765, 5198790, 4523809, 6489306, 5666791, 5013708, 5193267, 6674996, 6485111, 2021142, 5690716, 6608086, 5088085, 5156134, 2337603, 6071156, 6557543, 5411405, 6391757, 4776430, 5227562, 2496967, 5176097, 5174939, 6196749, 6447758, 5576119, 6445208, 3875268, 3319706, 5721472, 5825724, 6588619, 6735123], clouda.lego.mcodeDict = {
        e00ab880947deae29b4d7e40: 1,
        f1898b0e21da3e2d7e316ecf: 1,
        "7928a1522e05e2349bd9ac69": 1,
        f700da3476435c17aebbae0f: 1,
        "0355543f318008c37bdf7c26": 1,
        6417053: 1,
        "8249a165930aa3d9494cab5c": 1,
        af17bc76a50b8852450963eb: 1,
        abad6dcd140e1d49313af8db: 1,
        c8ab8fc7fe9c51f8c2d819cf: 1,
        "000cd7d65546b1bae0347781": 1,
        "420901dc5debff340b9a70cb": 1,
        "34927d330c23c3342133e564": 1,
        "102640bbaf5407211f368900": 1,
        e221d1c7fb52942c3c2a5849: 1,
        f945601a2e37e4121617a7d4: 1,
        cac3b4fcd9a7da506fdc2521: 1,
        db132d476b5aac421618a293: 1,
        dd6293c00b54e940d0e00fd1: 1,
        "05474db5b2698122a1cb42a8": 1,
        d080a1c506a91a3ad503f9c3: 1,
        "0967822052a813f3f961c686": 1,
        dbc58fbd1591beea3c276b3f: 1,
        "74dc122651d815c02b7bdc34": 1,
        c0b6640cd5e161b9c9400e58: 1,
        bda3fed8359d800918648003: 1,
        ee07ad10bc5af4083373f6c1: 1,
        "4eec58dca307b86d0f43d2ae": 1,
        dcbe66f1e3e03300fc1c661d: 1,
        "384bf9ef113cb416e5b0be9c": 1,
        f36ba1a6ed40374151cb3035: 1,
        a531d4a78f29d521b13e0041: 1,
        "6584795318fa4c4326c0d385": 1,
        "01c94f4ff3e2a3187afb3ac9": 1,
        "5da5b83aa60c89c3831d15ed": 1,
        "77203ff2f537c5de0149ff00": 1,
        "05cfd85866b1971a9bfbea89": 1,
        d001ed4115d73e2951f95d9b: 1,
        "143620a2b964e01f3dc3730b": 1,
        "9ae8efe64aeff399a3211781": 1,
        "70c2962b770946548a1383d9": 1,
        ff18da941948ee15e3ed05ad: 1,
        "4335019100eeaa12c7403fb0": 1,
        "62f6c92f56d703333fd3e6d2": 1,
        "3866a1fa47c6ce0fa94bc90a": 1,
        "97552b4da9493930190761f1": 1,
        "5b73b04720549e128b714643": 1,
        "6372702284464bdc7f7b2669": 1,
        bdc151f6a3e3904b6933caae: 1,
        "83962a8e18b3cc03b5bb48c1": 1,
        c5bd8a0e10a2b026011352ee: 1,
        "326bee93ca88723b5122db46": 1,
        "9da0456c01372e439de39351": 1,
        fec6cb28af02efd8894586bf: 1,
        "1ecbe6a2eac6ad3e33ea01b5": 1,
        f92d5001f31295432482447c: 1,
        "8353c30d3d07ac421718a253": 1,
        "87f0d1cfa91940341f6cee3e": 1,
        "833bfe4d1be3187b93eddd33": 1,
        "133e663fdf9475c61456a884": 1,
        "1a8a788a513329e0f925b187": 1,
        "93ade966faf865f00bfcfd40": 1,
        "642ce84078c55d33002dcb06": 1,
        "74b1b23ff113fb559630e879": 1,
        "08354437447b363018076149": 1,
        e7cedfe3a2569e19c3150483: 1,
        "1f7143098362c32bed34e4d0": 1,
        "62dd0b41a24f3b1e68d31e6a": 1,
        f714d4d6add48f011ee8b3f8: 1,
        "47985c311ddeda11c91f72d7": 1,
        "7e192f0d3ac8cbe88dd54ca5": 1,
        "8118e572f415c0faf00a2a7a": 1,
        "641be7ff44013fccf7cbcca3": 1,
        cc528fddba0a88bb61c6af33: 1,
        "4f48bc39c3cc72b9c9400e3a": 1,
        "29e9325d5aa089ed1187ec7a": 1,
        fa464f2695f066717e295cdc: 1,
        "27d249c2de514890ba191b11": 1,
        "298fc17b961e3c1e69d31e96": 1,
        a7fb3f348ab7d0cb4505cd3e: 1,
        e54a6f78a1bddafbe6f3ebb4: 1,
        c2c6a9dad4d9a020f3399533: 1,
        "546daf16fc3ecc1781f9b8af": 1,
        "0515d7ce66c9b0ed354fdeac": 1,
        "1f65ba0122424f224276c4d9": 1,
        "3a194a137892f6bb2b4d4903": 1,
        a70c2eb6fba52056dd29a936: 1,
        a31d200cc81a1ef4baea6a5d: 1,
        "69ce8bc5727c1e3708ccc3d7": 1,
        "0200ce41c19d3d3151386f7f": 1,
        cb49a2bb3de03cccf7cbcc11: 1,
        "79b825fa9e0bc3dfd74a4bf8": 1,
        "047ab52847f818f3f861c661": 1,
        ed214842bc57339eb91909e9: 1,
        ed54a62ddf5f0a0f070065b4: 1,
        "922bb207c699be35e7818ec6": 1,
        b94eb11376fc79089ec55046: 1,
        "8adf50f16e1a08e206f3cfd6": 1,
        cb10f1a4336309a80b580b1e: 1,
        "41e816ad35733a18c334a3e8": 1,
        "429635a50c42276cc755efaf": 1,
        "8202c01525a85833002dcb54": 1,
        "851660d03ec13c07a052628d": 1,
        "837251fb33832317fe8ca04c": 1,
        "8c09c1c7ccb48fed354fde99": 1,
        "57943b0fa22581ea03306058": 1,
        "47756e594963285870e8744c": 1,
        b9f71e8fc560f834caede3e3: 1,
        cf3cbec244716f052fe2ce6e: 1,
        e1058c3aec4a67445661ba2d: 1,
        "7f22f949562ba410f15024d2": 1,
        e32453bbf181fc1f3dc3737a: 1,
        "1b172e33091e3e877834edfd": 1,
        "099a3bc3aed9f4e29b4d7e37": 1,
        "11af00fe673aec99a2211770": 1,
        b419ad796e7f6b7b92edddd5: 1,
        b02caf5696481382b4124508: 1,
        cd03e45e48be20548a13838c: 1,
        "8f1a22ed147ca8bae134775e": 1,
        "4ccd56c9ce2095cbfee843cc": 1,
        "97f63cdffaab2100fc1c661e": 1,
        bbbe67306fcc71f1c812a673: 1,
        fb7ef86b1f9a8a30a31ae999: 1,
        c06cab4f7f816df00bfcfd54: 1,
        "4830640f6445a99f27f46963": 1,
        "4fe80e16a398b15dc834e278": 1,
        "4f60d14adae13cf3ff0fc844": 1,
        "2ba47c6a1551b4cab22f9f8a": 1,
        "27415328305abed96917ad18": 1,
        "70acd24059ef8e659b183939": 1,
        "475b5f52287d8d128a7146fc": 1,
        "154500eb3c88a7e2a0e2d557": 1,
        fc950b674dcffeed1087ec36: 1,
        "6fd8a03ecaf27fb9c9400e65": 1,
        ff141adad7320417fe8ca033: 1,
        "61d74209547c342d7f316e06": 1,
        "2f43a009fcfbaf187afb3a82": 1,
        "1388adbae7c3376cc755ef20": 1,
        d23f2e29da726a4c942094ad: 1,
        "5b5c6f17803e49c61456a8b0": 1,
        "0390dd4a0e8429439ce393fd": 1,
        daa73f6fff6025e894e8bc4f: 1,
        "1bebdd1be6fe8be191ba7626": 1,
        "07a94eb66578993e32ea0109": 1,
        a73544eac276e803b5bb488c: 1,
        "18a97a8c86447d7dadd88560": 1,
        b901529d4c1121a80a580b56: 1,
        "89acf8eafe11735547295534": 1,
        "1f36d4b3947b35fb4b74d0af": 1,
        "7a9d3a3cbd694233012dcb7f": 1
    }, clouda.lego._initSmartBar = function (a, c) {
        e(function () {
            if (!clouda.lego.smartBar._cacheAppState) {
                if (c && clouda.lego.appIdList && -1 !== clouda.lego.appIdList.indexOf(c)) return void (clouda.lego.monitor && clouda.lego.monitor.send && clouda.lego.monitor.send("diyEv", {
                    name: "LIGHTAPP_FILTER_LIGHTAPP_APPID",
                    value: c
                }));
                if (a && clouda.lego.mcodeDict && 1 === clouda.lego.mcodeDict[a]) return void (clouda.lego.monitor && clouda.lego.monitor.send && clouda.lego.monitor.send("diyEv", {
                    name: "LIGHTAPP_FILTER_LIGHTAPP_MCODE",
                    value: a
                }));
                clouda.lego.mAppId = a, f(a, c), clouda.lightInit({
                    ak: null,
                    module: ["smartBar", "app", "push", "socialshare"]
                })
            }
        })
    }, clouda.lightapp.appid && (clouda.lego.monitor && clouda.lego.monitor.create && clouda.lego.monitor.create(clouda.lightapp.appid, 0, 1, !0), clouda.lego._initSmartBar(null, clouda.lightapp.appid))
}();
;void function (t, e) {
    function n(t) {
        var e = String(window.document.location.href), n = new RegExp("(^|)" + t + "=([^&]*)(&|$)", "gi").exec(e);
        return n ? n[2] : 0
    }

    function i(t, n, i) {
        i = i || 15;
        var o = new Date;
        o.setTime((new Date).getTime() + 1e3 * i);
        try {
            e.cookie = t + "=" + escape(n) + ";path=/;expires=" + o.toGMTString()
        } catch (a) {
        }
    }

    function o(t) {
        var n = e.cookie.match(new RegExp("(^| )" + t + "=([^;]*)(;|$)"));
        return null !== n ? unescape(n[2]) : null
    }

    function a(t, e) {
        for (var n = 0; e;) {
            if ((e.nodeName || e.tagName).toLowerCase() === t.toLowerCase()) return e;
            if (n >= 4) return null;
            n++, e = e.parentNode
        }
        return null
    }

    function r() {
        var t = n("bd_ts"), a = 0, r = e.referrer, s = +new Date, d = o("bd_hash"), c = o("bd_st");
        if (c) {
            try {
                i("bd_st", "", -1), c = JSON.parse(c.substr(1, c.length - 2))
            } catch (_) {
                c = {}
            }
            c.r && r.replace(/#.*/, "").slice(-50) != c.r || (a = c.s)
        } else r.indexOf("baidu.com") > -1 && t > 0 && 7 == String(t).length && d != t && (i("bd_hash", t, 30), a = parseInt((s + "").slice(0, 6) + t, 10));
        return s - a >= 2e4 && (a = 0), a
    }

    function s(t, e) {
        for (var n in t) n && (e[n] = t[n]);
        return e
    }

    window.bd || (window.bd = {}), window.bd._qdc = {
        _v: 1,
        _timing: {},
        _random: Math.random(),
        _st: r(),
        _is_send: !1,
        _opt: {
            sample: .5,
            log_path: "http:" === window.location.protocol ? "http://static.tieba.baidu.com/tb/opms/img/st.gif" : "https://gsp0.baidu.com/5aAHeD3nKhI2p27j8IqW0jdnxx1xbK/tb/opms/img/st.gif",
            items: ["lt"]
        },
        _check: function () {
            for (var t = this._opt.items, e = this._timing, n = !0, i = t.length - 1; i >= 0; i--) e.hasOwnProperty(t[i]) || (n = !1);
            n && this.send()
        },
        init: function (t) {
            s(t, this._opt), t && t.app_id && "undefined" != typeof clouda && (clouda.lego || (clouda.lego = {}), clouda.lego._initSmartBar && clouda.lego._initSmartBar(t.app_id))
        },
        mark: function (t, e) {
            this._st > 0 && (this._timing[t] = e || +new Date - this._st, this._check())
        },
        first_screen: function () {
            var t = document.getElementsByTagName("img"), e = +new Date, n = [], i = this;
            this._setFS = function () {
                for (var t = i._opt.fsHeight || document.documentElement.clientHeight, o = 0; o < n.length; o++) {
                    var a = n[o], r = a.img, s = a.time, d = r.offsetTop || 0;
                    d > 0 && t > d && (e = s > e ? s : e)
                }
                i._timing.fs = e - i._st
            };
            for (var o = function () {
                this.removeEventListener && this.removeEventListener("load", o, !1), n.push({
                    img: this,
                    time: +new Date
                })
            }, a = 0; a < t.length; a++) {
                var r = t[a];
                r.addEventListener && !r.complete && r.addEventListener("load", o, !1)
            }
        },
        send: function () {
            if (this._random < this._opt.sample && this._st > 0 && !this._is_send) {
                this._is_send = !0;
                var t = this._timing, e = [];
                for (var n in t) e.push(n + "=" + t[n]);
                e.push("_t=" + 1 * new Date);
                var i = document.createElement("img");
                i.src = this._opt.log_path + "?type=bdapp&v=" + this._v + "&app_id=" + this._opt.app_id + "&" + e.join("&")
            }
        }
    }, e.addEventListener("DOMContentLoaded", function () {
        bd._qdc.mark("drt")
    }, !1), t.addEventListener("load", function () {
        "function" == typeof bd._qdc._setFS && bd._qdc._setFS(), bd._qdc.mark("lt")
    }), e.addEventListener("click", function (t) {
        t = t || window.event;
        var n = t.target || t.srcElement, o = a("a", n);
        if (o) {
            var r = o.getAttribute("href");
            /^#|javascript:/.test(r) || i("bd_st", '({"s":' + +new Date + ',"r":"' + e.URL.replace(/#.*/, "").slice(-50) + '"})')
        }
    }, !1), bd._qdc.mark("ht")
}(window, document);