<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>Agent注册审批</span>
      </div>
      <div class="text item">
        <div class="filter-container">
          <el-input v-model="listQuery.name" placeholder="请输入内容" style="width: 300px;" class="filter-item" @keyup.enter.native="handleFilter" />
          <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">
            搜索
          </el-button>
        </div>

        <el-table
          :key="tableKey"
          v-loading="listLoading"
          :data="list"
          border
          fit
          highlight-current-row
          style="width: 100%; margin-top: 12px"
        >
          <el-table-column label="ID">
            <template slot-scope="{row}">
              <span>{{ row.id }}</span>
            </template>
          </el-table-column>
          <el-table-column label="AgentID">
            <template slot-scope="{row}">
              <span>{{ row.agent_id }}</span>
            </template>
          </el-table-column>
          <el-table-column label="IP地址">
            <template slot-scope="{row}">
              <span>{{ row.ipaddress }}</span>
            </template>
          </el-table-column>
          <el-table-column label="创建时间">
            <template slot-scope="{row}">
              <span>{{ row.create_time | formatDate }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" align="center" width="230" class-name="small-padding fixed-width">
            <template slot-scope="{row}">
              <el-button type="primary" size="mini" @click="handleAgree(row)">
                通过
              </el-button>
              <el-button size="mini" type="danger" @click="handleIgnore(row)">
                忽略
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

      </div>
    </el-card>
  </div>
</template>

<script>
import moment from 'moment'
import waves from '@/directive/waves' // waves directive
import Pagination from '@/components/Pagination'
import {
  registerApplyList,
  agreeRegisterApply,
  ignoreRegisterApply
} from '@/api/system' // secondary package based on el-pagination

export default {
  name: 'Classification',
  components: { Pagination },
  directives: { waves },
  filters: {
    formatDate: function(date) {
      return moment.utc(date).format('YYYY-MM-DD HH:mm:ss')
    }
  },
  data() {
    return {
      listQuery: {
        page: 1,
        limit: 10
      },
      listLoading: true,
      tableKey: 0,
      list: null,
      total: 0
    }
  },
  created() {
    this.getList()
  },
  methods: {
    handleFilter() {
      this.listQuery.page = 1
    },
    getList() {
      this.listLoading = true
      registerApplyList(this.listQuery).then(response => {
        this.list = response.data.list
        this.total = response.data.total
        this.listLoading = false
      })
    },
    handleAgree(row) {
      agreeRegisterApply({
        agent_id: row.agent_id
      }).then(response => {
        this.getList()
      })
    },
    handleIgnore(row) {
      this.$confirm('此操作将忽略Agent的注册数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        ignoreRegisterApply({
          id: row.id
        }).then(() => {
          this.getList()
          this.$message({
            type: 'success',
            message: '已忽略!'
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消'
        })
      })
    }
  }
}
</script>
