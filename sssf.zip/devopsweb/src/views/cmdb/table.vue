<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>表管理</span>
      </div>
      <div class="text item">
        <div class="filter-container">
          <el-input v-model="listQuery.name" placeholder="请输入表名称" style="width: 300px;" class="filter-item" @keyup.enter.native="handleFilter" />
          <el-button v-waves class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">
            搜索
          </el-button>
          <el-button class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-edit" @click="handleCreate">
            新建
          </el-button>
        </div>

        <el-table
          :key="tableKey"
          v-loading="listLoading"
          :data="list"
          border
          fit
          highlight-current-row
          style="width: 100%; margin-top: 12px"
        >
          <el-table-column label="ID">
            <template slot-scope="{row}">
              <span>{{ row.id }}</span>
            </template>
          </el-table-column>
          <el-table-column label="名称">
            <template slot-scope="{row}">
              <span>{{ row.name }}</span>
            </template>
          </el-table-column>
          <el-table-column label="别名">
            <template slot-scope="{row}">
              <span>{{ row.alias }}</span>
            </template>
          </el-table-column>
          <el-table-column label="类型">
            <template slot-scope="{row}">
              <span>{{ row.classification_name }}</span>
            </template>
          </el-table-column>
          <el-table-column label="创建时间">
            <template slot-scope="{row}">
              <span>{{ row.create_time | formatDate }}</span>
            </template>
          </el-table-column>
          <el-table-column label="更新时间">
            <template slot-scope="{row}">
              <span>{{ row.update_time | formatDate }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" align="center" width="230" class-name="small-padding fixed-width">
            <template slot-scope="{row,$index}">
              <el-button type="success" size="mini" @click="handleDetails(row)">
                详情
              </el-button>
              <el-button type="primary" size="mini" @click="handleUpdate(row)">
                编辑
              </el-button>
              <el-button size="mini" type="danger" @click="handleDelete(row,$index)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

        <el-dialog :title="textMap[dialogStatus]==='Create'?'新建表': '编辑表'" :visible.sync="dialogFormVisible">
          <el-form
            ref="dataForm"
            :rules="rules"
            :model="temp"
            label-position="left"
            label-width="70px"
            style="margin-left:50px; width: 90%;"
          >
            <el-form-item label="名称" prop="name">
              <el-input v-model="temp.name" size="small" placeholder="请输入名称" />
            </el-form-item>
            <el-form-item label="别名" prop="alias">
              <el-input v-model="temp.alias" size="small" placeholder="请输入别名" />
            </el-form-item>
            <el-form-item label="类型" prop="classification">
              <el-select v-model="temp.classification" filterable placeholder="请选择类型" style="width: 100%" size="small">
                <el-option
                  v-for="(citem, cindex) in classificationOptions"
                  :key="cindex"
                  :label="citem.name"
                  :value="citem.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="备注">
              <el-input v-model="temp.remarks" type="textarea" size="small" placeholder="请输入备注" />
            </el-form-item>
            <el-form-item label="字段" prop="fields">
              <div
                v-for="(item, index) in temp.fields"
                :key="index"
              >
                <el-input v-model="item.name" style="width: 110px" size="small" placeholder="名称: name" />
                <el-input v-model="item.alias" style="width: 110px" size="small" placeholder="别名: 名称" />
                <el-select v-model="item.type" clearable filterable placeholder="请选择类型" size="small" style="width: 130px">
                  <el-option
                    v-for="(item1, index1) in typeOptions"
                    :key="index1"
                    :label="item1.label"
                    :value="item1.value"
                  />
                </el-select>
                <el-checkbox v-model="item.required" style="margin-left: 20px; margin-right: 20px">必填</el-checkbox>
                <el-input v-model="item.remarks" style="width: 120px" size="small" placeholder="备注描述" />
                <el-button
                  v-if="index===0"
                  type="primary"
                  icon="el-icon-circle-plus"
                  style="margin-left: 9px;"
                  size="small"
                  @click="addFields"
                />
                <el-button
                  v-if="index!==0"
                  type="danger"
                  icon="el-icon-remove"
                  size="small"
                  style="margin-left: 9px;"
                  @click.prevent="removeFields(item)"
                />
              </div>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer" style="text-align: center">
            <el-button @click="dialogFormVisible = false">
              关闭
            </el-button>
            <el-button type="primary" @click="dialogStatus==='create'?createData():updateData()">
              提交
            </el-button>
          </div>
        </el-dialog>
      </div>
    </el-card>

    <el-dialog title="表详情" :visible.sync="dialogTableVisible">
      <el-form :inline="true" :model="tableDetails" class="demo-form-inline" label-width="100px">
        <el-form-item label="ID: " style="width: 40%; margin-bottom: 0">
          {{ tableDetails.id }}
        </el-form-item>
        <el-form-item label="名称: " style="width: 40%; margin-bottom: 0">
          {{ tableDetails.name }}
        </el-form-item>
        <el-form-item label="别名: " style="width: 40%; margin-bottom: 0">
          {{ tableDetails.alias }}
        </el-form-item>
        <el-form-item label="类型: " style="width: 40%; margin-bottom: 0">
          {{ tableDetails.classification_name }}
        </el-form-item>
        <el-form-item label="备注: " style="width: 100%; margin-bottom: 0">
          {{ tableDetails.remarks }}
        </el-form-item>
        <el-form-item label="创建时间: " style="width: 40%">
          {{ tableDetails.create_time | formatDate }}
        </el-form-item>
        <el-form-item label="更新时间: " style="width: 40%">
          {{ tableDetails.update_time | formatDate }}
        </el-form-item>
      </el-form>
      <el-table :data="tableDetails.fields">
        <el-table-column property="name" label="名称" />
        <el-table-column property="alias" label="别名" />
        <el-table-column property="type" label="类型" />
        <el-table-column property="required" :formatter="formatBoolean" label="必填" />
        <el-table-column property="remarks" label="备注" />
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import moment from 'moment'
import waves from '@/directive/waves' // waves directive
import Pagination from '@/components/Pagination'
import {
  classificationList,
  createTable,
  tableList,
  updateTable,
  deleteTable
} from '@/api/cmdb' // secondary package based on el-pagination

export default {
  name: 'Classification',
  components: { Pagination },
  directives: { waves },
  filters: {
    formatDate: function(date) {
      return moment.utc(date).format('YYYY-MM-DD HH:mm:ss')
    }
  },
  data() {
    return {
      tableDetails: '',
      dialogTableVisible: false,
      typeOptions: [
        { label: '单行输入框', value: 'input' },
        { label: '多行输入框', value: 'textarea' },
        { label: '日期', value: 'date' },
        { label: '日期时间', value: 'datetime' }
      ],
      tableKey: 0,
      list: null,
      classificationOptions: null,
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      },
      temp: {
        id: undefined,
        name: '',
        alias: '',
        classification: '',
        remarks: '',
        fields: [{
          name: '',
          alias: '',
          type: '',
          required: false,
          remarks: ''
        }]
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: 'Edit',
        create: 'Create'
      },
      rules: {
        name: [{ required: true, message: '名称不能为空', trigger: 'blur' }],
        alias: [{ required: true, message: '昵称不能为空', trigger: 'blur' }],
        classification: [{ required: true, message: '类型必须选择', trigger: 'change' }],
        fields: [{ required: true, message: '字段不能为空', trigger: 'blur' }]
      }
    }
  },
  created() {
    this.getList()
    this.getClassificationList()
  },
  methods: {
    formatBoolean: function(row, column, cellValue) {
      var ret = '' // 你想在页面展示的值
      if (cellValue) {
        ret = '是' // 根据自己的需求设定
      } else {
        ret = '否'
      }
      return ret
    },
    handleDetails(row) {
      this.tableDetails = row
      this.dialogTableVisible = true
    },
    removeFields(item) {
      var index = this.temp.fields.indexOf(item)
      if (index !== -1) {
        this.temp.fields.splice(index, 1)
      }
    },
    addFields() {
      this.temp.fields.push({
        name: '',
        alias: '',
        type: '',
        required: false,
        remarks: ''
      })
    },
    getList() {
      this.listLoading = true
      tableList(this.listQuery).then(response => {
        this.list = response.data.list
        this.total = response.data.total
        this.listLoading = false
      })
    },
    getClassificationList() {
      var jsonParams = {
        page: 1,
        limit: 999999
      }
      classificationList(jsonParams).then(response => {
        this.classificationOptions = response.data.list
      })
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    resetTemp() {
      this.temp = {
        id: undefined,
        name: '',
        alias: '',
        classification: '',
        remarks: '',
        fields: [{
          name: '',
          alias: '',
          type: '',
          required: false,
          remarks: ''
        }]
      }
    },
    handleCreate() {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          createTable(this.temp).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '创建成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.temp = Object.assign({}, row) // copy obj
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          updateTable(this.temp).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '更新成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleDelete(row, index) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteTable(
          { 'id': row.id }
        ).then(() => {
          this.getList()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  }
}
</script>

<style>
  .table-details-dev {
    border: 1px solid red;
    height: 100px;
  }
  .table-details-dev > div {
    border: 1px solid red;
    width: 50%;
    height: 100%;
    float: left;
  }

  .text {
    font-size: 14px;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  .clearfix:after {
    clear: both
  }

  .el-dialog__body {
    padding-bottom: 0;
  }

  #app > div > div.main-container > section > div > div.el-dialog__wrapper > div > div.el-dialog__body {
    padding-bottom: 30px;
  }
</style>
