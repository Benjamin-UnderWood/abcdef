<template>
    <!--author Jack qq:774428957-->
    <div class="app-container">
        <div class="filter-container">
            <el-button type="primary" plain @click="handleCreate">增加</el-button>
            <el-input v-model="listQuery.search" placeholder="请输入内容" style="width: 200px;"></el-input>
            <el-button type="primary" plain @click="handleFilter">搜索</el-button>
        </div>
        <el-table
                v-loading="listLoading"
                :key="tableKey"
                :data="list"
                border
                fit
                highlight-current-row
                style="width: 100%">
            <el-table-column :label="'英文名'">
                <template slot-scope="scope">
                    <span class="link-type">{{ scope.row.name }}</span>
                </template>
            </el-table-column>
            <el-table-column label="中文名">
                <template slot-scope="scope">
                    <span class="link-type">{{ scope.row.cname }}</span>
                </template>
            </el-table-column>
            <el-table-column label="备注信息">
                <template slot-scope="scope">
                    <span class="link-type">{{ scope.row.remark }}</span>
                </template>
            </el-table-column>
            <el-table-column label="创建时间">
                <template slot-scope="scope">
                    <span class="link-type">{{ scope.row.create_time }}</span>
                </template>
            </el-table-column>
            <el-table-column label="修改时间">
                <template slot-scope="scope">
                    <span class="link-type">{{ scope.row.update_time }}</span>
                </template>
            </el-table-column>
            <el-table-column class-name="small-padding fixed-width" fixed="right"
                             label="操作">
                <template slot-scope="scope">
                    <el-button type="primary" size="mini" @click="handleUpdate(scope.row)">编辑</el-button>
                    <el-button v-if="scope.row.status!='deleted'" size="mini" type="danger"
                               @click="handleDelete(scope.row.id)">删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>

        <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.pagesize"
                    @pagination="getList"/>

        <el-dialog :title="dialogStatus" :visible.sync="dialogFormVisible" :close-on-click-modal='false'>
            <el-form ref="dataForm" :rules="rules" :model="temp" label-position="left" label-width="100px"
                     style="width: 80%; margin-left:50px;">
                <el-form-item label="英文名"  prop="name">
                    <el-input v-model="temp.name"></el-input>
                </el-form-item>
                <el-form-item label="中文名"  prop="cname">
                    <el-input v-model="temp.cname"></el-input>
                </el-form-item>
                <el-form-item label="备注" prop="remark">
                    <el-input type="textarea" v-model="temp.remark"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false" size="mini">取消</el-button>
                <el-button v-show="dialogStatus!='detail'" type="primary"
                           @click="dialogStatus==='create'?createData():updateData()" size="mini">提交
                </el-button>
            </div>
        </el-dialog>

        <!-- 删除提示框 -->
        <el-dialog :title="dialogStatus" :visible.sync="delVisible" width="300px">
            <div class="del-dialog-cnt">删除不可恢复，是否确定删除？</div>
            <span slot="footer" class="dialog-footer">
        <el-button @click="delVisible = false">取 消</el-button>
        <el-button type="primary" @click="deleteData()">确 定</el-button>
      </span>
        </el-dialog>

    </div>
</template>

<script>
    import {Workflowgroup as masterApi} from '@/api/workflow'
    import waves from '@/directive/waves' // Waves directive
    import Pagination from '@/components/Pagination' // Secondary package based on el-pagination

    export default {
        name: 'workflow_group',
        components: {Pagination},
        directives: {waves},
        data() {
            return {
                delVisible: false,
                textMap: {
                    update: 'Edit',
                    create: 'Create',
                    delete: 'Delete'
                },
                dialogStatus: 'create',
                tableKey: 0,
                list: null,
                total: 0,
                listLoading: false,
                listQuery: {
                    page: 1,
                    pagesize: 30,
                    name: undefined,
                    ordering: '-id',
                    search: ''
                },
                temp: {
                    id: undefined,
                    name: undefined,
                    cname: undefined,
                    remark: undefined,
                },
                dialogFormVisible: false,
                rules: {
                    name: [{required: true, message: 'name is required', trigger: 'blur'}],
                    cname: [{required: true, message: 'cname is required', trigger: 'blur'}],
                },

            }
        },
        created() {
            //进来就给我获取列表
            this.getList()
        },
        methods: {
            //获取列表
            getList() {
                //调用后端
                this.listLoading = true
                masterApi.list(this.listQuery).then(response => {
                    this.list = response['results']
                    this.total = response['count']
                    this.listLoading = false
                })
            },
            handleFilter() {
                console.log(this.listQuery)
                this.getList()
            },
            handleCreate() {
                this.dialogFormVisible = true
                this.resetTemp()
                this.dialogStatus = 'create'
            },
            handleUpdate(row) {
                this.dialogFormVisible = true
                this.resetTemp()
                this.dialogStatus = 'update'
                this.temp = Object.assign({}, row)
            },
            handleDelete(id) {
                this.resetTemp()
                this.temp.id = id
                this.delVisible = true
            },
            resetTemp() {
                this.temp = {
                    id:undefined,
                    name: undefined,
                    cname: undefined,
                    remark: undefined,
                }
            },
            createData() {
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        masterApi.create(this.temp).then(() => {
                            this.dialogFormVisible = false
                            this.getList()
                            this.notice('成功', 'create成功')
                        })
                    }
                })
            },
            updateData() {
                masterApi.patch(this.temp.id, this.temp).then(() => {
                    this.dialogFormVisible = false
                    this.getList()
                    this.notice('成功', 'update成功')
                })
            },
            deleteData() {
                masterApi.delete(this.temp.id).then(() => {
                    this.getList()
                    this.notice('成功', 'delete成功')
                    this.delVisible = false
                })
            },
            notice(title, msg) {
                this.$notify({
                    title: title,
                    message: msg,
                    type: 'success',
                    duration: 2000
                })
            }
        }
    }
</script>
