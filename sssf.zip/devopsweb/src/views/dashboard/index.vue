<template>
  <div class="dashboard-container">
    <div class="dashboard-text" style="text-align: center; margin-top: 50px; font-size: 50px;">
      欢 迎 登 陆 本 系 统
    </div>
    <!-- <div class="dashboard-text" style="text-align: center; margin-top: 50px; font-size: 30px;">
      本系统基本架构如下：
    </div>
    <div style="text-align: center; margin-top: 20px;">
      <img src="@/styles/images/WechatIMG202.png" width="820" height="530">
    </div>
    <div class="dashboard-text" style="text-align: center; margin-top: 50px; font-size: 30px;">
      项目基本信息如下：
    </div>
    <div style="text-align: center; margin-top: 20px;">
      <img src="@/styles/images/WechatIMG2.jpeg" width="820">
    </div> -->
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'Dashboard',
  computed: {
    ...mapGetters([
      'name'
    ])
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
