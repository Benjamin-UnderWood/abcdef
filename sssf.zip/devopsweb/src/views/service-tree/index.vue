<template>
  <!-- padding: 内部标签（儿子级别的）跟自己相距15个像素 -->
  <div style="padding: 15px">
    <!-- 布局 24：100%-->
    <el-row>
      <el-col :span="5">
        <div class="grid-content bg-purple-dark">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>服务树</span>
              <el-button style="float: right; padding: 3px 0" type="text" @click="addTopNode">新建</el-button>
            </div>
            <div class="text item">
              <!-- node-click 这个事件是为了后面查询cmdb绑定数据，预留的扩展方法 -->
              <el-tree
                :data="treeValue"
                @node-click="handleNodeClick"
                @node-contextmenu="handleContextMenu"
              >
                <!-- 添加插槽 -->
                <template slot-scope="{ node }">
                  <span v-contextmenu:contextmenu style="font-size: 15px">
                    {{ node.label }}
                  </span>
                </template>
              </el-tree>
              <template>
                <v-contextmenu ref="contextmenu">
                  <v-contextmenu-item @click="addNode">新建节点</v-contextmenu-item>
                  <v-contextmenu-item @click="editNode">编辑节点</v-contextmenu-item>
                  <v-contextmenu-item @click="deleteNode">删除节点</v-contextmenu-item>
                </v-contextmenu>
              </template>
            </div>
          </el-card>
        </div>
      </el-col>
      <el-col :span="19">
        <div class="grid-content bg-purple-dark" style="margin-left: 10px">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>CMDB</span>
              <el-button style="float: right; padding: 3px 0" type="text" @click="bindCmdbInit">绑定</el-button>
            </div>
            <div class="text item">
              <el-tabs v-if="currentNode.id !== undefined" type="border-card">
                <el-tab-pane v-for="(bindClassifyItem, bindClassifyIndex) in bindClassifyList" :key="bindClassifyIndex" :label="bindClassifyItem.name">
                  <el-tag
                    style="cursor: pointer;"
                    v-for="(bindClassifyTableItem, bindClassifyTableIndex) in bindClassifyTableList"
                    :key="bindClassifyTableIndex"
                    @click="getTableDataFunction(bindClassifyItem.id, bindClassifyTableItem.id)"
                  >
                    {{ bindClassifyTableItem.alias }}
                  </el-tag>
                  <div>
                    <el-table
                      :data="bindTableData"
                      border
                      style="width: 100%; margin-top: 10px"
                    >
                      <el-table-column
                        v-for="(tableItem, tableIndex) in bindTableDetails.fields"
                        :key="tableIndex"
                        :prop="tableItem.name"
                        :label="tableItem.alias"
                      />
                      <el-table-column
                        fixed="right"
                        label="操作"
                        width="120"
                      >
                        <template slot-scope="scope">
                          <el-button
                            type="text"
                            size="small"
                            @click.native.prevent="deleteBindData(bindClassifyItem.id, bindTableDetails.id, scope.row)"
                          >
                            移除
                          </el-button>
                        </template>
                      </el-table-column>
                    </el-table>
                    <!-- <el-pagination
                      style="margin-top: 10px"
                      :current-page="currentPage4"
                      :page-sizes="[100, 200, 300, 400]"
                      :page-size="100"
                      layout="total, sizes, prev, pager, next, jumper"
                      :total="400"
                      @size-change="handleSizeChange"
                      @current-change="handleCurrentChange"
                    /> -->
                  </div>
                </el-tab-pane>
              </el-tabs>
              <div v-else style="border-radius: 4px; border: 1px solid #ddd; height: 100px; line-height: 100px; text-align: center; color: #999; font-size: 25px;">
                暂未选中节点
              </div>
            </div>
          </el-card>
        </div>
      </el-col>
    </el-row>
    <el-dialog :title="status==='create'?'新建节点':'编辑节点'" :visible.sync="dialogFormVisible">
      <el-form ref="form" :model="form" :rules="rules">
        <el-form-item label="节点名称" label-width="100px" prop="label">
          <el-input v-model="form.label" autocomplete="off" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="status==='create'?addNodeSubmit():editNodeSubmit()">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="绑定CMDB" :visible.sync="dialogCmdbVisible">
      <el-form :model="cmdbForm" label-width="100px">
        <el-form-item label="资产分类">
          <el-select v-model="cmdbForm.classify" placeholder="请选择资产分类" style="width: 95%" @change="getClassifyTables">
            <el-option
              v-for="item in classifyOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="资产模型">
          <el-select v-model="cmdbForm.table" placeholder="请选择资产模型" style="width: 95%" @change="getTableData">
            <el-option
              v-for="item in tableOptions"
              :key="item.id"
              :label="item.alias"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="资产列表">
          <el-table
            v-if="tableData.length !== 0"
            ref="multipleTable"
            :data="tableData"
            border
            style="width: 100%"
            tooltip-effect="dark"
            @selection-change="handleSelectionChange"
          >
            <el-table-column
              type="selection"
              width="55"
            />
            <el-table-column
              v-for="(tableItem, tableIndex) in tableDetails.fields"
              :key="tableIndex"
              :prop="tableItem.name"
              :label="tableItem.alias"
            />
          </el-table>
          <div v-else style="border-radius: 4px; border: 1px solid #ddd; height: 100px; line-height: 100px; text-align: center; color: #999; font-size: 25px;">
            暂无数据
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogCmdbVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogCmdbVisible = false">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

import Vue from 'vue'
import contentmenu from 'v-contextmenu'
import 'v-contextmenu/dist/index.css'
Vue.use(contentmenu)

import {
  treeData,
  createTreeNode, // 新建节点
  deleteTreeNode, // 删除节点
  updateTreeNode, // 编辑节点
  cmdbTableDetails, // cmdb模型详情
  getBindClassifyList, // 获取绑定的分类列表
  getBindClassifyTableList, // 获取绑定的分类列表对应的模型累表
  getBindTableDataList, // 获取模型对应的数据
  deleteBind, // 解除数据绑定
  bindCmdbData // 绑定cmdb数据
} from '@/api/service-tree'

import {
  classificationList,
  classificationTable,
  dataList
} from '@/api/cmdb'

import { lang } from 'moment'

/*
  1. 树的管理，增删改查
     - 公司 --
       - 部门
         - 业务 （人脸识别，轨迹查询等等）
           - 集群
             - 模块 上线升级。 -> 按钮（上线） -> 10台cmdb机器 -> 任务 -> 上线 -> 返回结果
  2. 绑定cmdb数据
  --------------------------

  Todo List
  3. 绑定jenkins，上线发布
  4. 关连任务。 -> 业务的批处理。
*/

export default {
  components: {

  },
  data() {
    return {
      bindClassifyList: [],
      bindClassifyTableList: [],
      classifyOptions: [],
      tableOptions: [],
      tableData: [],
      bindTableData: [],
      tableDetails: {},
      bindTableDetails: {},
      cmdbForm: {},
      treeValue: [],
      currentNode: {},
      status: 'create',
      dialogFormVisible: false,
      dialogCmdbVisible: false,
      currentPage4: 0,
      form: {
        label: ''
      },
      rules: {
        label: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ]
      }
    }
  },
  // 数据渲染之前执行的钩子函数
  created() {
    this.getTreeData()
  },
  methods: {
    // 获取树结构的数据
    getTreeData() {
      treeData().then(response => {
        this.treeValue = response.data
      })
    },
    // 绑定数据的初始化动作
    bindCmdbInit() {
      // 获取cmdb资产分类列表
      classificationList().then(response => {
        this.classifyOptions = response.data.list
        this.dialogCmdbVisible = true

        // 清空之前的处理
        this.cmdbForm = {}
        this.tableData = []
      })
    },
    // 解除绑定
    deleteBindData(classify_id, table_id, row) {
      deleteBind({
        service_tree: this.currentNode.id,
        classify: classify_id,
        table: table_id,
        data_id: row.data_id
      }).then(response => {
        this.getTableDataFunction(classify_id, table_id)
      })
    },
    // 获取分类对应的模型列表
    getClassifyTables() {
      classificationTable({
        id: this.cmdbForm.classify
      }).then(response => {
        this.tableOptions = response.data
      })
    },
    getTableData() {
      this.tableData = []
      cmdbTableDetails(this.cmdbForm.table).then(response => {
        this.tableDetails = response.data
        dataList({
          limit: 99999,
          table_id: this.cmdbForm.table
        }).then(response => {
          for (var d of response.data.list) {
            d.value.data_id = d.id
            this.tableData.push(d.value)
          }
        })
      })
    },
    handleSelectionChange(selection) {
      if (this.currentNode.id === undefined || this.currentNode.id === null) {
        this.$message({ type: 'error', message: '未选中节点' })
      } else {
        var params = {
          service_tree: this.currentNode.id,
          classification: this.cmdbForm.classify,
          table: this.cmdbForm.table,
          data: selection[selection.length - 1].data_id
        }
        bindCmdbData(params).then(response => {

        })
      }
    },
    handleCurrentChange() {},
    handleSizeChange() {},

    // 获取数据
    getTableDataFunction(classify_id, table_id) {
      this.bindTableData = []
      cmdbTableDetails(table_id).then(response => { // 查询表结构
        this.bindTableDetails = response.data
        getBindTableDataList({
          service_tree: this.currentNode.id,
          classify: classify_id,
          table: table_id
        }).then(response => {
          for (var d of response.data) {
            d.value.data_id = d.id
            this.bindTableData.push(d.value)
          }
        })
      })
    },

    // 第一次点击节点的时候，获取数据的。
    handleNodeClick(data, node, event) {
      // 预留查询其他系统的方法
      // console.log(data, node, event)
      this.bindTableData = []
      this.currentNode = data
      getBindClassifyList(this.currentNode.id).then(response => {
        this.bindClassifyList = response.data
        getBindClassifyTableList({
          service_tree: this.currentNode.id,
          classify: this.bindClassifyList[0].id
        }).then(response => {
          this.bindClassifyTableList = response.data
          this.getTableDataFunction(this.bindClassifyList[0].id, this.bindClassifyTableList[0].id)
        })
      })
    },
    // 获取当前节点的数据，并且绑定到公共变量
    handleContextMenu(enent, data, node, self) {
      // 右键绑定当前节点的数据
      this.currentNode = data
    },
    // 初始化form表单数据
    resetForm() {
      this.form = {
        id: undefined,
        label: ''
      }
    },
    // 新建顶层节点
    addTopNode() {
      this.resetForm()
      // id, label, parent, level
      this.status = 'create'
      this.form.id = undefined
      this.form.parent = 0
      this.form.level = 1
      this.dialogFormVisible = true
      this.$nextTick(() => { // 去掉之前的验证信息
        this.$refs['form'].clearValidate()
      })
    },
    // 新建节点
    addNode() {
      this.resetForm()

      // id, label, parent, level
      // 生成请求的参数
      this.status = 'create'
      this.form.parent = this.currentNode.id
      this.form.level = this.currentNode.level + 1
      this.dialogFormVisible = true
      this.$nextTick(() => { // 去掉之前的验证信息
        this.$refs['form'].clearValidate()
      })
    },
    // 新建节点请求方法
    addNodeSubmit() {
      this.$refs['form'].validate((valid) => { // 验证
        if (valid) {
          createTreeNode(this.form).then(response => {
            this.getTreeData()
            this.dialogFormVisible = false
          })
        }
      })
    },
    // 编辑节点
    editNode() {
      this.form = this.currentNode
      this.status = 'edit'
      this.dialogFormVisible = true
      console.log(this.form)
    },
    // 编辑节点请求方法
    editNodeSubmit() {
      this.$refs['form'].validate((valid) => { // 验证
        if (valid) {
          updateTreeNode({
            id: this.currentNode.id,
            label: this.form.label
          }).then(response => {
            this.getTreeData()
            this.dialogFormVisible = false
          })
        }
      })
    },
    // 删除节点
    deleteNode() {
      this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteTreeNode(this.currentNode.id).then(response => {
          this.getTreeData()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  }
}
</script>

<style scoped>

</style>
