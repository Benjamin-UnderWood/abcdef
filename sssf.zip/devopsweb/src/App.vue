<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import axios from 'axios'
import { getToken } from '@/utils/auth'

export default {
  name: 'App',
  created() {
    axios.defaults.headers.common[
      'Authorization'
    ] = `JWT ` + getToken()
  }
}
</script>
