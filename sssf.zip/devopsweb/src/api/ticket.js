import request from '@/utils/request'

// 任务列表
export function upcomingTicketList(params) {
  return request({
    url: '/api/v1/ticket/',
    method: 'get',
    params
  })
}
