import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'
/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: 'Dashboard',
      component: () => import('@/views/dashboard/index'),
      meta: { title: '首页', icon: 'dashboard' }
    }]
  },
  // {
  //   path: '/book',
  //   component: Layout,
  //   name: '图书管理系统',
  //   meta: {
  //     title: '图书管理系统',
  //     icon: 'example'
  //   },
  //   children: [
  //     {
  //       path: 'classification',
  //       name: 'classification',
  //       component: () => import('@/views/book/book'),
  //       meta: { title: '图书', icon: 'form' }
  //     },
  //     {
  //       path: 'table',
  //       name: 'table',
  //       component: () => import('@/views/book/author'),
  //       meta: { title: '作者', icon: 'form' }
  //     },
  //     {
  //       path: 'data',
  //       name: 'data',
  //       component: () => import('@/views/book/public'),
  //       meta: { title: '出版商', icon: 'form' }
  //     }
  //   ]
  // },
  {
    path: '/cmdb',
    component: Layout,
    name: '资源管理',
    meta: {
      title: '资源管理',
      icon: 'example'
    },
    children: [
      {
        path: 'classification',
        name: 'classification',
        component: () => import('@/views/cmdb/classification'),
        meta: { title: '分类管理', icon: 'form' }
      },
      {
        path: 'table',
        name: 'table',
        component: () => import('@/views/cmdb/table'),
        meta: { title: '表管理', icon: 'form' }
      },
      {
        path: 'data',
        name: 'data',
        component: () => import('@/views/cmdb/data'),
        meta: { title: '数据管理', icon: 'form' }
      }
    ]
  },
  {
    path: '/task',
    component: Layout,
    name: '任务管理',
    meta: {
      title: '任务管理',
      icon: 'task'
    },
    children: [
      {
        path: 'task-manager',
        name: 'task-manager',
        component: () => import('@/views/celeryTasks/task-manager'),
        meta: { title: '任务管理', icon: 'form' }
      },
      {
        path: 'crontab-task',
        name: 'crontab-task',
        component: () => import('@/views/celeryTasks/crontab-task'),
        meta: { title: '定时任务', icon: 'form' }
      },
      {
        path: 'task-history',
        name: 'task-history',
        component: () => import('@/views/celeryTasks/task-history'),
        meta: { title: '任务历史', icon: 'form' }
      }
    ]
  },
  {
    path: '/service-tree',
    component: Layout,
    name: '服务树',
    meta: {
      title: '服务树',
      icon: 'tree'
    },
    children: [
      {
        path: 'index',
        name: 'index',
        component: () => import('@/views/service-tree/index'),
        meta: { title: '服务树', icon: 'tree' }
      }
    ]
  },


  {
  path: '/workflow',
  component: Layout,
  redirect: '/workflow/workorders/',
  name: '工单系统',
  meta: {
    title: '工单系统',
    icon: 'form'
  },
  children: [
    {
      path: 'workorders',
      component: () => import('@/views/workflow/workorders'),
      name: '工单',
      meta: {title: '工单'}
    },
     {
      path: 'workorderswaiting',
      component: () => import('@/views/workflow/workorderswaiting'),
      name: '工单审批',
      meta: {title: '工单审批'}
    },
    {
      path: 'workordershistory',
      component: () => import('@/views/workflow/workordershistory'),
      name: '工单历史',
      meta: {title: '工单历史'}
    },
    {
      path: 'workflows',
      component: () => import('@/views/workflow/workflows'),
      name: '工作流配置',
      meta: {title: '工作流配置'}
    },
    {
      path: 'workflowgroup',
      component: () => import('@/views/workflow/workflowgroup'),
      name: '工作组管理',
      meta: {title: '工作组管理'},
      hidden:true,
    },


    {
      path: 'formfields',
      component: () => import('@/views/workflow/formfields'),
      name: '工单项管理',
      meta: {title: '工单项管理'},
      hidden: true,
    },
    {
      path: 'auditsteps',
      component: () => import('@/views/workflow/auditSteps'),
      name: '审批流管理',
      meta: {title: '审批流管理'},
      hidden: true,
    },

  ]
},
  // {
  //   path: '/task',
  //   component: Layout,
  //   name: '任务管理',
  //   meta: {
  //     title: '任务管理',
  //     icon: 'task'
  //   },
  //   children: [
  //     {
  //       path: 'task-manager',
  //       name: 'task-manager',
  //       component: () => import('@/views/task/task-manager'),
  //       meta: { title: '任务管理', icon: 'form' }
  //     },
  //     {
  //       path: 'timing-task',
  //       name: 'timing-task',
  //       component: () => import('@/views/task/timing-task'),
  //       meta: { title: '定时任务', icon: 'form' }
  //     },
  //     {
  //       path: 'execute-history',
  //       name: 'agent-list',
  //       component: () => import('@/views/task/execute-history'),
  //       meta: { title: '执行历史', icon: 'form' }
  //     }
  //   ]
  // },
  // {
  //   path:'/bastion',
  //   component:Layout,
  //   name:'堡垒机管理',
  //   meta:{
  //     title:"堡垒机管理",
  //     icon:'settings'
  //   },
  //   children:[
  //       {
  //         path:'account-manager',
  //         name:'account-manager',
  //         component:()=> import('@/views/bastion/account'),
  //         meta:{ title : '帐户管理', icon: 'form' }
  //       },
  //       {
  //         path:'permission-manger',
  //         name:'permission-manger',
  //         component:()=> import('@/views/bastion/permission'),
  //         meta:{ title: '帐户权限管理', icon: 'form' }
  //       },
  //       {
  //         path:'auditor',
  //         name:'auditor',
  //         component:()=> import('@/views/bastion/auditor'),
  //         meta:{ title: '安全审计', icon:'settings' }
  //       }
  //   ]
  // },
  // {
  //   path: '/system',
  //   component: Layout,
  //   name: '系统管理',
  //   meta: {
  //     title: '系统管理',
  //     icon: 'settings'
  //   },
  //   children: [
  //     {
  //       path: 'register-apply',
  //       name: 'register-apply',
  //       component: () => import('@/views/system/register-apply'),
  //       meta: { title: 'Agent审批', icon: 'form' }
  //     },
  //     {
  //       path: 'agent-list',
  //       name: 'agent-list',
  //       component: () => import('@/views/system/agent-list'),
  //       meta: { title: 'Agent列表', icon: 'form' }
  //     }
  //   ]
  // },




  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router


