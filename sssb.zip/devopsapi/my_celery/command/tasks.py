#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

"""
执行shell命令，包括脚本
"""

import subprocess
# import logging
from my_celery.run import app  # Celery 实例对象

from my_celery.callback_task import MyTask


# log = logging.getLogger("django")


@app.task(base=MyTask)
def exec_command(command):
    """
    :param command: 用户传递的命令
    :return:
    """
    try:
        _, output = subprocess.getstatusoutput(command)
    except Exception as e:
        output = str(e)
    return output  # 会把任务执行的结果存入到对应的celery存储中，按照这个项目的话，就是存入到redis
