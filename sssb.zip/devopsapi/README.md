## 版本要求

- Python 3.6.8+
- Django 2.2+
- Django rest framework
- MySQL 5.7
- Redis 3.2.11+

## 安装项目依赖包
```bash
# virtualenv .venv
# source .venv/bin/activate
# pip install -r requirements.txt
# make migrate
```

## 启动方式

- 启动 Django
```bash
# make run
or 
# python manage.py runserver 0.0.0.0:800
```

- 启动 Celery scheduler
```bash
# celery -A devops beat -l info
```

- 启动 Celery Worker
```bash
# celery -A devops worker -l info
```

- 启动 Celery Flower
```bash
# celery -A devops flower -l info
```