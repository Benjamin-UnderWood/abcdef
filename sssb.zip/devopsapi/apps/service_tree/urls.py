#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

from django.urls import path
from apps.service_tree import views


urlpatterns = [
    # 分类管理
    path("service-tree", views.ServiceTree.as_view(), name="service-tree"),
    path("cmdb-table-details", views.CmdbTableDetails.as_view(), name="cmdb-table-details"),
    path("bind-cmdb-data", views.BindCmdbData.as_view(), name="bind-cmdb-data"),
    path("get-bind-classify", views.GetBindClassify.as_view(), name="get-bind-classify"),
    path("get-bind-classify-table", views.GetBindClassifyTable.as_view(), name="get-bind-classify-table"),
    path("get-bind-table-data", views.GetBindTableData.as_view(), name="get-bind-table-data"),
    path("delete-bind", views.DeleteBind.as_view(), name="delete-bind")
]
