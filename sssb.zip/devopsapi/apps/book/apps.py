from django.apps import AppConfig


class BookConfig(AppConfig):
    name = 'apps.book'
    verbose_name = '图书管理系统'
