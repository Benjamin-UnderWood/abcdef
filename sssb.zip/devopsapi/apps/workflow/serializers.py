# -*- coding: utf-8 -*-
# author Jack qq:774428957
from rest_framework import serializers
from django.contrib.auth import get_user_model
from apps.workflow.models import *

User = get_user_model()

class WorkFlowGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkFlowGroup
        fields = '__all__'



class WorkFlowSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkFlow
        fields = '__all__'
    def to_representation(self, instance):
        ret = super().to_representation(instance)
        # step_instances = AuditStep.objects.filter(workflow=instance).order_by('order_num')
        # ret['steps'] = '->'.join([row.role.cname for row in step_instances])

        #instance ---> workflow
        #groupid=3 groupname
        print(instance.group)
        ret['group_cname'] = None if not instance.group else instance.group.cname
        ret['is_automatic'] = True if instance.script else False
        return ret


class AuditStepSerializer(serializers.ModelSerializer):
    role = serializers.PrimaryKeyRelatedField(label="角色", help_text="角色", required=False, queryset=Role.objects.all())

    class Meta:
        model = AuditStep
        fields = '__all__'

    def create(self, validated_data):
        instance = super().create(validated_data=validated_data)
        workflow = validated_data['workflow']
        last_instance = workflow.auditstep_set.order_by('order_num').last()
        if last_instance: instance.order_num = last_instance.order_num + 1
        instance.save()
        return instance

    def to_representation(self, instance):  #回填  role用户都返回回去,遍历role把信息添加回去
        ret = super().to_representation(instance)
        role_instance = instance.role
        user_list = []
        for u in role_instance.users.all():
            user_list.append({'username': u.username, 'cname': u.name, 'phone': u.phone, 'id': u.id})
        role_data = {'name': role_instance.name, 'cname': role_instance.cname,'users': user_list}
        ret['role'] = role_data
        return ret

class FormFieldSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormField
        fields = '__all__'

    def create(self, validated_data):
        instance = super().create(validated_data=validated_data)
        workflow = validated_data['workflow']
        last_instance = workflow.formfield_set.order_by('order_num').last()
        if last_instance: instance.order_num = last_instance.order_num + 1
        instance.save()
        return instance


class OpenApiSerializer(serializers.Serializer):
    pass