import os
import pathlib
import time

from rest_framework.views import APIView
from utils.api_response.api_response import api_response
from utils.task.get_file_name import get_file_name
from my_celery.command.tasks import exec_command
from my_celery.remote_command.tasks import exec_command as remote_exec_command
from apps.celery_tasks import models
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from my_celery.run import app
from celery.result import AsyncResult
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore, register_events
from utils.add_execute_task.add_execute_task import add_execute_task
from uuid import uuid4

scheduler = BackgroundScheduler()
scheduler.add_jobstore(DjangoJobStore())
scheduler.start()


# 任务管理
class TaskManager(APIView):

    def get(self, request):
        """ 获取文件列表 """

        try:
            file_list = []
            dir_obj = pathlib.Path("./scripts")
            for d in dir_obj.iterdir():
                f = pathlib.Path(d)
                """
                    1. 脚本文件名称
                    2. 属主
                    3. 属组
                    4. 创建时间
                    5. 更新时间
                """
                file_list.append({
                    "name": f.name,
                    "owner": f.owner(),
                    "group": f.group(),
                    "create_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(f.stat().st_ctime)),
                    "update_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(f.stat().st_mtime)),
                })

            return api_response(data=file_list)
        except Exception as e:
            return api_response(10400, str(e))

    def post(self, request):
        """ 创建任务 """

        try:

            # 校验出参数对应的文件，不能出现已 '.' 活着 '/' 开头
            # ../create_task.py, /create_task.py
            # 获取任务名称
            result, status = get_file_name(request.data)
            if not status:
                return api_response(10400, result)
            # 获取任务内容
            file_content = request.data.get("content", "")
            if file_content == "":
                return api_response(10400, "任务内容不能为空，请确认content是否传递")
            # os.getcwd() 项目的根目录，result文件名称
            task_path = f"{os.getcwd()}/scripts/{result}"
            # pathlib
            # 创建一个pathlib文件对象
            file_obj = pathlib.Path(task_path)
            # 判断用户是否存在
            if file_obj.exists():
                return api_response(10400, f"任务<{result}>已经存在")
            # 创建任务文件
            file_obj.touch(mode=0o755)
            file_obj.write_text(file_content)  # 写入任务文件内容

            return api_response()
        except Exception as e:
            return api_response(10400, str(e))

    def put(self, request):
        try:

            result, status = get_file_name(request.data)
            if not status:
                return api_response(10400, result)

            file_content = request.data.get("content", "")
            if file_content == "":
                return api_response(10400, "任务内容不能为空")

            # 生成实例
            update_file_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")

            # 判断文件是否存在
            if not update_file_obj.exists():
                return api_response(10400, f"任务{result}，不存在")

            # 更新文件
            update_file_obj.write_text(file_content)

            return api_response()
        except Exception as e:
            return api_response(10400, str(e))

    def delete(self, request):
        """ 删除任务 """

        try:

            result, status = get_file_name(request.GET)
            if not status:
                return api_response(10400, result)

            delete_file_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")
            delete_file_obj.unlink()

            return api_response()
        except Exception as e:
            return api_response(10400, str(e))


# 任务详情
class TaskDetails(APIView):
    def get(self, request):
        """ 获取任务详情 """

        try:

            result, status = get_file_name(request.GET)
            if not status:
                return api_response(10400, result)

            read_content_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")
            file_content = read_content_obj.read_text()

            return api_response(data=file_content)
        except Exception as e:
            return api_response(10400, str(e))


def test_callback():
    print("51reboot")


# 立即执行命令
class ExecCommand(APIView):
    def post(self, request):
        try:

            """
                title: 简要描述此次执行命令的标题
                ip_list: 执行命令的机器列表
                command：命令的内容
            """

            # target_ip_list = request.data.get("ips", "").split(",")  # 假如这个是cmdb传递过来的ip地址
            title = request.data.get("title", "")
            ip_list = request.data.get("ip_list", "")
            command = request.data.get("command", "")
            if title == "" or command == "":
                return api_response(10400, "command和title都必须传递")

            # for ip in target_ip_list:

            exec_result = remote_exec_command.delay(ip_list, command)  # 异步命令

            result = AsyncResult(id=exec_result.id, app=app)

            print(result.status)

            models.TaskHistory.objects.create(**{
                "title": title,
                "task_id": exec_result.id,
                "task_type": "立即执行命令",
                "task_status": result.status
            })

            return api_response()
        except Exception as e:
            return api_response(10400, str(e))


# 立即执行任务
class ExecTask(APIView):
    def post(self, request):
        try:

            """
                name: 任务名称
            """

            result, status = get_file_name(request.data)
            if not status:
                return api_response(10400, result)

            task_script_path = f"{os.getcwd()}/scripts/{result}"

            exec_task_obj = pathlib.Path(f"{os.getcwd()}/scripts/{result}")
            if not exec_task_obj.exists():
                return api_response(10400, "任务脚本不存在")

            exec_task_command = task_script_path

            if task_script_path.endswith(".py"):
                exec_task_command = f"python {task_script_path}"

            exec_result = exec_command.delay(exec_task_command)  # 异步命令

            # result = AsyncResult(id=exec_result.id, app=app)
            # print(result.get())  # 同步命令

            models.TaskHistory.objects.create(**{
                "title": result,
                "task_id": exec_result.id,
                "task_type": "立即执行任务"
            })

            return api_response()
        except Exception as e:
            return api_response(10400, str(e))


# 历史记录
class TaskHistory(APIView):
    def get(self, request):
        try:
            contact_list = models.TaskHistory.objects.all().order_by("-id")
            paginator = Paginator(contact_list, 10)  # 每页显示10条

            page = request.GET.get('page')
            try:
                contacts = paginator.page(page)
            except PageNotAnInteger:
                # 如果请求的页数不是整数，返回第一页。
                contacts = paginator.page(1)
            except EmptyPage:
                # 如果请求的页数不在合法的页数范围内，返回结果的最后一页。
                contacts = paginator.page(paginator.num_pages)
            return api_response(data={
                "total": paginator.count,
                "list": list(contacts.object_list.values()),
            })
        except Exception as e:
            return api_response(10400, str(e))


# 通过任务ID，将任务历史的执行结果返回
class TaskHistoryResult(APIView):
    def get(self, request):
        try:

            task_id = request.GET.get("task_id", "")
            if task_id == "":
                return api_response(10400, "task_id必须传递")

            result = AsyncResult(id=task_id, app=app)

            return api_response(data=result.get())
        except Exception as e:
            return api_response(10400, str(e))


# 定时任务
class CrontabTask(APIView):
    def get(self, request):
        """ 定时任务列表 """
        try:

            task_list = []
            job_list = scheduler.get_jobs()
            for j in job_list:
                tmp_dict = {
                    "id": j.id,
                    "next_run_time": j.next_run_time,
                    "name": "",
                    "remarks": ""
                }
                job_info_list = models.CrontabTask.objects.filter(task_id=j.id)
                if len(job_info_list) > 0:
                    tmp_dict["name"] = job_info_list[0].name
                    tmp_dict["remarks"] = job_info_list[0].remarks
                task_list.append(tmp_dict)

            return api_response(data=task_list)
        except Exception as e:
            return api_response(10400, str(e))

    def post(self, request):
        """ 创建定时任务 """
        try:

            task_name = request.data.get("task_name", "")
            execution_way = request.data.get("execution_way", "")
            name = request.data.get("name", "")
            remarks = request.data.get("remarks", "")
            if task_name == "" or execution_way == "":
                return api_response(10400, "task_name或者execution_way参数必须传递")

            # 定时任务job id
            task_id = uuid4().hex

            # apschudels注册定时任务
            scheduler.add_job(
                add_execute_task,
                "cron",
                args=[f"./scripts/{task_name}"],
                id=task_id,
                **execution_way
            )

            # 注册任务
            register_events(scheduler)

            models.CrontabTask.objects.create(**{
                "task_id": task_id,
                "name": name,
                "remarks": remarks
            })

            return api_response()
        except Exception as e:
            return api_response(10400, str(e))

    def delete(self, request):
        """ 删除定时任务 """

        try:
            scheduler.remove_job(request.GET.get("job_id", ""))
            return api_response()
        except Exception as e:
            return api_response(10400, str(e))

    def put(self, request):
        try:
            job_id = request.data.get("job_id", "")
            if job_id == "":
                return api_response(10400, "job_id必须传递")

            status = int(request.data.get("status", -1))
            if status == 1:
                scheduler.resume_job(job_id)
            elif status == 0:
                scheduler.pause_job(job_id)
            return api_response()
        except Exception as e:
            return api_response(10400, str(e))
