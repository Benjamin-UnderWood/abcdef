import os


class Config(object):
    """Base config class."""
    DEBUG = True


class DevelopmentConfig(Config):
    """Development config class."""
    DEBUG = True

    # MYSQL Default
    MYSQL_HOST = "192.168.163.241"
    MYSQL_PORT = 3306
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "123"
    MYSQL_DB = "devops"
    MYSQL_CHARSET = "utf8mb4"
    MYSQL_UNIX_SOCKET = ""

    # REDIS
    REDIS_HOST = "127.0.0.1"
    REDIS_PORT = 6579
    REDIS_PASSWORD = "zhangsan"

    PROJECT_INFO_URL = 'http://192.168.163.134:9000'
    TASK_WAITING = "task_waiting_list"

    # bastion
    bastion_server_url = "http://127.0.0.1:8080/account_create/"


class ProductionConfig(Config):
    """Production config class."""
    DEBUG = False

    # MYSQL Default
    MYSQL_HOST = "192.168.163.241"
    MYSQL_PORT = 3306
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "123"
    MYSQL_DB = "devops"
    MYSQL_CHARSET = "utf8mb4"
    MYSQL_UNIX_SOCKET = ""

    # REDIS
    REDIS_HOST = "127.0.0.1"
    REDIS_PORT = 6579
    REDIS_PASSWORD = "zhangsan"

    PROJECT_INFO_URL = 'http://192.168.163.134:9000'
    TASK_WAITING = "task_waiting_list"


if os.environ.get("APIEnviron", 'dev') == 'release':
    Config = ProductionConfig()
else:
    Config = DevelopmentConfig()