import request from '@/utils/request'

// 获取树结构
export function getTreeData() {
  return request({
    url: '/api/v1/tree',
    method: 'get'
  })
}

// 创建节点
export function createNode(data) {
  return request({
    url: '/api/v1/tree/',
    method: 'post',
    data
  })
}

// 编辑节点
export function editNode(id, data) {
  return request({
    url: `/api/v1/tree/${id}`,
    method: 'put',
    data
  })
}

// 删除节点
export function deleteNode(id) {
  return request({
    url: `/api/v1/tree/${id}`,
    method: 'delete'
  })
}

// 查询节点对应的资产数据
export function getTreeNodeResource(id, params) {
  return request({
    url: `/api/v1/tree/get-reloated-resource/${id}`,
    method: 'get',
    params
  })
}

// 添加资源关联
export function createResourceRelated(data) {
  return request({
    url: `/api/v1/tree/related`,
    method: 'post',
    data
  })
}

// 删除资源关联
export function deleteResourceRelated(nodeID, params) {
  return request({
    url: `/api/v1/tree/related/${nodeID}`,
    method: 'delete',
    params
  })
}

// 新建服务模版
export function createServiceTemplate(data) {
  return request({
    url: `/api/v1/tree/service-template`,
    method: 'post',
    data
  })
}

// 编辑服务模版
export function editServiceTemplate(id, data) {
  return request({
    url: `/api/v1/tree/service-template/${id}`,
    method: 'put',
    data
  })
}

// 服务模版列表
export function serviceTemplateList(params) {
  return request({
    url: `/api/v1/tree/service-template`,
    method: 'get',
    params
  })
}

// 删除服务模版
export function deleteServiceTemplate(id) {
  return request({
    url: `/api/v1/tree/service-template/${id}`,
    method: 'delete'
  })
}

// 新建模版进程
export function createTemplateProcess(data) {
  return request({
    url: `/api/v1/tree/template-process`,
    method: 'post',
    data
  })
}

// 编辑模版进程
export function editTemplateProcess(id, data) {
  return request({
    url: `/api/v1/tree/template-process/${id}`,
    method: 'put',
    data
  })
}

// 模版进程列表
export function templateProcessList(params) {
  return request({
    url: `/api/v1/tree/template-process`,
    method: 'get',
    params
  })
}

// 删除模版进程
export function deleteTemplateProcess(id) {
  return request({
    url: `/api/v1/tree/template-process/${id}`,
    method: 'delete'
  })
}

// 新建模版与进程的关联
export function createTemplateProcessRelated(data) {
  return request({
    url: `/api/v1/tree/template-process-related`,
    method: 'post',
    data
  })
}

// 编辑服务模版
export function editTemplateProcessRelated(id, data) {
  return request({
    url: `/api/v1/tree/template-process-related/${id}`,
    method: 'put',
    data
  })
}

// 删除服务模版
export function deleteTemplateProcessRelated(id) {
  return request({
    url: `/api/v1/tree/template-process-related/${id}`,
    method: 'delete'
  })
}
