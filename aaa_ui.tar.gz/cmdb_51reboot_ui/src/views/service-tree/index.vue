<template>
  <div class="app-container">
    <el-row>
      <el-col :span="5" style="padding-right: 5px">
        <el-card class="box-card">
          <div>
            <el-input
              v-model="filterText"
              size="small"
              placeholder="输入关键字进行过滤"
              style="margin-bottom: 10px;"
            />

            <el-tree
              ref="tree"
              node-key="id"
              class="filter-tree"
              :data="treeData"
              :props="defaultTreeProps"
              default-expand-all
              :filter-node-method="filterNode"
              @node-click="handleNodeClick"
            />
          </div>
        </el-card>
      </el-col>
      <el-col :span="19">
        <el-card class="box-card" style="margin-bottom: 5px">
          <div>
            <el-row>
              <el-button type="primary" icon="el-icon-plus" size="small" @click="createTopNodeHandle">新建主节点</el-button>
              <el-button type="primary" icon="el-icon-plus" size="small" @click="createNodeHandle">新建子节点</el-button>
              <el-button type="warning" icon="el-icon-edit" size="small" @click="editNodeHandle">编辑节点</el-button>
              <el-button type="danger" icon="el-icon-delete" size="small" @click="deleteNodeHandle">删除节点</el-button>
            </el-row>
          </div>
        </el-card>
        <el-tabs v-model="nodeActiveName" type="border-card">
          <el-tab-pane label="资源列表" name="list">
            <div v-if="currentNode.id">
              <div class="filter-container">
                <el-button
                  type="primary"
                  size="small"
                  style="margin-right: 5px;"
                  @click="getResourceListHandle"
                >绑定资源</el-button>
                <el-select
                  v-model="listQuery.model"
                  style="margin-right: 5px; width: 160px;"
                  placeholder="请选择"
                  size="small"
                  @change="searchNodeResourceHandle"
                >
                  <el-option-group
                    v-for="group in models"
                    :key="group.id"
                    :label="group.name"
                  >
                    <el-option
                      v-for="item in group.models"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    />
                  </el-option-group>
                </el-select>

                <el-input v-model="listQuery.username" placeholder="请输入搜索内容" size="small" style="width: 350px;">
                  <el-button slot="append" icon="el-icon-search" @click="handleFilter" />
                </el-input>
              </div>

              <el-table
                :key="tableKey"
                v-loading="false"
                :data="list"
                border
                fit
                highlight-current-row
                size="mini"
                style="width: 100%; margin-top: 10px;"
              >
                <template v-for="fieldItem of fieldList">
                  <el-table-column
                    v-if="fieldItem.is_list"
                    :key="fieldItem.id"
                    :label="fieldItem.cname"
                    :prop="fieldItem.name"
                  />
                </template>
                <el-table-column
                  fixed="right"
                  label="操作"
                  width="100"
                >
                  <template slot-scope="{row}">
                    <el-button
                      type="text"
                      size="small"
                      icon="el-icon-delete"
                      @click.native.prevent="handleDeleteRow(row)"
                    >
                      移除
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>

              <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />

            </div>
            <div v-else class="notNode">
              未选择节点
            </div>
          </el-tab-pane>
          <el-tab-pane label="进程信息" name="process">
            <div class="notNode">
              暂无进程信息
            </div>
          </el-tab-pane>
          <el-tab-pane label="节点信息" name="info">
            <el-row v-if="currentNode.id" class="tree-node-info">
              <el-col :span="12">
                <span>ID: </span> {{ currentNode.id }}
              </el-col>
              <el-col :span="12">
                <span>名称: </span> {{ currentNode.label }}
              </el-col>
              <el-col :span="12">
                <span>标识: </span> {{ currentNode.name }}
              </el-col>
              <el-col :span="12">
                <span>父级ID: </span> {{ currentNode.parent }}
              </el-col>
              <el-col :span="12">
                <span>级别: </span> {{ currentNode.level }}
              </el-col>
              <el-col :span="12">
                <span>Tags: </span>
                <el-tag
                  v-for="(tagItem, tagIndex) in currentNode.tags"
                  :key="tagIndex"
                  size="mini"
                  style="margin-right: 5px;"
                > {{ tagItem }}</el-tag>
              </el-col>
              <el-col :span="12" style="margin-bottom: 0;">
                <span>创建时间: </span> {{ currentNode.create_time }}
              </el-col>
              <el-col :span="12" style="margin-bottom: 0;">
                <span>更新时间: </span> {{ currentNode.update_time }}
              </el-col>
            </el-row>
            <div v-else class="notNode">
              未选择节点
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-col>
    </el-row>

    <!-- 节点管理 -->
    <el-dialog
      title="节点管理"
      :visible.sync="nodeDialog"
      width="38%"
    >
      <div>
        <el-form ref="nodeForm" :model="nodeForm" :rules="rules" label-width="60px" class="demo-ruleForm">
          <el-form-item label="名称" prop="label">
            <el-input v-model="nodeForm.label" placeholder="请输入名称" size="small" />
          </el-form-item>
          <el-form-item label="标识" prop="name">
            <el-input v-model="nodeForm.name" placeholder="请输入标识" size="small" />
          </el-form-item>
          <el-form-item label="标签" prop="tags">
            <el-select
              v-model="nodeForm.tags"
              size="small"
              multiple
              filterable
              allow-create
              default-first-option
              placeholder="请输入标签"
              style="width:100%;"
            >
              <el-option
                v-for="item in nodeTags"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="nodeDialog = false">取 消</el-button>
        <el-button type="primary" size="small" @click="nodeSubmit">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 资源列表 -->
    <el-dialog
      title="资源列表"
      :visible.sync="resourceVisible"
      width="80%"
    >
      <div>
        <el-table
          :key="tableKey"
          v-loading="false"
          :data="dataList"
          border
          fit
          highlight-current-row
          size="mini"
          style="width: 100%; margin-top: 10px;"
          @select="handleResourceSelect"
        >
          <el-table-column
            type="selection"
            width="55"
          />
          <template v-for="fieldItem of fieldList">
            <el-table-column
              v-if="fieldItem.is_list"
              :key="fieldItem.id"
              :label="fieldItem.cname"
              :prop="fieldItem.name"
            />
          </template>
        </el-table>

        <pagination v-show="dataTotal>0" :total="dataTotal" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />
      </div>
    </el-dialog>

  </div>
</template>

<script>
import {
  getTreeData,
  createNode,
  editNode,
  deleteNode,
  getTreeNodeResource,
  createResourceRelated,
  deleteResourceRelated
} from '@/api/service-tree/index'

import {
  getModels,
  modelDetails,
  resourceList
} from '@/api/cmdb/model'

import Pagination from '@/components/Pagination'
export default {
  components: {
    Pagination
  },
  data() {
    return {
      resourceVisible: false,
      nodeActiveName: 'list',
      nodeDialog: false,
      filterText: '',
      treeData: [],
      defaultTreeProps: {
        children: 'children',
        label: 'label'
      },
      nodeForm: {
        parent: 0,
        level: 1
      },
      rules: {
        label: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入标识', trigger: 'blur' }
        ]
      },
      nodeTags: [],
      nodeSubmitStatus: 'create',
      currentNode: {},
      //
      list: [], // 按照模型区分，绑定资源数据的列表
      total: 0, // 按照模型区分，绑定资源数据的总数
      dataList: [], // 按照模型区分，所有资源列表
      dataTotal: 0, // 按照模型区分，所有资源总数
      listQuery: {},
      tableKey: 0,
      fieldList: [],
      models: [],
      currentResourceRelatedList: []
    }
  },
  watch: {
    filterText(val) {
      this.$refs.tree.filter(val)
    }
  },
  created() {
    this.getTreeHandle()
  },
  methods: {
    filterNode(value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    getTreeHandle() {
      getTreeData().then(res => {
        this.treeData = res.data
      })
    },
    createTopNodeHandle() {
      this.nodeSubmitStatus = 'create'
      this.nodeDialog = true
      this.nodeForm = {
        parent: 0,
        level: 1
      }
      this.$nextTick(() => {
        this.$refs['nodeForm'].clearValidate()
      })
    },
    createNodeHandle() {
      this.nodeSubmitStatus = 'create'
      if (this.currentNode.id) {
        this.nodeDialog = true
        this.nodeForm = {
          parent: this.currentNode.id,
          level: this.currentNode.level + 1
        }
        this.$nextTick(() => {
          this.$refs['nodeForm'].clearValidate()
        })
      } else {
        this.$notify({
          type: 'warning',
          title: '警告',
          message: '未选中节点'
        })
      }
    },
    editNodeHandle() {
      if (this.currentNode.id) {
        this.nodeSubmitStatus = 'edit'
        this.nodeDialog = true
        this.nodeForm = JSON.parse(JSON.stringify(this.currentNode))
        delete this.nodeForm.id
        delete this.nodeForm.create_time
        delete this.nodeForm.update_time
        this.$nextTick(() => {
          this.$refs['nodeForm'].clearValidate()
        })
      } else {
        this.$notify({
          type: 'warning',
          title: '警告',
          message: '未选中节点'
        })
      }
    },
    deleteNodeHandle() {
      if (this.currentNode.id) {
        this.$confirm('确认是否删除此节点?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          deleteNode(this.currentNode.id).then(() => {
            this.getTreeHandle()
            this.currentNode = {} // 不能直接修改为，undefined
            this.$message({
              type: 'success',
              title: 'Success',
              message: '删除成功!'
            })
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            title: '取消',
            message: '已取消删除'
          })
        })
      } else {
        this.$notify({
          type: 'warning',
          title: '警告',
          message: '未选中节点'
        })
      }
    },
    handleNodeClick() {
      this.currentNode = this.$refs.tree.getCurrentNode()
      this.getModelsData()
    },
    nodeSubmit() {
      this.$refs['nodeForm'].validate((valid) => {
        if (valid) {
          if (this.nodeForm.level < 6) {
            if (this.nodeSubmitStatus === 'create') {
              // 创建
              createNode(this.nodeForm).then(res => {
                this.getTreeHandle()
                this.nodeDialog = false
                this.$notify({
                  type: 'success',
                  title: '成功',
                  message: '创建主节点成功'
                })
              })
            } else {
              // 编辑
              editNode(this.currentNode.id, this.nodeForm).then(res => {
                this.getTreeHandle()
                this.nodeDialog = false
                this.$notify({
                  type: 'success',
                  title: '成功',
                  message: '编辑节点成功'
                })
              })
            }
          } else {
            this.nodeDialog = false
            this.$notify({
              type: 'warning',
              title: '警告',
              message: `无法创建，层级最多为 5 层`
            })
          }
        } else {
          return false
        }
      })
    },
    getList() {
      this.dataList = []
      if (this.listQuery.model) {
        resourceList(this.listQuery).then(res => {
          for (var d of res.data.list) {
            if (this.currentResourceRelatedList.indexOf(d.id) === -1) {
              d.data['data_id'] = d.id
              d.data['data_model'] = d.model
              d.data['data_tag'] = d.tag
              this.dataList.push(d.data)
            }
          }
          this.dataTotal = res.data.total
        })
      } else {
        this.$notify({
          type: 'warning',
          title: '警告',
          message: '未选择模型'
        })
      }
    },
    searchNodeResourceHandle() {
      this.getModel(this.listQuery.model)
      this.getNodeResource() // 查询关联资源
    },
    // 获取字段信息
    getModel(modelId) {
      this.fieldList = []
      modelDetails(modelId).then(res => {
        this.model = res.data
        for (var field_group of res.data.field_group) {
          for (var field of field_group.fields) {
            if (field.required) {
              this.rules[field.name] = [
                { required: true, message: '必填', trigger: 'blur' }
              ]
            }
            this.fieldList.push(field)
          }
        }
      })
    },
    handleFilter() {},
    getModelsData() {
      // 获取字段信息
      getModels().then(res => {
        this.models = res.data.list
        if (this.models !== undefined && this.models.length > 0) {
          if (this.models[0].models !== undefined && this.models[0].models.length > 0) {
            if (this.listQuery.model === undefined) {
              this.listQuery.model = this.models[0].models[0].id
            }
            this.getModel(this.listQuery.model)
            this.getNodeResource() // 查询关联资源
          }
        }
      })
    },
    getNodeResource() {
      if (this.currentNode.id) {
        this.list = []
        getTreeNodeResource(this.currentNode.id, this.listQuery).then(res => {
          for (var r of res.data.list) { // in 遍历得到的就是索引，of 得到的就是数组的值
            r.data.resource_id = r.id
            r.data.resource_model = r.model
            this.list.push(r.data)
            this.currentResourceRelatedList.push(r.id)
          }
          this.total = res.data.total
        })
      } else {
        this.$notify({
          type: 'warning',
          title: '警告',
          message: '未选中节点'
        })
      }
    },
    getResourceListHandle() {
      this.resourceVisible = true
      this.getList()
    },
    handleResourceSelect(selection, row) {
      createResourceRelated({
        tree_id: this.currentNode.id,
        target_id: row.data_id,
        type: row.data_model
      }).then(res => {
        this.getNodeResource()
      })
    },
    handleDeleteRow(row) {
      this.$confirm('确认是否删除此资源关联?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteResourceRelated(this.currentNode.id, {
          target_id: row.resource_id,
          type: row.resource_model
        }).then(() => {
          this.getNodeResource()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(err => {
        console.log(err)
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .tree-node-info > .el-col {
    margin-bottom: 20px;
  }

  .tree-node-info > .el-col > span {
    color: #999;
    margin-right: 15px;
  }

  .notNode{
    font-size: 50px;
    text-align: center;
    height: 200px;
    line-height: 200px;
    color: #ddd;
  }

  ::v-deep .el-dialog__body {
    padding-bottom: 20px;
  }
</style>
