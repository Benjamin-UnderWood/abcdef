<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>进程管理</span>
      </div>
      <div>
        <div class="filter-container">
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-plus"
            style=" margin-right: 8px;"
            @click="handleCreate"
          >新 建</el-button>
          <el-input v-model="listQuery.username" placeholder="请输入搜索内容" size="mini" style="width: 350px;">
            <el-button slot="append" icon="el-icon-search" @click="handleFilter" />
          </el-input>
        </div>

        <el-table
          :key="tableKey"
          v-loading="false"
          :data="list"
          border
          fit
          highlight-current-row
          size="mini"
          style="width: 100%; margin-top: 10px;"
        >
          <el-table-column label="ID" prop="id" />
          <el-table-column label="名称" prop="name" />
          <el-table-column label="别名" prop="cname" />
          <el-table-column label="监听地址" prop="ip" />
          <el-table-column label="监听端口" prop="port" />
          <el-table-column label="创建时间">
            <template slot-scope="{row}">
              {{ row.create_time | parseTime() }}
            </template>
          </el-table-column>
          <!-- <el-table-column label="更新时间">
            <template slot-scope="{row}">
              {{ row.update_date | parseTime() }}
            </template>
          </el-table-column> -->
          <el-table-column label="操作" align="center" width="230" class-name="small-padding fixed-width">
            <template slot-scope="{row,$index}">
              <!-- <el-button
                type="text"
                size="mini"
                icon="el-icon-edit"
                @click="handleSelect(row)"
              >
                查看
              </el-button> -->
              <el-button type="text" size="mini" icon="el-icon-edit" @click="handleUpdate(row)">
                编辑
              </el-button>
              <el-button size="mini" type="text" icon="el-icon-delete" @click="handleDelete(row,$index)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.limit" @pagination="getList" />
      </div>
    </el-card>

    <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
      <el-form ref="dataForm" :rules="rules" :model="dataForm" label-position="right" label-width="100px">
        <el-form-item label="名称" prop="name">
          <el-input v-model="dataForm.name" placeholder="英文" size="small" />
        </el-form-item>
        <el-form-item label="别名" prop="cname">
          <el-input v-model="dataForm.cname" placeholder="中文" size="small" />
        </el-form-item>
        <el-form-item label="监听地址" prop="ip">
          <el-input v-model="dataForm.ip" placeholder="请输入监听地址" size="small" />
        </el-form-item>
        <el-form-item label="监听端口" prop="port">
          <el-input v-model="dataForm.port" placeholder="请输入监听端口" size="small" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="dialogFormVisible = false">
          关闭
        </el-button>
        <el-button type="primary" size="small" @click="dialogStatus==='create'?createData():updateData()">
          确认
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  createTemplateProcess,
  editTemplateProcess,
  templateProcessList,
  deleteTemplateProcess
} from '@/api/service-tree/index'

import waves from '@/directive/waves' // waves directive
import Pagination from '@/components/Pagination' // secondary package based on el-pagination

export default {
  name: 'Role',
  components: { Pagination },
  directives: { waves },
  data() {
    return {
      roles: [],
      tableKey: 0,
      list: [],
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      },
      dataForm: {
        id: undefined,
        name: '',
        cname: '',
        ip: '',
        port: ''
      },
      dialogFormVisible: false,
      dialogStatus: '',
      textMap: {
        update: '编辑',
        create: '新建'
      },
      rules: {
        name: [{ required: true, message: '请输入英文标识', trigger: 'blur' }],
        cname: [{ required: true, message: '请输入中文名称', trigger: 'blur' }],
        ip: [{ required: true, message: '请输入监听地址', trigger: 'blur' }],
        port: [{ required: true, message: '请输入监听端口', trigger: 'blur' }]
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      this.listLoading = true
      templateProcessList(this.listQuery).then(response => {
        this.list = response.data.list
        this.total = response.data.total
        this.listLoading = false
      })
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    resetDataForm() {
      this.dataForm = {
        id: undefined,
        name: '',
        cname: '',
        ip: '',
        port: ''
      }
    },
    handleCreate() {
      this.resetDataForm()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    createData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          createTemplateProcess(this.dataForm).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '创建成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleUpdate(row) {
      this.dataForm = Object.assign({}, row) // copy obj
      this.dialogStatus = 'update'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    updateData() {
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          const tempData = Object.assign({}, this.dataForm)
          editTemplateProcess(this.dataForm.id, tempData).then(() => {
            this.getList()
            this.dialogFormVisible = false
            this.$notify({
              title: '成功',
              message: '更新成功',
              type: 'success',
              duration: 2000
            })
          })
        }
      })
    },
    handleDelete(row, index) {
      this.$confirm('是否删除此服务模版?', '提示', {
        confirmButtonText: '是',
        cancelButtonText: '否',
        type: 'warning'
      }).then(() => {
        deleteTemplateProcess(row.id).then(() => {
          this.getList()
          this.$notify({
            title: '成功',
            message: '删除成功',
            type: 'success',
            duration: 2000
          })
        })
      }).catch(() => {
        this.$notify({
          title: '失败',
          message: '删除失败',
          type: 'warning',
          duration: 2000
        })
      })
    }
  }
}
</script>
