import os
import sys

BASEDIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASEDIR)
sys.path.insert(0, os.path.abspath(os.path.join(BASEDIR, '..')))


from tests import SetUpDecorator

@SetUpDecorator
def sendMail():
    from post_office import mail

    mail.send(
        'recipient@example.com', # List of email addresses also accepted
        'from@example.com',
        subject='My email',
        message='Hi there!',
        html_message='Hi <strong>there</strong>!',
    )



def main():
    sendMail()



if __name__ == '__main__':
    main()