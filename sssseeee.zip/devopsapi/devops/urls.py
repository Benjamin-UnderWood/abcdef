"""bsc URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf.urls import url
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter

from apps.user import urls as user_urls
from apps.cmdb import urls as cmdb_urls
from apps.service_tree import urls as service_tree_urls
from apps.bastion import urls as bastion_urls
from apps.book.route import books_router
from apps.system import urls as system_urls
from apps.task import urls as task_urls
from apps.celery_tasks import urls as celery_tasks_urls
from django.views.static import serve
# Api Document
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

api_version = "api/v1/"

router = DefaultRouter()
router.registry.extend(books_router.registry)

urlpatterns = [
                  path("admin/", admin.site.urls),
                  # 视图集
                  path(api_version, include(router.urls)),
                  # 用户
                  path(api_version, include(user_urls)),
                  # cmdb
                  path(api_version, include(cmdb_urls)),
                  # celery tasks
                  path(api_version, include(celery_tasks_urls)),
                  # service tree
                  path(api_version, include(service_tree_urls)),
                  # system
                  path(api_version, include(system_urls)),
                  # task
                  path(api_version, include(task_urls)),
                  # ticket
                  # path(api_version, include(ticket_urls)),
                  # 堡垒机
                  path(api_version, include(bastion_urls)),
                  # 堡垒机
                  # path(api_version, include(ticket_urls))
              ] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# 增加swagger 文档
schema_view = get_schema_view(
    openapi.Info(
        title="51Reboot API",
        default_version="v1",
        description="Release description",
        terms_of_service="https://www.51reboot.com/policies/terms/",
        contact=openapi.Contact(email="moyu@51reboot.com"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)
# print(serve, {'document_root': settings.MEDIA_ROOT})
urlpatterns += [
    path("swagger(?P<format>.\.json|\.yaml)", schema_view.without_ui(cache_timeout=0), name="schema-json"),
    path("swagger", schema_view.with_ui("swagger", cache_timeout=0), name="schema-swagger-ui"),
    path("redoc", schema_view.with_ui("redoc", cache_timeout=0), name="schema-redoc"),
]

#自动把 apps下的  模块 路由扫描进来
urls = [url(r'^api/v1/{}/'.format(app.split(".")[1]), include('{}.urls'.format(app))) for app in ['apps.workflow']]
urlpatterns.extend(urls)
