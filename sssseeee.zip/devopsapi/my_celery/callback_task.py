#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

from celery import Task

from apps.celery_tasks import models


class MyTask(Task):
    # 任务失败时执行
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        print(f"task id: {task_id}, execute failed.")
        # models.TaskHistory.objects.filter(task_id=task_id).update(**{"task_status": "FAILED"})

    # 任务成功时执行
    def on_success(self, retval, task_id, args, kwargs):
        print(f"task id: {task_id}, execute successfully.")
        models.TaskHistory.objects.filter(task_id=task_id).update(**{"task_status": "SUCCESS"})

    # 任务重试时执行
    def on_retry(self, exc, task_id, args, kwargs, einfo):
        print(f"task id: {task_id}, execute retry.")
