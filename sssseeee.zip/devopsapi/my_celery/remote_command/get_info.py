#!/usr/bin/env python
# encoding: utf-8
# @author: lanyulei

import shutil
import time
import ansible.constants as C
import threading
import queue
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.module_utils.common.collections import ImmutableDict
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.plugins.callback import CallbackBase
from ansible.vars.manager import VariableManager
from ansible import context

q = queue.Queue(maxsize=200)
host_details_list = []
host_failed_list = []
dictionary = "idc"
g_lock = threading.Lock()


class ResultsCollectorJSONCallback(CallbackBase):
    def __init__(self, dictionary, *args, **kwargs):
        super(ResultsCollectorJSONCallback, self).__init__(*args, **kwargs)
        self.host_ok = {}
        self.host_unreachable = {}
        self.host_failed = {}
        self.dictionary = dictionary

    def v2_runner_on_unreachable(self, result):
        host = result._host
        self.host_unreachable[host.get_name()] = result

    def v2_runner_on_ok(self, result, *args, **kwargs):
        host = result._host
        description = result._result['ansible_facts']['ansible_lsb'].get('description', "")
        ansible_machine = result._result['ansible_facts']['ansible_machine']
        sysinfo = '%s %s' % (description, ansible_machine)

        idc_dict = {
            "uuid": "{}-{}".format(self.dictionary, host.name),
            "dictionary": self.dictionary,
            "push_type": 1,
            "value": {
                "sn": result._result['ansible_facts']['ansible_product_serial'],
                "sysinfo": sysinfo,
                "cpu": result._result['ansible_facts']['ansible_processor'][1],
                "cpu_count": result._result['ansible_facts']['ansible_processor_count'],
                "cpu_cores": result._result['ansible_facts']['ansible_processor_cores'],
                "mem": result._result['ansible_facts']['ansible_memtotal_mb'],
                "disk": result._result['ansible_facts']['ansible_devices'].get("sda", {}).get("size", ""),
                # "ipadd_in": result._result['ansible_facts']['ansible_default_ipv4']["address"],
                "ipadd_in": host.name,
                "macaddress": result._result['ansible_facts']['ansible_default_ipv4']["macaddress"],
                "os_kernel": result._result['ansible_facts']['ansible_kernel'],
                "host_name": result._result['ansible_facts']['ansible_hostname'],
            }
        }

        self.host_ok[host.get_name()] = idc_dict

    def v2_runner_on_failed(self, result, *args, **kwargs):
        host = result._host
        self.host_failed[host.get_name()] = result


def get_idc_info(host_list):
    print("开始上报IDC数据...")

    context.CLIARGS = ImmutableDict(
        module_path=['/Users/lanyulei/.ansible/plugins/modules', '/usr/share/ansible/plugins/modules'],
        connection='smart', remote_user="user", ack_pass=True, sudo_user=None, forks=5,  # todo 需要配置remote_user
        sudo=None, ask_sudo_pass=False,
        verbosity=5, become=None, become_method=None, become_user="None",
        check=False, diff=False,
        listhosts=None, listtasks=None, listtags=None, syntax=None)
    sources = ','.join(host_list)
    if len(host_list) == 1:
        sources += ','

    loader = DataLoader()
    passwords = dict(conn_pass='password')  # todo 配置对应的密码

    results_callback = ResultsCollectorJSONCallback(dictionary)

    inventory = InventoryManager(loader=loader, sources=sources)

    variable_manager = VariableManager(loader=loader, inventory=inventory)

    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords,
        stdout_callback=results_callback,
    )
    play_source = dict(
        name="Ansible Play",
        hosts=host_list,
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup'), register='shell_out'),
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    try:
        tqm.run(play)
    finally:
        tqm.cleanup()
        if loader:
            loader.cleanup_all_tmp_files()

    shutil.rmtree(C.DEFAULT_LOCAL_TMP, True)

    result_list = []
    for host, result in results_callback.host_ok.items():
        result_list.append('{0} >>> {1}'.format(host, result))

    for host, result in results_callback.host_failed.items():
        result_list.append('{0} >>> {1}'.format(host, result._result['msg']))

    for host, result in results_callback.host_unreachable.items():
        result_list.append('{0} >>> {1}'.format(host, result._result['msg']))

    print(result_list)
    return result_list


if __name__ == '__main__':
    start_time = time.time()
    get_idc_info(["192.1.1.1"])
    print(time.time() - start_time)
