#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

"""
执行shell命令，包括脚本
"""

from my_celery.run import app  # Celery 实例对象
from my_celery.callback_task import MyTask
import paramiko


# log = logging.getLogger("django")


@app.task(base=MyTask)
def exec_command(host_list, command):
    """
    :param command: 用户传递的命令
    :return:
    """

    print("start connect...")
    hostname = "192.160.84.97"
    port = 22
    username = 'root'
    password = 'P@ssw0rd'
    cmd = "ps -ef|grep java"

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    # ssh.connect( hostname ,22, username , password )
    ssh.connect(hostname, username=username, password=password, allow_agent=False, look_for_keys=False)
    stdin, stdout, stderr = ssh.exec_command(cmd)
    list = stdout.readlines()
    ssh.close()
