#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm


# 中间人，任务队列
broker_url = "redis://:ferry123456@127.0.0.1:6379/7"  # rbmq, redis

# 任务执行结果的存储
result_backend = "redis://:ferry123456@127.0.0.1:6379/8"

# 国标
enable_utc = False

# 时区
timezone = "Asia/Shanghai"
