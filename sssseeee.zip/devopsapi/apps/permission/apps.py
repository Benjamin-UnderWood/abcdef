from django.apps import AppConfig


class PermissionConfig(AppConfig):
    name = 'apps.permission'
    verbose_name = "API权限"
