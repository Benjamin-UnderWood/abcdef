#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.urls import path
from apps.cmdb import views


urlpatterns = [
    # 分类管理
    path('classification', views.Classification.as_view(), name='classification'),

    # 表管理
    path('table', views.Table.as_view(), name='table'),
    path('classification/table', views.ClassificationTable.as_view(), name='classification-table'),
    path('table/value', views.TableValue.as_view(), name='table-value'),

    # 数据
    path('data', views.Data.as_view(), name='data')
]
