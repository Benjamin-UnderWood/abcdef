from django.db import models
from django.contrib.auth.models import AbstractUser
from utils.util import deal_fields_Table
from utils.base_model import BaseModel

class UserProfile(AbstractUser):
    """
    Users within the Django authentication system are represented by this
    model.

    Username and password are required. Other fields are optional.
    """

    name = models.CharField("中文名", max_length=30)
    cname = models.CharField("中文名1", max_length=30)
    phone = models.CharField("手机", max_length=11, null=True, blank=True)

    class Meta:
        db_table = "user_profile"
        verbose_name = "用户信息表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.username

class Role(BaseModel):
    description = models.CharField(verbose_name='角色描述', help_text='角色描述', max_length=500, blank=True)
    users = models.ManyToManyField('UserProfile', verbose_name='用户', help_text='用户', blank=True)
    class Meta:
        unique_together = ('name',)
        verbose_name = verbose_name_plural = '用户角色'

    def get_fields(self):
        """
        获取字段信息
        """
        field_dict = {}
        for field in self._meta.fields:
            field_dict[field.name] = field.verbose_name
        return field_dict

    def get_table_info(self):
        """
        获取table表
        """
        data = deal_fields_Table(self._meta.fields+self._meta.many_to_many)
        data['field_select_kv'].append({"urls": [[row.id, row.url] for row in Url.objects.filter(user_type='customuser')]})
        data['fields']["users"] = "用户列表"
        data['field_add_novis'] = ['users','id']
        data['field_show_order'].append("users")
        return data
