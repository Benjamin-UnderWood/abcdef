from django.apps import AppConfig


class ServiceTreeConfig(AppConfig):
    name = 'apps.service_tree'
