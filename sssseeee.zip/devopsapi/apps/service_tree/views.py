from rest_framework.views import APIView
from django.http import JsonResponse
from rest_framework.authentication import SessionAuthentication
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated
from apps.service_tree import models
from apps.cmdb.models import Table, Classification, Data
from utils.api_response.api_response import api_response


# 树管理
class ServiceTree(APIView):
    authentication_classes = [SessionAuthentication, JSONWebTokenAuthentication]
    permission_classes = [IsAuthenticated]

    # 获取树状结构数据
    def get(self, request, *args, **kwargs):

        result = {"code": 20000, "message": "成功", "data": ""}

        # 递归函数
        def set_children(id, menus):
            """
            根据传递过来的父菜单id，递归设置各层次父菜单的子菜单列表

            :param id: 父级id
            :param menus: 子菜单列表
            :return: 如果这个菜单没有子菜单，返回None;如果有子菜单，返回子菜单列表
            """
            # 记录子菜单列表
            children = []
            # 遍历子菜单
            for m in menus:
                if m["parent"] == id:
                    children.append(m)

            # 把子菜单的子菜单再循环一遍
            for sub in children:
                menus2 = list(
                    models.ServiceTree.objects.filter(parent=sub["id"]).values("id", "label", "parent", "level")
                )
                # 还有子菜单
                if len(menus):
                    children_value = set_children(sub["id"], menus2)
                    if children_value is not None:
                        sub["children"] = children_value

            # 子菜单列表不为空
            if len(children):
                return children
            else:  # 没有子菜单了
                return None

        # 一级菜单
        # 所有父级为0的都是顶层节点。
        # models.ServiceTree.Objects.get(parent=0) 查询单挑数据
        top_menus = list(
            models.ServiceTree.objects.filter(parent=0).values("id", "label", "parent", "level"))  # 查询所有的顶层节点
        for menu in top_menus:  # 查询所有顶层节点的子节点
            children = list(
                models.ServiceTree.objects.filter(parent=menu["id"]).values("id", "label", "parent", "level")
            )
            menu["children"] = set_children(menu["id"], children)  # 触发递归函数

        result["data"] = top_menus

        return JsonResponse(result)

    # 创建节点数据
    def post(self, request, *args, **kwargs):
        result = {"code": 20000, "message": "成功", "data": ""}
        try:
            data = {
                "label": request.data.get("label"),
                "parent": request.data.get("parent"),
                "level": request.data.get("level"),
            }
            models.ServiceTree.objects.create(**data)
        except Exception as e:
            result["code"] = 400
            result["message"] = f"创建节点数据，{e}"

        return JsonResponse(result)

    # 编辑节点数据
    def put(self, request, *args, **kwargs):
        result = {"code": 20000, "message": "成功", "data": ""}
        try:
            models.ServiceTree.objects.filter(id=request.data.get("id")).update(**{"label": request.data.get("label")})
        except Exception as e:
            result["code"] = 400
            result["message"] = f"创建节点数据，{e}"

        return JsonResponse(result)

    # 删除节点数据
    def delete(self, request, *args, **kwargs):
        result = {"code": 20000, "message": "成功", "data": ""}
        try:
            models.ServiceTree.objects.filter(id=request.GET.get("id")).delete()
        except Exception as e:
            result["code"] = 400
            result["message"] = f"创建节点数据，{e}"

        return JsonResponse(result)


# 获取模型详情
class CmdbTableDetails(APIView):
    def get(self, request, *args, **kwargs):
        res = {
            "code": 20000,
            "message": "成功",
            "data": []
        }

        try:
            table_id = request.GET.get("table_id", "")
            if table_id == "":
                res["code"] = 10400
                res["message"] = "pk参数不能为空"
            else:
                table_value = list(Table.objects.filter(id=table_id).values())[0]
                res["data"] = table_value
        except Exception as e:
            res["code"] = 10400
            res["message"] = str(e)

        return JsonResponse(res)


# 绑定CMDB资产数据
class BindCmdbData(APIView):
    def post(self, request, *args, **kwargs):
        try:
            data = request.data

            # 判断是否绑定
            # todo 作业，自己实现判断。存在就不绑定，不存在则绑定

            models.BindCMDB.objects.create(**data)
        except Exception as e:
            return api_response(10400, str(e))
        return api_response()


# 获取绑定了哪些分类
class GetBindClassify(APIView):
    def get(self, request, *args, **kwargs):

        try:
            service_tree = request.GET.get("service_tree", "")
            if service_tree == "":
                return api_response(10400, "service_tree参数不能为空")

            classify_list = list(set([i[0] for i in list(
                models.BindCMDB.objects.filter(service_tree=service_tree).values_list("classification"))]))
            classify_details_list = list(Classification.objects.filter(id__in=classify_list).values())
            return api_response(data=classify_details_list)

        except Exception as e:
            return api_response(10400, str(e))


class GetBindClassifyTable(APIView):
    def get(self, request):
        try:

            service_tree = request.GET.get("service_tree", "")
            classify = request.GET.get("classify", "")
            if classify == "" or service_tree == "":
                return api_response(10400, "classify和service_tree参数都不能为空")

            table_list = list(set([i[0] for i in list(
                models.BindCMDB.objects.filter(service_tree=service_tree, classification=classify).values_list(
                    "table"))]))
            table_details_list = list(
                Table.objects.filter(id__in=table_list).values("id", "name", "alias", "classification_id"))

            return api_response(data=table_details_list)
        except Exception as e:
            return api_response(10400, f"查询类型对应的模型失败，{str(e)}")


class GetBindTableData(APIView):
    def get(self, request):
        try:

            service_tree = request.GET.get("service_tree", "")
            classify = request.GET.get("classify", "")
            table = request.GET.get("table", "")
            if classify == "" or service_tree == "" or table == "":
                return api_response(10400, "classify、service_tree和table参数都不能为空")

            data_list = list(set([i[0] for i in list(
                models.BindCMDB.objects.filter(service_tree=service_tree, classification=classify,
                                               table=table).values_list(
                    "data"))]))
            data_details_list = list(
                Data.objects.filter(id__in=data_list).values())

            return api_response(data=data_details_list)
        except Exception as e:
            return api_response(10400, str(e))


# 解除绑定
class DeleteBind(APIView):
    def delete(self, request):
        try:
            data_id = request.GET.get("data_id", "")
            if data_id == "":
                return api_response(10400, "data_id参数都不能为空")

            models.BindCMDB.objects.filter(
                service_tree=request.GET.get("service_tree"),
                classification=request.GET.get("classify"),
                table=request.GET.get("table"),
                data=request.GET.get("data_id"),
            ).delete()

            return api_response(message="绑定删除成功")
        except Exception as e:
            return api_response(10400, str(e))
