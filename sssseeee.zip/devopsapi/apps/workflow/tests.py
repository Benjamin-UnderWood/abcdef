# -*- coding: utf-8 -*-
#author Jack qq:774428957
from __future__ import unicode_literals

from django.test import TestCase

# Create your tests here.
