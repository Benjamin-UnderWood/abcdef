# author Jack qq:774428957
from rest_framework import routers
from apps.workflow.views import *

router = routers.DefaultRouter()
router.register(r'workflowgroups', WorkFlowGroupViewSet)
router.register(r'workflows', WorkFlowViewSet)
router.register(r'auditsteps', AuditStepViewSet)
router.register(r'formfields', FormFieldViewSet)
# router.register(r'openapis', OpenApiViewSet)

router.register(r'workorders', WorkOrderViewSet)
router.register(r'auditrecords', AuditRecordViewSet)
urlpatterns = router.urls

