# -*- coding: utf-8 -*-
#author Jack qq:774428957
import json,logging
from django.conf import settings
from django.db import transaction
from django.db.models import Q, Count
from django.contrib.auth import get_user_model
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import action
from utils.base_view import BaseModelViewSet
from .base_mixin import UpDownMixin
from apps.user.models import Role

from apps.workflow.tasks import workorder_task

from .util import *
from .serializers import *
from .models import *
from .filters import *

User = get_user_model()

logger = logging.getLogger('views')

class WorkFlowGroupViewSet(BaseModelViewSet):
    '''
        queryset=model.objects.all().order_by('id')
        serializers
        search_filed=('name','cname')
    '''
    queryset=WorkFlowGroup.objects.all().order_by('-id')   #list
    serializer_class = WorkFlowGroupSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')


class WorkFlowViewSet(BaseModelViewSet):
    '''
        queryset=model.objects.all().order_by('id')
        serializers
        search_filed=('name','cname')
    '''
    queryset=WorkFlow.objects.all().order_by('-id')   #list
    serializer_class = WorkFlowSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')

    @action(methods=['get'], detail=True)
    def steps(self, request, pk):
        '''
        审批流
        '''
        instance = self.get_object()
        step_instances = AuditStep.objects.filter(workflow=instance).order_by('order_num')
        serializer = AuditStepSerializer(step_instances, many=True)
        return Response(serializer.data)

    @action(methods=['get'],detail=True)
    def formfields(self,request,pk):
        instances = FormField.objects.filter(workflow_id=pk).order_by('order_num')
        serializer = FormFieldSerializer(instances, many=True)
        #把有dicturl的数据都调用一边:
        #数据组装完毕后在用
        #serializer.data 判断是不是select,是不是dicturl!=null 调用request_get获取数据填充进来s


        return Response(serializer.data)

    @action(methods=['get'], detail=False)
    def demoformfields(self, request):
        '''
        demo表单字段
        '''
        instance = WorkFlow.objects.get(name='demo')
        formfield_instances = FormField.objects.filter(workflow=instance).order_by('order_num')
        serializer = FormFieldSerializer(formfield_instances, many=True)
        return Response(serializer.data)


class AuditStepViewSet(UpDownMixin,BaseModelViewSet):
    queryset = AuditStep.objects.order_by('order_num')
    serializer_class = AuditStepSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')

    def list(self,request):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        print(serializer.data)
        return Response(serializer.data)

    @action(methods=['get'], detail=False)
    def get_table_info(self, request):
        '''
        获取表字段名和过滤选项
        '''
        data = {}
        if hasattr(self.queryset.model(), 'get_fields'): data['fields'] = self.queryset.model().get_fields()
        data['role_types'] = AuditStep.ROLE_TYPE
        data['roles'] = [{'id': row.id, 'cname': row.cname} for row in Role.objects.all()]
        return Response(data)

class FormFieldViewSet(UpDownMixin,BaseModelViewSet):
    queryset = FormField.objects.order_by('order_num')
    serializer_class = FormFieldSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')

#
# class OpenApiViewSet(UpDownMixin,BaseModelViewSet):
#     queryset = NoneModel.objects.all()
#     serializer_class = OpenApiSerializer
#
#     @action(methods=['get'], detail=False)
#     def get_ecstypes(self,request):
#         '''
#         #使用阿里云 api/sdk 链接进入
#         # 获取列表.格式化成能使用的格式
#             [
#                 {"value":"0","label":"大象","disabled":false},
#                 {"value":"1","label":"青蛙","disabled":false},
#                 {"value":"2","label":"狐狸","disabled":false}
#             ]
#         :param request:
#         :return:
#         '''
#         ret=[
#             {"value": 1, "label": "大象", "disabled": False},
#             {"value": 2, "label": "青蛙", "disabled": False},
#             {"value": 3, "label": "狐狸", "disabled": False}
#         ]
#         return Response(ret)
#
#     @action(methods=['get'], detail=False)
#     def get_gitlabgroups(self,request):
#         '''
#         #自己去调用gitlab
#         做名字对应关系----
#         # 获取列表.格式化成能使用的格式
#             [
#                 {"value":"0","label":"大象","disabled":false},
#                 {"value":"1","label":"青蛙","disabled":false},
#                 {"value":"2","label":"狐狸","disabled":false}
#             ]
#         :param request:
#         :return:
#         '''
#         ret=[
#             {"value": 1, "label": "大象", "disabled": False},
#             {"value": 2, "label": "青蛙", "disabled": False},
#             {"value": 3, "label": "狐狸", "disabled": False}
#         ]
#         return Response(ret)


class WorkOrderViewSet(BaseModelViewSet):
    queryset = WorkOrder.objects.order_by('-id')
    serializer_class = WorkOrderSerializer
    ordering_fields = ('id', 'name')
    search_fields = ('id', 'name', 'cname', 'creator__username', 'cur_user__username')
    filterset_class = WorkOrderFilter

    def get_serializer_class(self):
        if self.action == 'audit':
            return AuditSerializer
        elif self.action == 'list':
            return WorkOrderListSerializer
        elif self.action == 'auditrecord':
            return AuditRecordSerializer
        elif self.action == 'feedback':
            return FeedbackSerializer
        elif self.action == 'create':
            return CreateWorkOrderSerializer
        elif self.action == 'revoke':
            return RevokeSerializer
        else:
            return self.serializer_class

    def perform_create(self, serializer):
        with transaction.atomic():
            instance = serializer.save()
            instance.creator = self.request.user
            instance.name = instance.workflow.name
            instance.cname = instance.workflow.cname
            steps = instance.workflow.auditstep_set.order_by('order_num')
            instance.steps = json.dumps(AuditStepSerializer(steps, many=True).data)
            instance.status = 2
            instance.workflow.num += 1
            instance.workflow.save()
            instance.save()
            if not steps:
                instance.cur_step = None
                instance.cur_user = self.request.user
                if hasattr(instance.workflow, 'script'):
                    workorder_task.apply_async((instance.id,), queue=settings.HIGH_PRIORITY_QUEUE)
                    instance.status = 4
            else:
                instance.cur_step = steps[0]
            instance.save()
        # workorder_notice(instance)
        return Response({'code': 0, 'msg': 'success'},)

    @action(methods=['get'], detail=False)
    def get_table_info(self, request):
        '''
        获取表字段名和过滤选项
        '''
        data = {}
        if hasattr(self.queryset.model(), 'get_fields'): data['fields'] = self.queryset.model().get_fields()
        group_data = []
        workflow_data = []
        for row in WorkFlowGroup.objects.order_by('order_num'):
            d = {}
            d['id'] = row.id
            d['name'] = row.name
            d['cname'] = row.cname
            workflows = WorkFlow.objects.filter(is_active=True, group=row).order_by('-num')
            d['workflow'] = [{'id': i.id, 'name': i.name, 'cname': i.cname} for i in workflows]
            group_data.append(d)
        for row in WorkFlow.objects.filter(is_active=True, num__gt=0).order_by('-num')[:15]:
            d = {}
            d['id'] = row.id
            d['name'] = row.name
            d['cname'] = row.cname
            d['num'] = row.num
            d['group_cname'] = row.group.cname
            workflow_data.append(d)
        data['workflowgroups'] = group_data
        data['workflows'] = workflow_data
        data['exec_statuss'] = WorkOrder.EXEC_STATUS
        data['statuss'] = WorkOrder.STATUS
        return Response(data)


    @action(methods=['post'], detail=True)
    def audit(self, request, pk):
        '''
        审批工单
        '''
        instance = self.get_object()#  workorder.objects.get(pk=pk)
        #转换序列化
        serializer = self.get_serializer(data=request.data)
        #校验序列化
        serializer.is_valid(raise_exception=True)

        next_user = instance.creator
        if 'next_user' in serializer.data:
            next_user = serializer.validated_data['next_user']
        opinion = serializer.validated_data["opinion"]
        remark = serializer.validated_data["remark"]

        #我处理不了,但是我的小伙伴能处理,,  移交给他---- opinion 1,2,3

        cur_step = instance.cur_step
        if not cur_step: return Response({'detail': ['流程已更新，您不是当前审批人']}, status=status.HTTP_400_BAD_REQUEST)

        cur_role = cur_step.role
        cur_users = cur_role.users.all()

        roles = ['super_admin', 'workflow_supervisor', 'workflow_admin']
        is_supervisor = True if request.user.role_set.filter(name__in=roles) else False
        if request.user != instance.cur_user and request.user not in cur_users and not is_supervisor:
            return Response({'detail': ['流程已更新，您不是当前审批人']}, status=status.HTTP_400_BAD_REQUEST)

        steps = AuditStep.objects.filter(workflow=instance.workflow).order_by('order_num')

        #找到比当前组order_num大的组做为以后的审批组
        next_step = steps.filter(order_num__gt=cur_step.order_num).first()
        data = {}
        data['order'] = instance
        data['user'] = request.user
        data['role'] = cur_role

        #督办:假如我给的人  研发领导  zhansang,lisi  超级管理人
        #if request.user not in cur_users and is_supervisor: data['role'] = Role.objects.get(name='workflow_supervisor')

        data['opinion'] = opinion
        data['remark'] = remark
        with transaction.atomic():
            print("=====================>11111")
            AuditRecord.objects.create(**data)

            # 1. 审批人不是工单流程最后审批人
            if cur_step != steps.last():
                # 驳回
                if opinion == 0:
                    next_step = None
                    next_status = 0
                    next_user = None
                # 同意
                elif opinion == 1 or opinion == 2:
                    next_step = next_step
                    next_status = 3
                # 移交
                elif opinion == 3:
                    next_step = cur_step
                    next_status = instance.status
            # 2. 审批人是工单流程最后审批人
            elif cur_step == steps.last():
                # 驳回
                if opinion == 0:
                    next_step = None
                    next_status = 0
                    next_user = None
                    instance.exec_status = 1
                # 移交
                elif opinion == 3:
                    next_step = cur_step
                    next_status = instance.status
                # 同意
                elif opinion == 1:
                    next_step = None
                    next_status = 4
                    next_user = None
                    instance.status = next_status
                    instance.save()
                    workorder_task.apply_async((instance.id,), queue=settings.HIGH_PRIORITY_QUEUE)
                # 同意，人工执行，不触发自动化脚本执行
                elif opinion == 2:
                    next_step = None
                    next_status = 4
                    next_user = None
                    instance.exec_status = 1

            instance.status = next_status
            instance.cur_step = next_step
            instance.cur_user = next_user
            instance.save()
            # 邮件通知
            # workorder_notice(instance)
        return Response(serializer.data)

    @action(methods=['post'], detail=True)
    def feedback(self, request, pk):
        '''
        申请人确认反馈处理结果
        '''
        with transaction.atomic():
            instance = self.get_object()
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            instance.status = 4
            opinion = serializer.data["opinion"]
            remark = ''
            if 'remark' in serializer.data:
                remark = serializer.data["remark"]
            if instance.status != 4 and request.user != instance.creator:
                return Response({'detail': ['无权限，流程已更新或您不是申请人']}, status=status.HTTP_400_BAD_REQUEST)
            data = {}
            data['order'] = instance
            data['user'] = request.user
            data['role'] = None
            data['opinion'] = opinion
            data['remark'] = remark
            AuditRecord.objects.create(**data)

            # 已解决
            if opinion == 10:
                next_step = None
                next_status = 5
                next_user = None
            # 未解决回退处理人
            elif opinion == 11:
                steps = AuditStep.objects.filter(workflow=instance.workflow).order_by('order_num')
                next_step = steps.last()
                next_status = 6
                next_user = AuditRecord.objects.filter(order=instance, role=next_step.role).last().user

            instance.status = next_status
            instance.cur_step = next_step
            instance.cur_user = next_user
            instance.save()
        return Response(serializer.data)

    @action(methods=['post'], detail=True)
    def revoke(self, request, pk):
        '''
        工单撤回
        '''
        instance = self.get_object()
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        if instance.status == 2:
            with transaction.atomic():
                instance.status = 5
                instance.cur_step = None
                instance.cur_user = None
                instance.save()
                data = {}
                data['order'] = instance
                data['user'] = instance.creator
                data['role'] = None
                data['opinion'] = 11
                data['remark'] = '自己撤回'
                AuditRecord.objects.create(**data)
        else:
            params={}
            params['opinion']=1
            return Response(params)
        return Response(serializer.data)


    @action(methods=['get'], detail=True)
    def auditrecord(self, request, pk):
        '''
        工单审批记录
        '''
        instance = self.get_object()
        records = instance.auditrecord_set.order_by('-id')
        serializer = self.get_serializer(records, many=True)
        return Response(serializer.data)

class AuditRecordViewSet(BaseModelViewSet):
    queryset = AuditRecord.objects.all()
    serializer_class = AuditRecordSerializer
    ordering_fields = ('id', 'name',)
    search_fields = ('name', 'cname')