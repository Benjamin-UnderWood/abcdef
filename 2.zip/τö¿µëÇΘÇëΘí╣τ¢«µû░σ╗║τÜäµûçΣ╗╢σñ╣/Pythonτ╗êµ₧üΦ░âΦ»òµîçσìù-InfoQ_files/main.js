(function(){
  function loadCSS(url) {
    var domLink = document.createElement('link');
    domLink.href = url;
    domLink.rel = 'stylesheet';
    document.getElementsByTagName('head')[0].appendChild(domLink);
  }

  loadCSS('https://static001.geekbang.org/static/infoq/www/css/app.da68435f.css')

    function loadJS(url, success) {
      var domScript = document.createElement('script');
      domScript.src = url;
      success = success || function () {};
      domScript.onload = domScript.onreadystatechange = function () {
          if (!this.readyState || 'loaded' === this.readyState || 'complete' === this.readyState) {
              success();
              this.onload = this.onreadystatechange = null;
              this.parentNode.removeChild(this);
          }
      }
      document.getElementsByTagName('head')[0].appendChild(domScript);
    }

    loadJS('https://static001.geekbang.org/static/infoq/www/js/chunk-swiper.4133b822.js', function () {
      loadJS('https://static001.geekbang.org/static/infoq/www/js/chunk-vendors.5be94349.js', function () {
        loadJS('https://static001.geekbang.org/static/infoq/www/js/app.2700e518.js');
      });
    });
  })();