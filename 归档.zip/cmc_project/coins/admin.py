from django.contrib import admin

from .models import Coin

admin.site.register(Coin)