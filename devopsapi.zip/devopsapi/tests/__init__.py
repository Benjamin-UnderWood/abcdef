import os
import functools


def SetUpDecorator(func):

    def wrapper(*args, **kwargs):

        os.environ.setdefault("DJANGO_SETTINGS_MODULE", "bsc.production_settings")

        import django
        django.setup()

        print("Start...")
        func()
        print("Stop...")


    return functools.wraps(func)(wrapper)
