#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

from django.http import JsonResponse


def api_response(code=20000, message="OK", data=()):
    return JsonResponse({
        "code": code,
        "message": message,
        "data": data
    })
