#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

from django.urls import path
from apps.celery_tasks import views


urlpatterns = [
    # 任务管理
    path('task/manage', views.TaskManager.as_view(), name='task-manage'),
    path('task/details', views.TaskDetails.as_view(), name='task-details'),
    path('task/command', views.ExecCommand.as_view(), name='task-command'),
    path('task/execute', views.ExecTask.as_view(), name='task-execute'),
    path('task/history', views.TaskHistory.as_view(), name='task-history'),
    path('task/history-result', views.TaskHistoryResult.as_view(), name='task-history-result'),
    path('task/crontab', views.CrontabTask.as_view(), name='task-crontab'),
]