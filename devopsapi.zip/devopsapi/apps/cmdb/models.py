from django.db import models
import django.utils.timezone as timezone
# from django_mysql.models import JSONField


def JSONFieldDefault():
    return {}


class Classification(models.Model):
    """ 分类表 """

    name = models.CharField(verbose_name="名称", max_length=128, unique=True)
    remarks = models.CharField(verbose_name="备注", max_length=1024)
    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now)
    update_time = models.DateTimeField(verbose_name="更新时间", auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "cmdb_classification"
        verbose_name = "分类管理"
        verbose_name_plural = "分类管理"


class Table(models.Model):
    """ 表管理 """

    name = models.CharField(verbose_name="名称", max_length=128)
    alias = models.CharField(verbose_name="别名", max_length=128)
    classification = models.ForeignKey("Classification", on_delete=models.CASCADE)
    # fields = JSONField(default=JSONFieldDefault)
    remarks = models.CharField(verbose_name="备注", max_length=1024)
    self = models.ForeignKey("self", on_delete=models.CASCADE, null=True, blank=True)
    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now)
    update_time = models.DateTimeField(verbose_name="更新时间", auto_now=True)

    def __str__(self):
        return self.alias

    class Meta:
        db_table = "cmdb_table"
        verbose_name = "表管理"
        verbose_name_plural = "表管理"


class Data(models.Model):
    """ 数据管理 """

    table = models.ForeignKey("Table", on_delete=models.CASCADE)
    # value = JSONField(default=JSONFieldDefault)
    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now)
    update_time = models.DateTimeField(verbose_name="更新时间", auto_now=True)

    def __str__(self):
        return self.table.alias

    class Meta:
        db_table = "cmdb_data"
        verbose_name = "数据管理"
        verbose_name_plural = "数据管理"


class TableHistory(models.Model):
    table_id = models.IntegerField()  # 表ID
    data_id = models.IntegerField()  # 数据ID
    # change_type = models.CharField(max_length=255)  # 变更类型，增加、更新、删除
    change_time = models.DateTimeField()  # 更新时间
    change_content = models.TextField()  # 更新内容
    """
    增加，...
    更新，...
    删除，table, id
    """

    def __str__(self):
        return self.id

    class Meta:
        db_table = "cmdb_table_history"
        verbose_name = ""
        verbose_name_plural = ""
