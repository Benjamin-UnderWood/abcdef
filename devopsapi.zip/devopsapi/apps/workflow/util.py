# -*- coding: utf-8 -*-
#author Jack qq:774428957
import json
import logging
from django.conf import settings
from utils.util import send_html_mail
from apps.workflow.models import *

logger = logging.getLogger('views')
def workorder_notice(instance):
    '''工单通知'''
    data = json.loads(instance.data)
    if instance.cur_user:
        tos = instance.cur_user.email
        cc = ''
        if 'cc' in data: cc = data['cc']
        subject = '<{}>工单处理通知'.format(instance.cname)
        if instance.status == 2:
            content = '<br>{}({})申请 {} 工单已发起，等待您处理，<a href="{}/#/workflow/workorderswaiting" target="_blank">点击处理工单</a>，谢谢！'.format(instance.creator.username, instance.creator.cname, instance.cname, settings.PROJECT_URL)
        elif instance.status == 3:
            content = '<br>{}({})申请 {} 工单上级审批人已审批，等待您处理，<a href="{}/#/workflow/workorderswaiting" target="_blank">点击处理工单</a>，谢谢！'.format(instance.creator.username, instance.creator.cname, instance.cname, settings.PROJECT_URL)
        elif instance.status == 6:
            content = '<br>{}({})申请 {} 工单申请人反馈未解决，等待您确认并处理，<a href="{}/#/workflow/workorderswaiting" target="_blank">点击处理工单</a>，谢谢！'.format(instance.creator.username, instance.creator.cname, instance.cname, settings.PROJECT_URL)
        elif instance.status == 0:
            tos = instance.creator.email
            content = '<br>{} 工单已驳回，<a href="{}/#/workflow/workorders" target="_blank">点击查看</a>，谢谢！'.format(instance.cname, settings.PROJECT_URL)
        else:
            return ''
        return send_html_mail(tos, subject, content, cc=cc)

def get_strees(isone,deep,ishostpool,exclude2):
    from stree.util import get_strees
    return get_strees(isone=isone,deep=deep,ishostpool=ishostpool,exclude2=exclude2)

def get_stree_roles():
    from stree.models import StreeRole
    return StreeRole.objects.all()

def get_stree_auditors():
    from stree.models import StreeRole
    return StreeRole.objects.all()