import django.utils.timezone as timezone
from django.db import models


class ServiceTree(models.Model):
    """ 服务树 """
    # id, label, parent, level
    label = models.CharField(verbose_name="名称", max_length=128)  # 展示节点值
    parent = models.IntegerField(verbose_name="父级", db_index=True)  # 父级菜单ID
    level = models.IntegerField(verbose_name="层级")  # 层级别
    # ...
    create_time = models.DateTimeField(verbose_name='创建时间', default=timezone.now)
    update_time = models.DateTimeField(verbose_name='更新时间', auto_now=True)

    def __str__(self):
        return self.label

    class Meta:
        db_table = 'service_tree'
        verbose_name = "服务树"
        verbose_name_plural = "服务树"


class BindCMDB(models.Model):
    """ 服务树绑定的CMDB数据 """
    service_tree = models.IntegerField(verbose_name="服务树ID")
    classification = models.IntegerField(verbose_name="分类ID")
    table = models.IntegerField(verbose_name="表ID")
    data = models.IntegerField(verbose_name="数据ID")

    def __str__(self):
        return self.id

    class Meta:
        db_table = 'service_tree_cmdb'
        verbose_name = "服务树绑定CMDB"
        verbose_name_plural = "服务树绑定CMDB"
        index_together = ["service_tree", "classification", "table"]  # 联合索引
