#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm


import json
import logging
from aliyunsdkcore import client
from aliyunsdkecs.request.v20140526.DescribeInstancesRequest import DescribeInstancesRequest
from aliyunsdkecs.request.v20140526.DescribeRegionsRequest import DescribeRegionsRequest

# configuration the log output formatter, if you want to save the output to file,
# append ",filename='ecs_invoke.log'" after datefmt.

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a %d %b %Y %H:%M:%S')
clt = client.AcsClient('<accessKeyId>', '<accessSecret>', 'cn-hangzhou')


# 获取可用区
def hello_aliyun_regions():
    request = DescribeRegionsRequest()
    response = _send_request(request)  # 发送请求
    if response is not None:
        region_list = response.get('Regions').get('Region')  # 可用区
        assert response is not None  # 断言
        assert region_list is not None

        result = map(_print_region_id, region_list)
        # ||
        # result = []
        # for i in region_list:
        #     r = _print_instance_id(i)
        #     result.append(i)

        logging.info("region list: %s", result)


# 实例列表
def list_instances():
    request = DescribeInstancesRequest()  # 实例化
    response = _send_request(request)  # 发送请求
    if response is not None:
        instance_list = response.get('Instances').get('Instance')
        result = map(_print_instance_id, instance_list)
        logging.info("current region include instance %s", result)
        return result
    return []


# 获取实例id，并返回
def _print_instance_id(item):
    instance_id = item.get('InstanceId')
    return instance_id


# 获取可用区ID并返回
def _print_region_id(item):
    region_id = item.get("RegionId")
    return region_id


# send open api request
def _send_request(request):
    request.set_accept_format('json')  # json的格式
    try:
        response_str = clt.do_action_with_exception(request)  # 实际去发送请求的动作
        logging.info(response_str)  # 日志输出
        response_detail = json.loads(response_str)  # 反序列化
        return response_detail
    except Exception as e:
        logging.error(e)


if __name__ == '__main__':
    logging.info("Hello Aliyun OpenApi!")
    hello_aliyun_regions()
    list_instances = list_instances()

    # 发送请求，上报给cmdb
    import requests
    json_value = {
        "table": 1,
        "value": list_instances
    }
    requests.post("http://127.0.0.1/api/v1/data", json=json_value)
