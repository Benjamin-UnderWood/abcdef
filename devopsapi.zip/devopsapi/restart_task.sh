if [ $(ps -ef|grep celery|wc -l|head -1) -gt 1  ];then
    ps -ef|grep celery|grep -v grep|grep -v restart-dcelery|awk '{print $2}'|xargs kill -9
fi
(source env/bin/activate && nohup  celery worker -A bsc --loglevel=info -Q task_a,task_b -c 8 --loglevel=info &>logs/celery/celery_task.log 2>&1 ) &
(source env/bin/activate && nohup celery beat -A bsc --loglevel=info &>logs/celery/celery_beat.log 2>&1) &
(source env/bin/activate && nohup  celery flower -A bsc --address=0.0.0.0 --port=5555 --loglevel=info &>logs/celery/celery_flower.log 2>&1) &
