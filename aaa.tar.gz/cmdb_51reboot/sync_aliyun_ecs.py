#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

"""
key: LTAI5tQVyn1tu5eAnKqACGLn
secret: O4j894f2GVvHYxAQ6h5NgNGXkP0O3h
cn-qingdao-et2-b01
"""

import json
import logging
import requests
from aliyunsdkcore import client
from aliyunsdkecs.request.v20140526.DescribeInstancesRequest import DescribeInstancesRequest
from aliyunsdkecs.request.v20140526.DescribeRegionsRequest import DescribeRegionsRequest

# configuration the log output formatter, if you want to save the output to file,
# append ",filename='ecs_invoke.log'" after datefmt.

access_key_id = "LTAI5tQVyn1tu5eAnKqACGLn"
access_secret = "O4j894f2GVvHYxAQ6h5NgNGXkP0O3h"
region_id = "cn-beijing"

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%a %d %b %Y %H:%M:%S')
clt = client.AcsClient(access_key_id, access_secret, region_id)


# 查询实例
def list_instances():
    request = DescribeInstancesRequest()
    # response = _send_request(request)
    response = {
        "Instances": {
            "Instance": [
                {
                    "ResourceGroupId": "rg-bp67acfmxazb4p****",
                    "Memory": 16384,
                    "InstanceChargeType": "PostPaid",
                    "Cpu": 8,
                    "OSName": "CentOS  7.4 64 位",
                    "InstanceNetworkType": "vpc",
                    "InnerIpAddress": {
                        "IpAddress": [

                        ]
                    },
                    "ExpiredTime": "2017-12-10T04:04Z",
                    "ImageId": "m-bp67acfmxazb4p****",
                    "EipAddress": {
                        "AllocationId": "eip-2ze88m67qx5z****",
                        "IpAddress": "42.112.**.**",
                        "InternetChargeType": "PayByTraffic"
                    },
                    "HostName": "testHostName",
                    "Tags": {
                        "Tag": [
                            {
                                "TagKey": "TestKey",
                                "TagValue": "TestValue"
                            }
                        ]
                    },
                    "VlanId": "",
                    "Status": "Running",
                    "MetadataOptions": {
                        "HttpTokens": "optional",
                        "HttpEndpoint": "enabled"
                    },
                    "InstanceId": "i-bp67acfmxazb4p****",
                    "StoppedMode": "KeepCharging",
                    "CpuOptions": {
                        "ThreadsPerCore": 2,
                        "Numa": "2",
                        "CoreCount": 4
                    },
                    "StartTime": "2017-12-10T04:04Z",
                    "DeletionProtection": False,
                    "SecurityGroupIds": {
                        "SecurityGroupId": [
                            "sg-bp67acfmxazb4p****"
                        ]
                    },
                    "VpcAttributes": {
                        "PrivateIpAddress": {
                            "IpAddress": [
                                "172.17.**.**"
                            ]
                        },
                        "VpcId": "vpc-2zeuphj08tt7q3brd****",
                        "VSwitchId": "vsw-2zeh0r1pabwtg6wcs****",
                        "NatIpAddress": "172.17.**.**"
                    },
                    "InternetChargeType": "PayByTraffic",
                    "InstanceName": "InstanceNameTest",
                    "DeploymentSetId": "",
                    "InternetMaxBandwidthOut": 5,
                    "SerialNumber": "51d1353b-22bf-4567-a176-8b3e12e4****",
                    "OSType": "linux",
                    "CreationTime": "2017-12-10T04:04Z",
                    "AutoReleaseTime": "2017-12-10T04:04Z",
                    "Description": "testDescription",
                    "InstanceTypeFamily": "ecs.g5",
                    "DedicatedInstanceAttribute": {
                        "Tenancy": "default",
                        "Affinity": "default"
                    },
                    "PublicIpAddress": {
                        "IpAddress": [
                            "121.40.**.**"
                        ]
                    },
                    "GPUSpec": "",
                    "NetworkInterfaces": {
                        "NetworkInterface": [
                            {
                                "Type": "Primary",
                                "PrimaryIpAddress": "172.17.**.***",
                                "NetworkInterfaceId": "eni-2zeh9atclduxvf1z****",
                                "MacAddress": "00:16:3e:32:b4:**",
                                "PrivateIpSets": {
                                    "PrivateIpSet": [
                                        {
                                            "PrivateIpAddress": "172.17.**.**",
                                            "Primary": True
                                        }
                                    ]
                                }
                            }
                        ]
                    },
                    "SpotPriceLimit": 0.98,
                    "DeviceAvailable": True,
                    "SaleCycle": "month",
                    "InstanceType": "ecs.g5.large",
                    "OSNameEn": "CentOS  7.4 64 bit",
                    "SpotStrategy": "NoSpot",
                    "IoOptimized": True,
                    "ZoneId": "cn-hangzhou-g",
                    "ClusterId": "c-bp67acfmxazb4p****",
                    "EcsCapacityReservationAttr": {
                        "CapacityReservationPreference": "",
                        "CapacityReservationId": ""
                    },
                    "DedicatedHostAttribute": {
                        "DedicatedHostId": "dh-bp67acfmxazb4p****",
                        "DedicatedHostName": "testDedicatedHostName",
                        "DedicatedHostClusterId": "dc-bp67acfmxazb4h****"
                    },
                    "GPUAmount": 4,
                    "OperationLocks": {
                        "LockReason": [

                        ]
                    },
                    "InternetMaxBandwidthIn": 50,
                    "Recyclable": False,
                    "RegionId": "cn-hangzhou",
                    "CreditSpecification": ""
                }
            ]
        },
        "TotalCount": 1,
        "RequestId": "473469C7-AA6F-4DC5-B3DB-A3DC0DE3C83E",
        "PageSize": 10,
        "PageNumber": 1,
        "NextToken": "caeba0bbb2be03f84eb48b699f0a4883"
    }
    if response is not None:
        instance_list = response.get('Instances').get('Instance')
        result = map(_print_instance_id, instance_list)
        # logging.info("current region include instance %s", list(result))
        return {
            "model": 6,
            "data": list(result)
        }


# 打印实例
def _print_instance_id(item):
    return {
        "instance_id": item.get('InstanceId'),
        "host_name": item.get('HostName'),
        "status": item.get('Status'),
        "instancen_name": item.get('InstanceName'),
    }


# 发送请求
def _send_api_request(request):
    request.set_accept_format('json')
    try:
        response_str = clt.do_action_with_exception(request)
        logging.info(response_str)
        response_detail = json.loads(response_str)
        return response_detail
    except Exception as e:
        logging.error(e)


# 发送 CMDB 请求
def _send_cmdb_request():
    url = "http://127.0.0.1:8000/api/v1/cmdb/resource"

    data = list_instances()
    print(data)

    response = requests.post(url, json=data, headers={"Authorization": "JWT eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6Imxhbnl1bGVpIiwiZXhwIjoxNjI3MjA3MDczLCJlbWFpbCI6Imxhbnl1bGVpQGMuY29tIn0.5LCSGNG0k2_HF2pzS8U9Lt8bMJZgtZE29M2WLOtDAUA"})
    print(response.content)


if __name__ == '__main__':
    logging.info("Hello Aliyun OpenApi!")
    print(_send_cmdb_request())
