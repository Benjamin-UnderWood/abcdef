from pkg.custom_model_view_set import CustomModelViewSet
from . import models, serializers, filter
from django_filters.rest_framework import DjangoFilterBackend
from django.http import JsonResponse
from rest_framework import status
from pkg.has_resource_verify import has_resource_verify


# 模型分组
class ModelGroupViewSet(CustomModelViewSet):
    queryset = models.ModelGroup.objects.all()
    serializer_class = serializers.ModelGroupSerializer

    filter_backends = (DjangoFilterBackend,)
    filter_class = filter.ModelGroupFilter

    def list(self, request, *args, **kwargs):
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            queryset = self.filter_queryset(self.get_queryset())
            page = self.paginate_queryset(queryset)
            if page is not None:
                serializer = self.get_serializer(page, many=True)

                for model_group in serializer.data:
                    model_group["models"] = list(models.Model.objects.filter(group=model_group.get("id")).values())

                return self.get_paginated_response(serializer.data)

            serializer = self.get_serializer(queryset, many=True)
            res["data"] = serializer.data
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"获取模型分组失败，{e}"

        return JsonResponse(res, status=status.HTTP_200_OK)


# 模型分组
class ModelViewSet(CustomModelViewSet):
    queryset = models.Model.objects.all()
    serializer_class = serializers.ModelSerializer

    filter_backends = (DjangoFilterBackend,)
    filter_class = filter.ModelFilter

    def retrieve(self, request, *args, **kwargs):
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            instance = self.get_object()
            serializer = self.get_serializer(instance)
            result = dict(serializer.data)
            field_group_list = list(models.FieldGroup.objects.filter(model=kwargs.get("pk")).values())
            for field_group in field_group_list:
                field_group["fields"] = list(models.Fields.objects.filter(group=field_group.get("id")).values())
            result["field_group"] = field_group_list
            res["data"] = result
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"查询模型详情失败，{e}"

        return JsonResponse(res, status=status.HTTP_200_OK)


# 字段分组
class FieldGroupViewSet(CustomModelViewSet):
    queryset = models.FieldGroup.objects.all()
    serializer_class = serializers.FieldGroupSerializer

    filter_backends = (DjangoFilterBackend,)
    filter_class = filter.FieldGroupFilter


# 字段
class FieldsViewSet(CustomModelViewSet):
    queryset = models.Fields.objects.all()
    serializer_class = serializers.FieldsSerializer

    filter_backends = (DjangoFilterBackend,)
    filter_class = filter.FieldsFilter


# 资源
class ResourceViewSet(CustomModelViewSet):
    queryset = models.Resource.objects.all()
    serializer_class = serializers.ResourceSerializer

    filter_backends = (DjangoFilterBackend,)
    filter_class = filter.ResourceFilter

    def get_data(self, result):
        s, m = has_resource_verify(result)

        if s:
            serializer = self.get_serializer(data=result)
            serializer.is_valid(raise_exception=True)
            self.perform_create(serializer)
            return serializer.data
        else:
            return False

    def create(self, request, *args, **kwargs):
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }
        try:
            params = request.data.get("data", "")
            if params == "":
                res["code"] = 40000
                res["message"] = "创建资源失败"
            elif isinstance(params, list):
                for d in params:
                    dataValue = {
                        "model": request.data.get("model"),
                        "data": d
                    }

                    result = self.get_data(dataValue)
                    if result:
                        res["data"] = result
                    else:
                        res["code"] = 40000
                        res["message"] = "错误"
            elif isinstance(params, dict):
                s, m = has_resource_verify(request.data)

                if s:
                    serializer = self.get_serializer(data=request.data)
                    serializer.is_valid(raise_exception=True)
                    self.perform_create(serializer)
                    res["data"] = serializer.data
                else:
                    res["code"] = 40000
                    res["message"] = m
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"创建资源数据失败，{e}"

        return JsonResponse(res, status=status.HTTP_200_OK)

    def update(self, request, *args, **kwargs):
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }
        try:

            s, m = has_resource_verify(request.data)
            if s:
                partial = kwargs.pop('partial', False)
                instance = self.get_object()
                serializer = self.get_serializer(instance, data=request.data, partial=partial)
                serializer.is_valid(raise_exception=True)
                self.perform_update(serializer)

                if getattr(instance, '_prefetched_objects_cache', None):
                    instance._prefetched_objects_cache = {}

                res["data"] = serializer.data
            else:
                res["code"] = 40000
                res["message"] = m
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"更新资源数据失败，{e}"

        return JsonResponse(res, status=status.HTTP_200_OK)


# 资源关联
class ResourceRelatedViewSet(CustomModelViewSet):
    queryset = models.ResourceRelated.objects.all()
    serializer_class = serializers.ResourceSerializer


# 云资源账号
class CloudAccountViewSet(CustomModelViewSet):
    queryset = models.CloudAccount.objects.all()
    serializer_class = serializers.CloudAccountSerializer

    filter_backends = (DjangoFilterBackend,)
    filter_class = filter.CloudAccountFilter


# 云资源同步
class CloudDiscoveryViewSet(CustomModelViewSet):
    queryset = models.CloudDiscovery.objects.all()
    serializer_class = serializers.CloudDiscoverySerializer

    filter_backends = (DjangoFilterBackend,)
    filter_class = filter.CloudDiscoveryFilter
