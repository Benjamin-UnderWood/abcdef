#!/usr/bin/env python
# encoding: utf-8
# @author: lanyulei

from rest_framework import serializers
from . import models


class ModelGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ModelGroup
        fields = '__all__'


class ModelSerializer(serializers.ModelSerializer):
    icon = serializers.CharField(required=False)
    tag = serializers.JSONField(required=False)

    class Meta:
        model = models.Model
        fields = '__all__'


class FieldGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.FieldGroup
        fields = '__all__'


class FieldsSerializer(serializers.ModelSerializer):
    name = serializers.CharField(required=True)
    cname = serializers.CharField(required=True)

    class Meta:
        model = models.Fields
        fields = '__all__'


class ResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Resource
        fields = '__all__'


class ResourceRelatedSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ResourceRelated
        fields = '__all__'


class CloudAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CloudAccount
        fields = '__all__'


class CloudDiscoverySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CloudDiscovery
        fields = '__all__'
