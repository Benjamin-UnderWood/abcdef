#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : YuLei Lan
# @Software: PyCharm

from django.urls import path
from . import views

urlpatterns = [
    # 服务树
    path("", views.ServiceTreeViewSet.as_view({"get": "list", "post": "create"})),
    path("<int:pk>", views.ServiceTreeViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 服务树关联
    path("related", views.TreeRelatedViewSet.as_view({"get": "list", "post": "create"})),
    path("related/<int:pk>", views.TreeRelatedViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 查询关联的资产
    path("get-reloated-resource/<int:pk>", views.GetNodeResourceAPIView.as_view()),

    # 服务模版管理
    path("service-template", views.ServiceTemplateViewSet.as_view({"get": "list", "post": "create"})),
    path("service-template/<int:pk>", views.ServiceTemplateViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 模版进程
    path("template-process", views.TemplateProcessViewSet.as_view({"get": "list", "post": "create"})),
    path("template-process/<int:pk>", views.TemplateProcessViewSet.as_view({"put": "update", "delete": "destroy"})),

    # 模版与进程的关联关系
    path("template-process-related", views.TemplateProcessRelatedViewSet.as_view({"get": "list", "post": "create"})),
    path("template-process-related/<int:pk>",
         views.TemplateProcessRelatedViewSet.as_view({"put": "update", "delete": "destroy"})),
]
