from django.http import JsonResponse
from pkg.custom_model_view_set import CustomModelViewSet
from . import models, serializers
from pkg.recursion_service_tree import recursion_service_tree
from rest_framework.views import APIView
from apps.cmdb.models import Resource
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import transaction


# 服务树结构
class ServiceTreeViewSet(CustomModelViewSet):
    queryset = models.ServiceTreeModel.objects.all()
    serializer_class = serializers.ServiceTreeSerializer

    def list(self, request, *args, **kwargs):
        """
        使用递归的方式，将数据进行树结构的生成
        """
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            top_tree_list = list(models.ServiceTreeModel.objects.filter(parent=0).values())
            for node in top_tree_list:
                node["children"] = list(models.ServiceTreeModel.objects.filter(parent=node["id"]).values())
                node["children"] = recursion_service_tree.set_childrens(node["id"], node["children"])
            res["data"] = top_tree_list
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"获取树结构失败，{e}"
        return JsonResponse(res)

    def destroy(self, request, *args, **kwargs):
        """
        删除节点之前，需判断是否有关联资源
        """

        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            delete_related = request.GET.get("delete_related", "0")

            instance = self.get_object()

            with transaction.atomic():  # 事务
                if delete_related == "1":  # 删除关联
                    models.TreeRelatedModel.objects.filter(tree_id=instance.id).delete()

                # 判断是否有关联的资源数据
                tree_related_count = models.TreeRelatedModel.objects.filter(tree_id=instance.id).count()

                # 判断当前节点是否有子节点
                node_children_count = models.ServiceTreeModel.objects.filter(parent=instance.id).count()

                if tree_related_count > 0:
                    res["code"] = 40000
                    res["message"] = f"删除树节点失败，当前节点存在资源关联情况，无法直接删除。"
                elif node_children_count > 0:
                    res["code"] = 40000
                    res["message"] = f"删除树节点失败，当前节点存在子节点，无法直接删除。"
                else:
                    self.perform_destroy(instance)
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"删除树节点失败，{e}"
        return JsonResponse(res)


# 服务器关联资源
class TreeRelatedViewSet(CustomModelViewSet):
    queryset = models.TreeRelatedModel.objects.all()
    serializer_class = serializers.TreeRelatedSerializer

    def create(self, request, *args, **kwargs):
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            # 判断关联是否存在
            c = models.TreeRelatedModel.objects.filter(
                tree_id=request.data.get("tree_id"),
                target_id=request.data.get("target_id"),
                type=request.data.get("type"),
            ).count()

            if c == 0:
                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                self.perform_create(serializer)
                res["data"] = serializer.data
        except Exception as e:
            res["code"] = 40000
            res["message"] = "新建资源关联失败，{}".format(e)

        return JsonResponse(res)

    def destroy(self, request, *args, **kwargs):
        """
        删除资源关联的
        params: tree_id, target_id, type
        """

        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            models.TreeRelatedModel.objects.filter(
                tree_id=kwargs.get("pk"),
                target_id=request.GET.get("target_id"),
                type=request.GET.get("type")
            ).delete()
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"删除资源关联失败，{e}"

        return JsonResponse(res)


# 查询节点关联的数据
class GetNodeResourceAPIView(APIView):
    def get(self, request, pk, *args, **kwargs):
        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            model_id = request.GET.get("model", None)
            if model_id is None:
                raise Exception("参数 model 没有传递")

            resource_id_list = [t[0] for t in
                                list(models.TreeRelatedModel.objects.filter(tree_id=pk).values_list("target_id"))]

            contact_list = Resource.objects.filter(id__in=resource_id_list, model=model_id).values()
            paginator = Paginator(contact_list, 10)  # 每页显示25条

            page = request.GET.get('page')
            try:
                contacts = paginator.page(page)
            except PageNotAnInteger:
                # 如果请求的页数不是整数，返回第一页。
                contacts = paginator.page(1)
            except EmptyPage:
                # 如果请求的页数不在合法的页数范围内，返回结果的最后一页。
                contacts = paginator.page(paginator.num_pages)

            res["data"] = {
                "total": paginator.count,
                "list": list(contacts.object_list.values()),
            }
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"查询关联资源失败，{e}"

        return JsonResponse(res)


# 服务模板管理
class ServiceTemplateViewSet(CustomModelViewSet):
    queryset = models.ServiceTemplate.objects.all()
    serializer_class = serializers.ServiceTemplateSerializer

    def list(self, request, *args, **kwargs):
        res = {
            "code": 20000,
            "message": "success"
        }

        try:
            queryset = self.filter_queryset(self.get_queryset())
            page = self.paginate_queryset(queryset)
            if page is not None:
                serializer = self.get_serializer(page, many=True)

                res["data"] = serializer.data
                for i in res["data"]:
                    process_list = [p[0] for p in list(
                        models.TemplateProcessRelated.objects.filter(template=i.get("id")).values_list("process"))]
                    i["process_ids"] = process_list

                return self.get_paginated_response(res["data"])
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"查询模型列表失败，{e}"
        return JsonResponse(res)

    def create(self, request, *args, **kwargs):

        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:

            with transaction.atomic():
                process_ids = request.data.get("process_ids")

                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                self.perform_create(serializer)

                # 新建关联
                for i in process_ids:
                    models.TemplateProcessRelated.objects.create(**{
                        "template": serializer.data.get("id"),
                        "process": i
                    })

                res["data"] = serializer.data
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"编辑服务模版失败，{e}"

        return JsonResponse(res)

    def update(self, request, *args, **kwargs):

        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:

            with transaction.atomic():
                process_ids = request.data.get("process_ids")
                partial = kwargs.pop('partial', False)
                instance = self.get_object()
                serializer = self.get_serializer(instance, data=request.data, partial=partial)
                serializer.is_valid(raise_exception=True)
                self.perform_update(serializer)

                if getattr(instance, '_prefetched_objects_cache', None):
                    # If 'prefetch_related' has been applied to a queryset, we need to
                    # forcibly invalidate the prefetch cache on the instance.
                    instance._prefetched_objects_cache = {}

                # 删除其他关联
                models.TemplateProcessRelated.objects.filter(template=instance.id).delete()

                # 新建关联
                for i in process_ids:
                    models.TemplateProcessRelated.objects.create(**{
                        "template": instance.id,
                        "process": i
                    })

                res["data"] = serializer.data
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"编辑服务模版失败，{e}"

        return JsonResponse(res)

    def destroy(self, request, *args, **kwargs):
        """
        删除服务模版
        """

        res = {
            "code": 20000,
            "data": "",
            "message": "success"
        }

        try:
            # 判断是否有关联的进程
            template_id = kwargs.get("pk")
            if template_id:
                process_count = models.TemplateProcessRelated.objects.filter(template=template_id).count()
                if process_count == 0:
                    models.TemplateProcess.objects.filter(id=template_id).delete()
                else:
                    res["code"] = 40000
                    res["message"] = "当前模版有进程的关联数据，请清理后，再次删除"
            else:
                res["code"] = 40000
                res["message"] = "未查询到 pk 的参数，请确认"
        except Exception as e:
            res["code"] = 40000
            res["message"] = f"删除资源关联失败，{e}"

        return JsonResponse(res)


# 模版进程管理
class TemplateProcessViewSet(CustomModelViewSet):
    queryset = models.TemplateProcess.objects.all()
    serializer_class = serializers.TemplateProcessSerializer


# 模版与进程的关联关系
class TemplateProcessRelatedViewSet(CustomModelViewSet):
    queryset = models.TemplateProcessRelated.objects.all()
    serializer_class = serializers.TemplateProcessRelatedSerializer
