from django.db import models
from django.utils import timezone


# 树结构表
class ServiceTreeModel(models.Model):
    """
    有的DBA对建表的规范是，ID，创建时间，更新时间 是必须要有的字段
    """

    label = models.CharField(verbose_name="名称", max_length=128)
    name = models.CharField(verbose_name="标识", max_length=128, unique=True)
    parent = models.IntegerField(verbose_name="父级ID")  # 0 表示顶级
    level = models.IntegerField(verbose_name="层级")
    tags = models.JSONField(verbose_name="tag标签", null=True, blank=True)

    # ...

    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now())
    update_time = models.DateTimeField(verbose_name="创建时间", auto_now=True)

    # admin
    def __str__(self):
        return f"{self.name}"

    class Meta:
        db_table = "tree_list"
        verbose_name = "服务树"
        verbose_name_plural = "服务树"


# 树对应其他服务关联表
class TreeRelatedModel(models.Model):
    tree_id = models.IntegerField(verbose_name="服务树节点ID")
    target_id = models.IntegerField(verbose_name="资源ID")
    type = models.IntegerField(verbose_name="资源类型")  # 1 则是关联的CMDB

    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now())
    update_time = models.DateTimeField(verbose_name="创建时间", auto_now=True)

    class Meta:
        db_table = "tree_related"
        verbose_name = "服务树资源关联表"
        verbose_name_plural = "服务树资源关联表"


# 模版基本信息表
class ServiceTemplate(models.Model):
    name = models.CharField(verbose_name="名称", max_length=128)
    cname = models.CharField(verbose_name="别名", max_length=128)

    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now())
    update_time = models.DateTimeField(verbose_name="创建时间", auto_now=True)

    class Meta:
        db_table = "tree_service_template"
        verbose_name = "服务模版"
        verbose_name_plural = "服务模版"


# 进程信息表
class TemplateProcess(models.Model):
    name = models.CharField(verbose_name="名称", max_length=128)
    cname = models.CharField(verbose_name="别名", max_length=128)
    params = models.CharField(verbose_name="启动参数", max_length=256)
    ip = models.CharField(verbose_name="监听地址", max_length=128)
    port = models.IntegerField(verbose_name="监听端口")
    worker = models.CharField(verbose_name="工作目录", max_length=128)
    start_command = models.CharField(verbose_name="启动命令", max_length=128)
    restart_command = models.CharField(verbose_name="重启命令", max_length=128)
    reload_command = models.CharField(verbose_name="重载命令", max_length=128)
    stop_command = models.CharField(verbose_name="重载命令", max_length=128)

    remarks = models.CharField(verbose_name="备注", max_length=1024)

    create_time = models.DateTimeField(verbose_name="创建时间", default=timezone.now())
    update_time = models.DateTimeField(verbose_name="创建时间", auto_now=True)

    class Meta:
        db_table = "tree_template_process"
        verbose_name = "模版进程"
        verbose_name_plural = "模版进程"


# 模版与进程关联表
class TemplateProcessRelated(models.Model):
    template = models.IntegerField(verbose_name="服务模版")
    process = models.IntegerField(verbose_name="服务进程")

    class Meta:
        db_table = "tree_template_process_related"
        verbose_name = "模版与进程的关联"
        verbose_name_plural = "模版与进程的关联"
