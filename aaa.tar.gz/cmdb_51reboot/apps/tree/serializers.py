#!/usr/bin/env python
# encoding: utf-8
# @author: lanyulei

from rest_framework import serializers
from . import models


class ServiceTreeSerializer(serializers.ModelSerializer):
    tags = serializers.JSONField(required=False)

    class Meta:
        model = models.ServiceTreeModel
        fields = '__all__'


class TreeRelatedSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.TreeRelatedModel
        fields = '__all__'


class ServiceTemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ServiceTemplate
        fields = '__all__'


class TemplateProcessSerializer(serializers.ModelSerializer):
    worker = serializers.JSONField(required=False)
    start_command = serializers.JSONField(required=False)
    restart_command = serializers.JSONField(required=False)
    reload_command = serializers.JSONField(required=False)
    stop_command = serializers.JSONField(required=False)
    params = serializers.JSONField(required=False)
    remarks = serializers.JSONField(required=False)

    class Meta:
        model = models.TemplateProcess
        fields = '__all__'


class TemplateProcessRelatedSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.TemplateProcessRelated
        fields = '__all__'
